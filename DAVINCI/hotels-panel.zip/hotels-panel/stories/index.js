import React from 'react';
import { storiesOf, addDecorator } from '@storybook/react';
import injectTapEventPlugin from 'react-tap-event-plugin';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import davinciTheme from './davinciTheme.js';

import Date from '../app/common/Date';
import DateFlat from '../app/common/Date/DateFlat';
import DatePicker from '../app/common/DatePicker';
import Input from '../app/common/Input';
import NotificationBlock from '../app/common/NotificationBlock';
import RaisedBtn from '../app/common/RaisedBtn';
import Id from '../app/common/Id';
import More from '../app/common/More';

import RequestBlock from '../app/common/RequestBlock';
import Offer from '../app/pages/OfferPage/Offer';

const WrapDecorator = storyFn => (
  <MuiThemeProvider muiTheme={getMuiTheme(davinciTheme)} >
    { storyFn() }
  </MuiThemeProvider>
);
injectTapEventPlugin();
addDecorator(WrapDecorator);

const checkOut = '2018-04-12T13:55:22.880Z';
const checkIn = '2018-04-02T13:55:22.880Z';

storiesOf('Common', module)
  .add('Date', () => (
    <div>
      <br /><br /><br />
      <Date
        date={{ checkOut, checkIn }}
      />
      <br /><br />
      <Date
        date={{ checkOut, checkIn }}
        active
      />
    </div>

  ))
  .add('Date Flat', () => (
    <DateFlat date="2018-04-02T17:10:22.880Z" />
  ))
  .add('Date Picker', () => (
    <DatePicker />
  ))
  .add('Inputs', () => (
    <div>
      <Input />
      <br />
      <Input
        value={111}
        // onChange={this.handleChangeValidTime}
        floatingLabelText="Hours"
        name="validTime"
        id="validTime"
      />
    </div>
  ))
  .add('Notification Block', () => (
    <NotificationBlock icon={1} title="Dear partners," text={'Please check availability in your Hotel Tegnerlunden hotel for our group planning to arrive on: 02/05/2018 - 04/05/2018 \n We need accommodation with the following preliminary room structure: TWN 40 \n If you have avalibility for our group, please fill in your offer here'} />
  ))
  .add('id', () => (
    <Id id={45211} />
  ))
  .add('More', () => (
    <More amount={5} handleMoreClick={console.log('more click')} />
  ))
  .add('RaisedBtn', () => (
    <div>
      <RaisedBtn
        size={52}
        label="button 1"
      />

      <RaisedBtn
        size={52}
        label="button 2"
        primary
      />
      <br /><br /><br />
      <RaisedBtn
        label="button 1"
      />

      <RaisedBtn
        label="button 2"
        primary
      />
      <br /><br /><br />
      <RaisedBtn
        size={32}
        label="button 1"
      />

      <RaisedBtn
        size={32}
        label="button 2"
        primary
      />
    </div>
  ));
storiesOf('Components', module)
  .add('Request Block', () => (
    <RequestBlock
      request={sessions[0]}
    />
  ))
  .add('Offer', () => (
    <Offer request={sessions[0]} />
  ));

/**
 * app.js
 *
 * This is the entry file for the application, only setup and boilerplate
 * code.
 */

/* eslint-disable import/first */

import 'babel-polyfill';
import React, { lazy, Suspense } from 'react';
import ReactDOM from 'react-dom';
import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { ThemeProvider } from 'styled-components';
import * as Sentry from '@sentry/browser';
import { ApolloProvider } from 'react-apollo';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';

import './style/ui.scss';
import 'react-bootstrap';
import 'sanitize.css/sanitize.css';
import 'app/style/global-styles';
import './style/reset-style-bottstrap.scss';

import reducers from './redux/reducers';
import SystemEventAndNotificationsProvider from 'providers/SystemEventAndNotificationsProvider';
import LanguageProvider from 'app/providers/LanguageProvider';
import { API_SENTRY_DSN } from 'app/utils/environment';
import apolloClient from 'app/apollo';
import { translationMessages } from 'app/i18n';
import themeStyled from 'app/style/theme-styled';
import davinciTheme from 'app/style/theme-mui';
import initHotJar from 'app/utils/hotjar';

const BasePage = lazy(() => import('app/pages/BasePage'));
const TermsPage = lazy(() => import('app/pages/TermsPage'));
const NewRequestsPage = lazy(() => import('app/pages/NewRequestsPage'));
const SentOffersPage = lazy(() => import('app/pages/SentOffersPage'));
const ArchiveRequestsPage = lazy(() => import('app/pages/ArchiveRequestsPage'));
const ConfirmedReservationsPage = lazy(() => import('app/pages/ConfirmedReservationsPage/index'));
const OptionalReservationsPage = lazy(() => import('app/pages/OptionalReservationsPage/index'));
const CompletedReservationsPage = lazy(() => import('app/pages/CompletedReservationsPage/index'));
const AllReservationsPage = lazy(() => import('app/pages/AllReservationsPage/index'));
const ArchiveReservationsPage = lazy(() => import('app/pages/ArchiveReservationsPage/index'));
const HowItWorksPage = lazy(() => import('app/pages/StaticPage/HowItWorks'));
const SettingsPage = lazy(() => import('app/pages/SettingsPage/index'));
const OfferDetailPage = lazy(() => import('app/pages/OfferPage/index'));
const SignInPage = lazy(() => import('app/pages/SignInPage'));
const NotFoundPage = lazy(() => import('app/pages/NotFoundPage'));
import FlexRow from 'app/common/design/FlexRow';

// import history from 'app/redux/history';
import Loading from 'app/common/Loading';
import { getAccessToken, getParameterByName } from './utils';

const isProd = process.env.NODE_ENV === 'production';
const initialState = {};
const store = createStore(
  reducers,
  initialState, // initial state
  compose(
    applyMiddleware(thunk),
    // If you are using the devToolsExtension, you can add it here also
    (typeof window.__REDUX_DEVTOOLS_EXTENSION__ !== 'undefined') ? window.__REDUX_DEVTOOLS_EXTENSION__() : f => f, // eslint-disable-line
  ),
);

const token = getAccessToken(getParameterByName('access-token'));

console.log('app ready');

if (isProd) {
  Sentry.init({
    dsn: API_SENTRY_DSN,
  });
  initHotJar();
}

if (!token) {
  Sentry.captureMessage(`TOKEN not found, redirect to login page. All localsorage is:, ${localStorage.getItem('access-token')}`);
  ReactDOM.render(
    <Suspense fallback={<Loading />}>
      <SignInPage />
    </Suspense>,
    document.getElementById('app'),
  );
} else {
  const render = (messages) => {
    ReactDOM.render(
      <FlexRow>
        <MuiThemeProvider muiTheme={getMuiTheme(davinciTheme)}>
          <ThemeProvider theme={themeStyled}>
            <Provider store={store}>
              <ApolloProvider client={apolloClient} >
                <SystemEventAndNotificationsProvider>
                  <LanguageProvider messages={messages}>
                    <Router>
                      <Suspense fallback={<Loading />}>
                        <BasePage />
                        <Switch>
                          <Route path="/signin" component={SignInPage} />
                          <Route path="/terms" component={TermsPage} />
                          <Route
                            exact
                            path={[
                              '/:hotelId/requests/:sessionId/new',
                              '/:hotelId/requests/new/:sessionId',
                              '/:hotelId/requests/new',
                              '/:hotelId/requests',
                              '/requests/:sessionId',
                              '/requests/:sessionId/offer',
                              '/requests',
                              '/',
                            ]}
                            component={NewRequestsPage}
                          />
                          <Route path="/:hotelId/requests/sent" component={SentOffersPage} />
                          <Route path="/:hotelId/requests/archive" component={ArchiveRequestsPage} />
                          <Route
                            exact
                            path={[
                              '/:hotelId/reservations/all',
                              '/:hotelId/reservations/',
                            ]}
                            component={AllReservationsPage}
                          />
                          <Route path="/:hotelId/reservations/confirmed" component={ConfirmedReservationsPage} />
                          <Route path="/:hotelId/reservations/optional" component={OptionalReservationsPage} />
                          <Route path="/:hotelId/reservations/completed" component={CompletedReservationsPage} />
                          <Route path="/:hotelId/reservations/archive" component={ArchiveReservationsPage} />
                          <Route path="/:hotelId/how_it_works" component={HowItWorksPage} />
                          <Route path="/:hotelId/settings" component={SettingsPage} />
                          <Route path="/:hotelId/requests/new/:_id/offer" component={OfferDetailPage} />
                          <Route component={NotFoundPage} />
                        </Switch>
                      </Suspense>
                    </Router>
                  </LanguageProvider>
                </SystemEventAndNotificationsProvider>
              </ApolloProvider>
            </Provider>
          </ThemeProvider>
        </MuiThemeProvider>
      </FlexRow>,
      document.getElementById('app'),
    );
  };

  // Hot reloadable translation json files
  if (module.hot) {
    // modules.hot.accept does not accept dynamic dependencies,
    // have to be constants at compile-time
    module.hot.accept('app/utils/i18n', () => {
      render(translationMessages);
    });
  }

  // Chunked polyfill for browsers without Intl support
  if (!window.Intl) {
    (new Promise((resolve) => {
      resolve(import('intl'));
    }))
      .then(() => Promise.all([
        import('intl/locale-data/jsonp/en.js'),
      ])).then(() => render(translationMessages))
      .catch((err) => {
        throw err;
      });
  } else {
    render(translationMessages);
  }
}

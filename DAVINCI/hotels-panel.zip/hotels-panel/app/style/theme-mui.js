/**
 * Created by Max Kudla.
 */

export default {
  fontFamily: 'Roboto',
  palette: {
    primary1Color: '#04B9E6',
    primary2Color: '#04B9E6',
  },
};

import { WS_URL, GRAPH_URL, env } from 'app/utils/environment';
import { ApolloClient } from 'apollo-client';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { split, from } from 'apollo-link';
import { getOperationAST } from 'graphql';
import { HttpLink } from 'apollo-link-http';
import { WebSocketLink } from 'apollo-link-ws';
import { setContext } from 'apollo-link-context';
import { getAccessToken, getParameterByName } from 'app/utils';

let token = null;
if (!location.href.endsWith('signin')) {
  token = getAccessToken(getParameterByName('access-token'));
}

const httpLink = new HttpLink({ uri: `${GRAPH_URL}/graphql` });
const httpAuthLink = setContext(() => ({
  headers: {
    authorization: token ? `Bearer ${token}` : null,
  },
}));

const WSLink = new WebSocketLink({
  uri: `${WS_URL}/subscriptions`,
  options: {
    lazy: true,
    timeout: 3000,
    reconnectionAttempts: 1000000,
    reconnect: true, // auto-reconnect
    connectionParams: {
      authorization: token,
    },
    connectionCallback: (() => {}),
  },
});

const link = split(
  (operation) => {
    const operationAST = getOperationAST(operation.query, operation.operationName);
    return !!operationAST && operationAST.operation === 'subscription';
  },
  WSLink,
  from([
    httpAuthLink,
    httpLink,
  ]),
);

export default new ApolloClient({
  link,
  cache: new InMemoryCache(),
  connectToDevTools: env !== 'production',
});

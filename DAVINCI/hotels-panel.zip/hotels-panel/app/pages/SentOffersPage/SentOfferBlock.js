import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { redirectToOfferPage, getCityTaxValue } from 'app/utils';
import SentOfferBody from './SentOfferBody';
import SentOfferHeader from './SentOfferHeader';
import SentOfferBodyDeclined from './SentOfferBodyDeclined';
import OfferInfoWrapWrap from 'app/common/SentedOffer';
import HotelUtils from 'app/utils/hotel';
import OfferCollapseContainer from 'app/common/SentedOffer/OfferCollapseContainer';

class SentOfferBlock extends PureComponent {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.handlerEditSession = this.handlerEditSession.bind(this);
    this.state = { collapse: false };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  handlerEditSession = async () => {
    const { offer: { _id: sessionId }, onCancelSession, history } = this.props;
    await onCancelSession({ sessionId });
    redirectToOfferPage(sessionId, history);
  };

  render() {
    const {
      offer, handleOpenDialog, HotelBlock, currencies, hotelQuery,
    } = this.props;
    const { collapse } = this.state;

    const {
      isDeclined = false,
      proposals,
      foc,
      meal,
      cityTax,
      upTo,
      dueDays,
      sign = '€',
      rooms = [],
      declinedMsg = '',
      declined = false,
    } = HotelUtils.getDataHotel(offer, currencies, hotelQuery);
    const cityTaxValue = getCityTaxValue(cityTax);

    return (
      <OfferInfoWrapWrap
        num={offer.num}
      >
        <SentOfferHeader
          upTo={upTo}
          declined={declined}
          declinedMsg={declinedMsg}
          rooms={rooms}
          HotelBlock={HotelBlock}
          onClickHeader={this.toggle}
          handlerEditSession={this.handlerEditSession}
          handleOpenDialog={handleOpenDialog}
          offer={offer}
        />
        <OfferCollapseContainer collapse={collapse} toggle={this.toggle}>
          <div>
            {collapse ? (<div>
              {isDeclined ?
                <SentOfferBodyDeclined
                  offer={offer}
                  meal={meal}
                /> :
                <SentOfferBody
                  foc={foc}
                  meal={meal}
                  upTo={upTo}
                  sign={sign}
                  cityTaxValue={cityTaxValue}
                  dueDays={dueDays}
                  proposals={proposals}
                  checkIn={offer.checkIn}
                  checkOut={offer.checkOut}
                />
              }
            </div>) : null}
        </div>
        </OfferCollapseContainer>
      </OfferInfoWrapWrap>
    );
  }
}

SentOfferBlock.propTypes = {
  offer: PropTypes.shape({
    status4Hotel: PropTypes.string,
    checkIn: PropTypes.string,
    checkOut: PropTypes.string,
    num: PropTypes.string,
  }),
  hotel: PropTypes.shape({
    name: PropTypes.string,
  }),
  handleOpenDialog: PropTypes.func,
  onCancelSession: PropTypes.func,
};

export default SentOfferBlock;

import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

import { get } from 'lodash';
import { Row, Col } from 'reactstrap';

import CommentsBlock from 'app/common/SentedOffer/CommentsBlock';
import MealBlock from 'app/common/SentedOffer/MealBlock';
import RatingHotelBlock from 'app/common/SentedOffer/RatingHotelBlock';
import BudgetBlock from 'app/common/SentedOffer/BudgetBlock';
import CityTaxBlock from 'app/common/SentedOffer/CityTaxBlock';
import RequestWasSentBlock from 'app/common/SentedOffer/RequestWasSentBlock';
import i18n from 'app/utils/i18n';

class SentOfferBodyDeclined extends PureComponent {
  render() {
    const { offer, meal } = this.props;
    const {
      createdAt,
      requestData,
      sessionRequestComment,
      budget,
    } = offer;

    return (
      <div>
        <Row>
          <Col xs="4">
            <MealBlock
              meal={meal}
              msg={i18n('app.components.Request.meal_plan')}
            />
            <RatingHotelBlock
              handleRating={this.handleRating}
              msg={i18n('app.components.Request.hotel_rating')}
              rating={get(requestData, 'stars', [])}
            />
          </Col>
          <Col xs="4">
            <BudgetBlock
              sessionBudget={budget}
            />
            <CityTaxBlock
              cityTax={get(requestData, 'cityTax')}
              msg={i18n('app.components.Request.city_tax')}
            />
          </Col>
          <Col xs="4">
            <RequestWasSentBlock
              msg={i18n('app.components.Requests.wasSent')}
              createdAt={createdAt}
              classStyle="OfferWrapRowPadding"
            />
          </Col>
        </Row>
        <CommentsBlock
          msg={i18n('app.components.Request.comment')}
          commentText={sessionRequestComment}
        />
      </div>
    );
  }
}
SentOfferBodyDeclined.propTypes = {
  offer: PropTypes.object,
};
export default SentOfferBodyDeclined;

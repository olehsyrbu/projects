export const CHANGE_FILTER = 'CHANGE_FILTER';
export const CHANGE_FILTER_SUCCESS = 'CHANGE_FILTER_SUCCESS';
export const CHANGE_FILTER_FAIL = 'CHANGE_FILTER_FAIL';

export function changeFilter(activeFilter) {
  return dispatch => dispatch({
    type: CHANGE_FILTER_SUCCESS,
    payload: activeFilter,
  });
}


import initialState from './initialState';

import {
  CHANGE_FILTER,
  CHANGE_FILTER_SUCCESS,
  CHANGE_FILTER_FAIL,
} from './actions';

function SentOffersReducer(state = initialState, { type, payload }) {
  switch (type) {
    case CHANGE_FILTER:
      return state;
    case CHANGE_FILTER_SUCCESS:
      return { ...state, activeFilter: payload };
    case CHANGE_FILTER_FAIL:
      return state;
    default:
      return state;
  }
}

export default SentOffersReducer;

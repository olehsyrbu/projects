import React, { PureComponent } from 'react';
import styled from 'styled-components';
import Label from 'app/common/LabelStatusStyle';
import { Row } from 'reactstrap';

import timerIcon from 'app/media/timer.svg';
import iconCancel from 'app/media/ic_cancel1.svg';
import { colors } from 'app/style/variables';
import IconWrap from 'app/common/design/IconWrap';
import iconApprove from 'app/media/ic_reserved.svg';
import FlexRow from 'app/common/design/FlexRow';
import Flex from 'app/common/design/Flex';
import i18n from 'app/utils/i18n';

import {
  getIsCanceledOffer,
  getIsChoseAnotherHotel,
  getIsNoAvailability,
  getIsOfferExpired,
  getIsChoseYourHotel,
} from 'app/utils/statuses';

import { getIsValidTime } from 'app/utils/date';

const WrapTime = styled.span`
  display: flex;
  align-items: center;
  padding-left: 5px;
  color: ${colors.red};
`;

import LabelStatusDeclined from 'app/common/SentedOffer/LabelStatusDeclinde';
import LabelStatusTimer from 'app/pages/SentOffersPage/TimerLabelStatus';

class SentOffersLabelStatus extends PureComponent {
  render() {
    const {
      status4Hotel, declined, declinedMsg, upTo,
    } = this.props;

    const isCanceledOffer = getIsCanceledOffer(status4Hotel);
    const isChoseYourHotel = getIsChoseYourHotel(status4Hotel);
    const isDeclinedOffer = isCanceledOffer && !declined && declinedMsg && true || false;
    const status4HotelText = i18n(`app.components.SentOffers.${status4Hotel}`);

    if (isChoseYourHotel) {
      return (<Label color={colors.green}>
        <IconWrap>
          <img src={iconApprove} />
        </IconWrap>
        {i18n('app.components.SentOffers.CHOISED_YOUR_HOTEL')}
      </Label>);
    }

    if (getIsChoseAnotherHotel(status4Hotel)) {
      return (<Label color={colors.red}>
        <IconWrap>
          <img src={iconCancel} />
        </IconWrap>
        {status4HotelText}
      </Label>);
    }

    if (isDeclinedOffer) {
      return (
        <LabelStatusDeclined status4Hotel={status4Hotel} declinedMsg={declinedMsg} />
      );
    }

    if (getIsOfferExpired(status4Hotel)) {
      return (
          <Label color={colors.orange}>
            <FlexRow>
              <Flex>
                <IconWrap>
                  <img src={timerIcon} />
                </IconWrap>
                <Row>
                  {i18n('app.components.SentOffers.OFFER_EXPIRED')}:
                  <WrapTime>
                    00:00
                  </WrapTime>
                </Row>
              </Flex>
            </FlexRow>
          </Label>);
    }

    if (getIsNoAvailability(status4Hotel)) {
      return (<Label color={colors.red}>
        <IconWrap>
          <img src={iconCancel} />
        </IconWrap>
        {i18n('app.components.SentOffers.NO_AVAILABILITY')}
      </Label>);
    }

    if (isCanceledOffer && !declined && declinedMsg && true) {
      return (
        <LabelStatusDeclined status4Hotel={status4Hotel} declinedMsg={declinedMsg} />
      );
    }

    // valid status
    if (!isCanceledOffer && !isChoseYourHotel && getIsValidTime(upTo)) {
      return (<LabelStatusTimer msg={i18n('app.components.Offer.RoomStructure.validTime')} upTo={upTo} />);
    }

    if (!getIsValidTime(upTo)) {
      return i18n('app.components.SentOffers.OFFER_EXPIRED');
    }

    return status4HotelText && <Label color={colors.red}>{status4HotelText}</Label> || null;
  }
}

export default SentOffersLabelStatus;

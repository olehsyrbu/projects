import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { has, map, size } from 'lodash';
import { adopt } from 'react-adopt/dist/index';
import FlexEnd from 'app/common/design/FlexEnd';
import TitleBlockByDay from 'app/common/TitlePeriod';
import Title from 'app/common/TitlePage/index';
import Filter from 'app/common/Filter';
import PageWrapper from 'app/common/PageWrapper/index';
import Content from 'app/common/PageWrapper/Content';
import Dialog from 'app/common/DialogQuestion/index';
import SentOfferBlock from './SentOfferBlock';
import EmptyInfo from 'app/common/EmptyInfo';
import { styleSubMenuPage } from 'app/common/design/style';
import Loading from 'app/common/Loading/LoadingWrapPage';
import DialogError from 'app/common/Errors/DialogError';
import { changeFilter } from './actions';
import HotelInfo from 'app/common/HotelInfo';
import { colors } from 'app/style/variables';
import i18n from 'app/utils/i18n';
import {
  sortSessionsByFieldReverse,
  getValidOffersByHotelProposalsUpTo,
  getSessionsGroupByField,
  addToSessionAddedAt,
} from 'app/utils/sessions';

import SentOffersProvider from 'app/providers/Requests/SentOffersProvider';
import CancelReactionProvider from 'app/providers/Proposals/CancelReactionProvider';
import CurrencyProvider from 'app/providers/Requests/CurrencyProvider';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import SentryGraph from 'app/utils/sentryGraphUtil';

class SentOffers extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpenDialog: false,
      listActionsFilter: [
        { name: 'All offers', value: 0 },
        { name: 'Valid offers', value: 1 },
        { name: 'Cancelled offers', value: 2 },
      ],
      ...this.getInitState(props),
    };
    this.handleOkDialog = this.handleOkDialog.bind(this);
    this.handlerChangeFilter = this.handlerChangeFilter.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    this.setState(this.getInitState(nextProps));
  }

  getInitState = (props) => {
    if (props.sessions.loading) {
      return {
        isSessionLoading: true,
      };
    }

    if (props.sessions.error) {
      return {
        isSessionError: true,
      };
    }

    const sessions = addToSessionAddedAt(props.sessions.data.sentOffers);
    const activeFilter = has(props, 'activeFilter') ? props.activeFilter : 0;
    const offers = this.getOffers(sessions, activeFilter);

    return {
      isSessionLoading: false,
      isSessionError: false,
      sessions,
      offers,
      activeFilter: props.activeFilter,
      history: props.history,
      hotelQuery: props.hotelQuery,
      onCancelReaction: props.onCancelReaction,
    };
  };

  handlerChangeFilter = (activeFilter) => {
    this.props.changeFilter(activeFilter);
    this.setState({
      offers: this.getOffers(this.props.sessions.data.sentOffers, activeFilter),
    });
  };

  getOffers = (sessions, activeFilterIndex) => {
    switch (activeFilterIndex) {
      case 1:
        const validOffers = getValidOffersByHotelProposalsUpTo(sessions);
        return getSessionsGroupByField(sortSessionsByFieldReverse(validOffers, 'addedAt'), 'addedAt');
      case 2:
        // get offer if UpTo is expired or have hotelsDeclined[0].id
        const declinedOffers = sessions.filter(s => has(s, 'hotelsDeclined[0].id'));
        return getSessionsGroupByField(sortSessionsByFieldReverse(declinedOffers, 'addedAt'), 'addedAt') || [];
      default:
        return getSessionsGroupByField(sortSessionsByFieldReverse(sessions, 'addedAt'), 'addedAt');
    }
  };

  handleOpenDialog = (id) => {
    this.setState({ isOpenDialog: true, id });
  };

  handleCloseDialog = () => {
    this.setState({ isOpenDialog: false });
  };

  handleOkDialog = () => {
    this.props.onCancelReaction({
      sessionId: this.state.id,
    });
    this.setState({ isOpenDialog: false });
  };

  render() {
    const {
      activeFilter,
      listActionsFilter,
      offers,
      isOpenDialog,
      onCancelReaction,
      hotelQuery,
      isSessionLoading,
      isSessionError,
    } = this.state;

    if (isSessionLoading) return (<Loading />);

    if (isSessionError) {
      SentryGraph(this.props.sessions.error);
      return <DialogError />;
    }

    const hotelName = hotelQuery ? hotelQuery.name : '';
    const hotelLogo = hotelQuery ? hotelQuery.media.logo : '';

    if (isOpenDialog) {
      return (
        <Dialog
          title={i18n('app.components.Sessions.dialogTitleRecoverOffer')}
          modal={false}
          open={isOpenDialog}
          handlerOk={this.handleOkDialog}
          handleClose={this.handleCloseDialog}
        />
      );
    }

    return (
      <PageWrapper style={styleSubMenuPage}>
        <Content>
          <Title text={i18n('app.components.SentOffers.title')}>
            <FlexEnd>
              <Filter
                active={listActionsFilter[activeFilter].value}
                list={listActionsFilter}
                onChangeFilter={this.handlerChangeFilter}
              />
            </FlexEnd>
          </Title>

          {!size(offers) && <EmptyInfo text={i18n('app.components.SentOffers.title')} />}

          {map(offers, (Offers, day) => (
            <div key={day}>
              <TitleBlockByDay
                defMessage={i18n('app.components.SentOffers.Others')}
                date={day}
                count={Offers.length}
              />
              {map(Offers, offer => (
                <SentOfferBlock
                  onCancelSession={onCancelReaction}
                  handleOpenDialog={this.handleOpenDialog}
                  key={offer._id}
                  offer={offer}
                  hotelQuery={hotelQuery}
                  currencies={this.props.currencies}
                  HotelBlock={<HotelInfo
                    hotelName={hotelName}
                    hotelLogo={hotelLogo}
                    sizeAvatar={25}
                    color={colors.grayDarkText}
                  />
                }
                />
              ))}
            </div>
          ))}
        </Content>
      </PageWrapper>
    );
  }
}

SentOffers.propTypes = {
  sessions: PropTypes.object,
  hotelQuery: PropTypes.object,
  currencies: PropTypes.array,
  onCancelReaction: PropTypes.func,
};

const mapStateToProps = state => ({
  activeFilter: state.sentOffers.activeFilter,
});

const mapDispatchToProps = dispatch => ({
  changeFilter: params => dispatch(changeFilter(params)),
});

const SentOffersComponent = connect(mapStateToProps, mapDispatchToProps)(withRouter(SentOffers));

const Composed = adopt({
  onCancelReaction: CancelReactionProvider,
  currencies: CurrencyProvider,
  hotelQuery: HotelProvider,
  sessions: SentOffersProvider,
});

export default data => (
  <Composed>
    {props => (<SentOffersComponent {...props} {...data} />)}
  </Composed>
);

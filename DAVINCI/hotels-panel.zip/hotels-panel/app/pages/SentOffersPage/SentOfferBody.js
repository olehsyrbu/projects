import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { Row, Col } from 'reactstrap';

import CancelationPolicy from 'app/common/SentedOffer/CancelationPolicy';
import RoomsInfo from 'app/common/SentedOffer/TableRoomsSent';
import OfferHotelInfo from 'app/common/SentedOffer/OfferHotelInfo';
import ReservationStatus from 'app/common/SentedOffer/ReservationStatus';
import i18n from 'app/utils/i18n';

const WrapOfferHotelInfo = styled(OfferHotelInfo)`
  margin: 0 10px;
`;

const WrapRooms = styled.div`
  padding-right: 10px;
`;

class SentOfferBody extends PureComponent {
  render() {
    const {
      meal,
      foc,
      checkIn,
      dueDays,
      sign,
      proposals,
      cityTaxValue,
    } = this.props;

    return (
      <Row>
        <Col xs="4">
          <WrapRooms>
            <RoomsInfo sign={sign} rooms={proposals.rooms} />
          </WrapRooms>
        </Col>
        <Col xs="4">
          <WrapOfferHotelInfo
            cityTaxValue={cityTaxValue}
            sign={sign}
            meal={meal}
            foc={foc}
          />
        </Col>
        <Col xs="4">
          <CancelationPolicy
            msg={i18n('app.components.HotelCancellationPolicy.title')}
            Policy={proposals.cancellationPolicy}
          />
          <ReservationStatus
            msg={i18n('app.components.OfferBody.reservationStatus')}
            dueDays={dueDays}
            checkIn={checkIn}
          />
        </Col>
      </Row>
    );
  }
}

SentOfferBody.propTypes = {
  proposals: PropTypes.shape({
    rooms: PropTypes.array,
    cancellationPolicy: PropTypes.shape({
      free: PropTypes.number,
      periods: PropTypes.array,
    }),
  }),
  cityTax: PropTypes.string,
  meal: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  foc: PropTypes.string,
  checkOut: PropTypes.string,
  checkIn: PropTypes.string,
};
export default SentOfferBody;

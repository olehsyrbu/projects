import React, { Component } from 'react';
import { Row, Col } from 'reactstrap';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import _ from 'lodash';

import RoomStructureInfo from 'app/common/RoomStructureInfo';
import HeaderOfferStyle from 'app/common/design/HeaderOfferStyle';

import Label from 'app/common/design/LabelKeys';
import IconBed from 'app/common/IconBed';
import Date from 'app/common/Date';

import RaisedBtn from 'app/common/RaisedBtn.js';
import WrapMargColumn from 'app/common/design/WrapMargColumn';

import FlexEnd from 'app/common/design/FlexEnd';
import iconDelete from 'app/media/delete-forever.svg';
import IconWrap from 'app/common/design/IconWrap';
import LabelStatusOffer from './SentOffersLabelStatus';
import i18n from 'app/utils/i18n';

import {
  getIsOfferExpired,
  getIsNoAvailability,
  getIsCanceledOffer,
  getIsAgencyRequest,
} from 'app/utils/statuses';

import { getIsValidTime } from 'app/utils/date';

const FlexEndStyle = styled(FlexEnd)`
  height: 100%;
`;

class SentOfferHeader extends Component {
  constructor(props, context) {
    super(props, context);
    const { offer: { status4Hotel } } = props;
    this.state = {
      offer: props.offer,
      isOfferNoAvailability: getIsNoAvailability(status4Hotel),
      isExpiredSession: getIsOfferExpired(status4Hotel),
      isCanceledOffer: getIsCanceledOffer(status4Hotel),
    };
  }

  shouldComponentUpdate(nextProps) {
    return !_.isEqual(nextProps.offer, this.state.offer);
  }

  render() {
    const {
      handleOpenDialog,
      handlerEditSession,
      onClickHeader,
      HotelBlock,
      rooms = [],
      upTo,
      declinedMsg = '',
      declined = false,
    } = this.props;

    const {
      offer,
      isOfferNoAvailability,
      isExpiredSession,
      isCanceledOffer,
    } = this.state;
    const {
      status4Hotel, checkIn, checkOut, status,
    } = offer;

    const isAgencyRequest = getIsAgencyRequest(status);
    const isValidOfferCheckOut = getIsValidTime(checkOut);
    const isValidOffer = isOfferNoAvailability && isValidOfferCheckOut;
    const isCanUpdateOffer = isValidOfferCheckOut &&
      (isExpiredSession || isCanceledOffer) && isAgencyRequest;

    return (
      <HeaderOfferStyle isOfferNoAvailability={isOfferNoAvailability} onClick={onClickHeader}>
        <Row>
          <Col xs="3">
            <WrapMargColumn>
              <Date date={{ checkOut, checkIn }} />
            </WrapMargColumn>
            <WrapMargColumn>
              {HotelBlock}
            </WrapMargColumn>
          </Col>
          <Col xs="2">
            <WrapMargColumn>
              <Label>{i18n('app.components.Request.room')}:</Label>
            </WrapMargColumn>
            <WrapMargColumn>
              <Row>
                <IconWrap><IconBed /></IconWrap>
                <RoomStructureInfo rooms={rooms} />
              </Row>
            </WrapMargColumn>
          </Col>
          <Col xs="3">
            <WrapMargColumn>
              <Label>{i18n('app.components.Requests.status')}:</Label>
            </WrapMargColumn>
            <WrapMargColumn>
              <Row>
                <LabelStatusOffer
                  status4Hotel={status4Hotel}
                  declined={declined}
                  declinedMsg={declinedMsg}
                  upTo={upTo}
                />
              </Row>
            </WrapMargColumn>
          </Col>
          <FlexEnd>
             {isCanUpdateOffer &&
               <FlexEndStyle>
                  <RaisedBtn
                    label={i18n('app.common.updateOffer')}
                    onClick={handlerEditSession}
                  />
               </FlexEndStyle>
             }
             {!status4Hotel && isAgencyRequest &&
              <FlexEndStyle>
                <RaisedBtn
                  icon={<img src={iconDelete} />}
                  label={i18n('app.components.Offer.HotelCondition.btnCancel')}
                  onClick={handleOpenDialog.bind(this, offer._id)}
                />
              </FlexEndStyle>
             }
             {isValidOffer && isAgencyRequest &&
               <FlexEndStyle>
                 <RaisedBtn
                   primary
                   label={i18n('app.components.Request.MakeOffer')}
                   onClick={handlerEditSession}
                 />
               </FlexEndStyle>
             }
          </FlexEnd>
        </Row>
      </HeaderOfferStyle>
    );
  }
}

SentOfferHeader.propTypes = {
  offer: PropTypes.shape({
    status4Hotel: PropTypes.string,
    checkIn: PropTypes.string,
    checkOut: PropTypes.string,
    num: PropTypes.string,
  }),
  hotel: PropTypes.shape({
    name: PropTypes.string,
  }),
  handleOpenDialog: PropTypes.func,
  handlerEditSession: PropTypes.func,
};

export default SentOfferHeader;

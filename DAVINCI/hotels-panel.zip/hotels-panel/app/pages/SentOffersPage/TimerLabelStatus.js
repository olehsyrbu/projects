import React from 'react';
import Timer from 'app/common/Timer';
import timerIcon from 'app/media/timer.svg';
import Label from 'app/common/LabelStatusStyle';
import { colors } from '../../style/variables';
import IconWrap from 'app/common/design/IconWrap';
import FlexRow from 'app/common/design/FlexRow';
import Flex from 'app/common/design/Flex';
import styled from 'styled-components';

const PaddingWrap = styled.div`
  padding: 0 5px;
`;

export default ({ upTo, msg, isHideIcon }) => (
  <Label color={colors.orange}>
    <FlexRow>
      <Flex>
        {isHideIcon ? null :
          <IconWrap>
            <img src={timerIcon} />
          </IconWrap>
        }
        {msg}:
         <PaddingWrap>
           <Timer to={upTo} />
         </PaddingWrap>
      </Flex>
    </FlexRow>
  </Label>
);

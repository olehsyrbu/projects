import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { adopt } from 'react-adopt';
import size from 'lodash/size';
import forEach from 'lodash/forEach';
import has from 'lodash/has';
import map from 'lodash/map';
import isEmpty from 'lodash/isEmpty';
import i18n from 'app/utils/i18n';
import { getHotelId } from 'app/utils';
import { getActiveSessions, separateSessionByDate, sortAndPair } from 'app/utils/sessions';

import RequestBlock from 'app/common/RequestBlock/index';
import PageWrapper from 'app/common/PageWrapper/index';
import Content from 'app/common/PageWrapper/Content';
import DialogNotification from 'app/common/DialogNotification';
import TitlePeriod from 'app/common/TitlePeriod';
import Title from 'app/common/TitlePage/index';
import EmptyInfo from 'app/common/EmptyInfo';
import Loading from 'app/common/Loading';
import NewRequestProvider from 'app/providers/Requests/NewRequestsProvider';
import DeclineOfferProvider from 'app/providers/Proposals/DeclineOfferProvider';
import { styleSubMenuPage } from 'app/common/design/style';

class Requests extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      ...this.getInitState(props),
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState(this.getInitState(nextProps));
  }

  getInitState = (props) => {
    const {
      match, newRequestsQuery: { newRequests: sessions, loading, error } = {}, onDeclineSession,
    } = props;
    const { params: { sessionId } } = match;

    if (isEmpty(sessions)) {
      return {
        error,
        loading,
        sessionId,
        isEmptyNewRequests: true,
      };
    }

    if (sessions) {
      const activeSessions = getActiveSessions(sessions, 'checkIn');
      const groupSessionsByDate = separateSessionByDate(activeSessions);
      const sessionsGroup = sortAndPair(groupSessionsByDate);

      const session = sessionId
        ? this.getSessionById(sessionId, sessionsGroup)
        : { isNotFind: false };

      return {
        loading,
        isEmptyNewRequests: false,
        sessionId,
        sessions,
        sessionsGroup,
        onDeclineSession,
        ...session,
        ...props,
      };
    }

    return {
      loading,
      ...props,
    };
  };

  getSessionById = (sessionId, sessions) => {
    let session = null;
    const cloneSessions = Object.assign({}, sessions);

    // sessionsGrouped[0] consist date of month or current day
    // sessionsGrouped[1] consist all session by month
    forEach(cloneSessions, (sessionsGrouped, indexGroup) => forEach(sessionsGrouped[1], (s, index) => {
      if (has(s, '_id') && s._id === sessionId) {
        sessionsGrouped[1].splice(index, 1);

        // remove all array in grouped sessions if seize = 0
        if (!size(sessionsGrouped[1])) {
          sessions.splice(indexGroup, 1);
        }
        session = s;
      }
    }));

    return {
      isNotFind: !!(sessionId && !session),
      session,
    };
  };

  render() {
    const {
      hotelId,
      loading,
      isNotFind,
      sessionId,
      session,
      sessionsGroup,
      onDeclineSession,
      isEmptyNewRequests,
    } = this.state;

    if (loading) return (<Loading />);
    if (sessionId && isEmptyNewRequests || isNotFind) {
      return <DialogNotification isOpen action="notFound" isHideIcon />;
    }

    return (
      <PageWrapper style={styleSubMenuPage}>
        <Content>
          <Title text={i18n('app.common.headerRequest.title')} />
          {
            session && (
              <div>
                <RequestBlock
                  isNewRequest
                  key={session._id}
                  session={session}
                  isHasNotificationTitle
                  onDeclineSession={onDeclineSession}
                  hotelId={hotelId}
                />
              </div>
            )
          }
          {!session && !size(sessionsGroup) && (<EmptyInfo text={i18n('app.components.Requests.title')} />)}

          {map(sessionsGroup, sessionsByDay => (
            // sessionsByDay[0] = date
            // sessionsByDay[1] = array sessions

            <div key={sessionsByDay[0]}>
              <TitlePeriod
                period="month"
                defMessage={i18n('app.components.SentOffers.Others')}
                date={sessionsByDay[0]}
                count={sessionsByDay[1].length}
              />

              {map(sessionsByDay[1], session => (
                <RequestBlock
                  isNewRequest
                  key={session._id}
                  session={session}
                  onDeclineSession={onDeclineSession}
                  hotelId={hotelId}
                />
              ))}
            </div>
          ))}
        </Content>
      </PageWrapper>
    );
  }
}

Requests.propTypes = {
  onDeclineSession: PropTypes.func,
  newRequestsQuery: PropTypes.object,
};

const Composed = adopt({
  newRequestsQuery: NewRequestProvider,
  onDeclineSession: DeclineOfferProvider,
});

export default ({ ...data }) => (<Composed>
  {props => (<Requests {...props} {...data} hotelId={getHotelId()} />)}
</Composed>);

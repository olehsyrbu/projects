import React from 'react';
import PropTypes from 'prop-types';
import { TextWrap, inputStyle } from './styles';
import { FormattedMessage, defineMessages } from 'react-intl';

import TextField from 'app/ui/TextField';

const messages = defineMessages({
  emailAddress: {
    id: 'app.components.emailAddress',
    defaultMessage: 'E-mail address',
  },
});

const msg = {
  emailAddress: <FormattedMessage {...messages.emailAddress} />,
};

const EmailInput = ({ email, handleChangeEmail, failedSaved }) => (
  <div>
    <TextWrap>
      {msg.emailAddress}
    </TextWrap>
    <TextField
      style={inputStyle}
      value={email}
      hintText="email"
      name="email"
      onChange={handleChangeEmail}
      errorsData={failedSaved}
    />
  </div>
);

EmailInput.propTypes = {
  email: PropTypes.string,
  handleChangeEmail: PropTypes.func,
};

export default EmailInput;

import React from 'react';
import PropTypes from 'prop-types';

import get from 'lodash/get';

import { adopt } from 'react-adopt';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import UpdateHotelProvider from 'app/providers/General/UpdateHotelProvider';
import PageWrapper from 'app/common/PageWrapper';

import PhoneSvg from 'material-ui/svg-icons/maps/local-phone';
import Avatar from 'app/common/Avatar';
import NotifySnackbar from 'app/common/NotifySnackBar';
import RaisedBtn from 'app/common/RaisedBtn';
import PricesRange from 'app/pages/SettingsPage/PricesRange/main';
import BudgetTip from 'app/pages/SettingsPage/BudgetTip.js';
import FrequencyEmail from 'app/pages/SettingsPage/FrequencyEmail';
import EmailInput from 'app/pages/SettingsPage/EmailInput';
import { normalizeBudget, BUDGET_DEFAULT } from 'app/utils/global-constant';
import i18n from 'app/utils/i18n';

import {
  Row,
  Ceil,
  WrapHotel,
  SettingsPageStyle,
  TitleSettings,
  TitleStyle,
  Block,
  HotelBlock,
  HotelName,
  HotelAddress,
  WrapBtn,
  HotelInfo,
  HotelPhone,
  phoneStyle,
  ceilStyle,
} from './styles';

class SettingsPage extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      ...this.getDefState(props.hotelQuery),
    };

    this.onSaveSettings = this.onSaveSettings.bind(this);
    this.hideNotify = this.hideNotify.bind(this);
    this.changeBudget = this.changeBudget.bind(this);
  }

  getDefState = hotel => ({
    ...hotel,
    isChanged: false,
    budget: get(hotel, 'budget.personPerNight', BUDGET_DEFAULT),
    emailDeliveryDelay: get(hotel, 'emailDeliveryDelay') === null ? 0 : hotel.emailDeliveryDelay,
  });

  handleChangeEmail = (email) => {
    this.setState({ email, isChanged: true });
  };

  onSaveSettings = async () => {
    const { email, budget, emailDeliveryDelay } = this.state;
    const { updateHotel } = this.props;

    try {
      await updateHotel({
        hotel: {
          email,
          emailDeliveryDelay: +emailDeliveryDelay,
          budget: {
            personPerNight: normalizeBudget(budget),
          },
        },
      });
      this.setState({
        successSaved: true,
      }, () => {
        this.hideNotify({ successSaved: false });
      });
    } catch (e) {
      this.setState({
        failedSaved: true,
      }, () => {
        this.hideNotify({ failedSaved: false });
      });
    }
  };

  hideNotify = (data) => {
    setTimeout(() => {
      this.setState({ ...data, isChanged: false });
    }, 1000);
  };

  onHandlerCancel = () => {
    this.setState({ ...this.getDefState(this.props.hotelQuery) });
  };

  changeBudget = (budget) => {
    this.setState({
      budget,
      isChanged: true,
    });
  };

  handlerChangeBudget = (isBlur, type, e) => {
    const budget = { ...this.state.budget };
    budget[type] = +e.target.value;

    this.changeBudget(isBlur ? normalizeBudget(budget) : budget);
  };

  handlerChangeBudgetRange = newBudget =>
    this.changeBudget(normalizeBudget(newBudget || this.state.budget));

  handlerChangeEmailFrequency = (event, value) => {
    this.setState({
      emailDeliveryDelay: value,
      isChanged: true,
    });
  };

  render() {
    const {
      logo,
      name,
      email,
      geo,
      phone,
      budget,
      isChanged,
      failedSaved,
      successSaved,
      emailDeliveryDelay = 0,
    } = this.state;

    return (
      <PageWrapper>
        <SettingsPageStyle>
          <TitleSettings>{i18n('app.components.settings')}</TitleSettings>
          <WrapHotel>
            <Block>
              <TitleStyle>
                {i18n('app.components.emailSettings')}
              </TitleStyle>
              <Row>
                <Ceil flex="0.5" style={ceilStyle}>
                  <EmailInput
                    email={email}
                    handleChangeEmail={this.handleChangeEmail}
                    failedSaved={failedSaved}
                  />
                </Ceil>
                <Ceil flex="1.5">
                  <FrequencyEmail
                    emailDeliveryDelay={emailDeliveryDelay}
                    onChangeEmailFrequency={this.handlerChangeEmailFrequency}
                  />
                </Ceil>
              </Row>
              <BudgetTip />
              <PricesRange
                handlerChangeBudget={this.handlerChangeBudget}
                onChangeBudgetRange={this.handlerChangeBudgetRange}
                budget={budget}
              />
              <WrapBtn>
                <RaisedBtn
                  label={i18n('app.components.HotelChoose.btnCancel')}
                  onClick={this.onHandlerCancel}
                />
                <RaisedBtn
                  disabled={!isChanged}
                  primary={isChanged}
                  label={i18n('app.components.saveSettings')}
                  onClick={this.onSaveSettings}
                />
              </WrapBtn>

            </Block>
            <HotelBlock>
              <Avatar src={logo} size={84} name={!logo && name} />
              <HotelInfo>
                <HotelName>
                  {name}
                </HotelName>
                <HotelAddress>
                  {geo.address}
                </HotelAddress>
                <HotelPhone>
                  <PhoneSvg style={phoneStyle} />
                  {phone ? `${phone.replace(/(\d{3})/g, '$1 ').trim()}` : '-'}
                </HotelPhone>
              </HotelInfo>
            </HotelBlock>
          </WrapHotel>

          <NotifySnackbar
            isSuccess
            message={i18n('davinci.common.notify.success_save')}
            open={successSaved}
          />
          <NotifySnackbar
            isError
            message={i18n('davinci.common.notify.failed_save')}
            open={failedSaved}
          />
        </SettingsPageStyle>
      </PageWrapper>
    );
  }
}

SettingsPage.propTypes = {
  hotelQuery: PropTypes.object,
  updateHotel: PropTypes.func,
};

const Composed = adopt({
  hotelQuery: HotelProvider,
  updateHotel: UpdateHotelProvider,
});

export default props => (
  <Composed>
    {data => (<SettingsPage {...data} {...props} />)}
  </Composed>
);

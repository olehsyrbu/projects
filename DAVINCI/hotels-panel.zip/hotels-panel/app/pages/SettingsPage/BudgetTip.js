import React from 'react';
import { defineMessages, FormattedMessage } from 'react-intl';

import IconInfo from 'app/common/IconInfo';
import { WrapBudgetTip, TextBudget } from './styles';

const messages = defineMessages({
  textBudget: {
    id: 'app.common.textBudget',
    defaultMessage: 'Your preferred budget (per person per night)',
  },
  tipsBudget: {
    id: 'app.common.tipsBudget',
    defaultMessage: 'Please select your preferred budget range. You will receive your future requests within this budget range only.',
  },
});

const msg = {
  textBudget: <FormattedMessage {...messages.textBudget} />,
  tipsBudget: <FormattedMessage {...messages.tipsBudget} />,
};

export default () => (
  <WrapBudgetTip>
    <TextBudget>{msg.textBudget}</TextBudget>
    <IconInfo
      text={msg.tipsBudget}
      id="app.common.tipsBudget"
    />
  </WrapBudgetTip>
);

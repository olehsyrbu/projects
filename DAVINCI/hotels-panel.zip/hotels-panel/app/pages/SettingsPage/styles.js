import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

export const styleRadioBtn = { fontSize: '14px' };

export const inputStyle = {
  inputStyle: {
    width: '100%',
  },
};

export const radioStyle = {
  block: {
    display: 'flex',
  },
  radioButton: {
    maxWidth: 190,
  },
};
export const TextWrap = styled.div`
  color: ${colors.grayBg};
  font-size: 12px;
  line-height: 42px;
  text-transform: uppercase;
`;

export const WrapBudgetTip = styled.div`
  display: flex;
  flex: 0.3;
  font-size: 13px;
  color: ${colors.grayBg};
  line-height: 16px;
  padding: 24px 8px 0 0;
`;

export const TextBudget = styled.div`
  color: ${colors.dark};
  font-size: ${font.ml};
  font-weight: bold;
  line-height: 30px;
`;

export const WrapHotel = styled.div`
  border: 1px solid ${colors.grayBg};
  display: flex;
`;

export const SettingsPageStyle = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
`;

export const Block = styled.div`
  padding: 40px 32px 40px 36px;
  flex: 2;
`;

export const HotelBlock = styled.div`
  display: flex;
  flex: 1;
  padding: 40px;
  background: ${colors.grayWhiteBG}
`;

export const TitleSettings = styled.div`
  padding: 36px 0px 30px;
  color: ${colors.dark};
  font-size: ${font.xl};
  font-weight: bold;
  line-height: 36px;
`;

export const TitleStyle = styled.div`
  height: 24px;
  color: ${colors.dark};
  font-size: 21px;
  font-weight: bold;
  line-height: 24px;
`;

export const WrapBtn = styled.div`
  margin: 24px 0;
  display: flex;
  justify-content: flex-end;
  & > div {
    margin-left: 18px;
  }
`;

export const Row = styled.div`
  display: flex;
  flex:1;
  width: 100%;
`;

export const Ceil = styled.div`
  flex: 1;
`;

export const HotelInfo = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  padding: 0 20px;
`;

export const HotelName = styled.span`
  color: ${colors.dark};
  font-size: ${font.l};
  font-weight: bold;
  line-height: 24px;
  padding: 10px 0;
`;

export const HotelAddress = styled.span`
  color: ${colors.grayBg};
  font-size: ${font.ml};
  line-height: 24px;
  padding: 10px 0;
`;

export const HotelPhone = styled.span`
  color: ${colors.grayBg};
`;

export const ceilStyle = { marginRight: '34px' };

export const phoneStyle = {
  color: `${colors.grayBg}`,
  height: '16px',
};

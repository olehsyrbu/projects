import React from 'react';
import styled from 'styled-components';
import TextField from 'material-ui/TextField';
import { colors } from '../../../style/variables';

export const RangeWrapStyle = styled.div`
  display: flex;
  flex: 1;
`;

export const RangeInputsStyle = styled.div`
  display: flex;
  flex: .5;
  align-items: center;
  justify-content: flex-start;
`;

export const TextFieldStyle = styled(({ typeInput, ...props }) => (<TextField {...props} />)).attrs({
  className: props => `input-${props.typeInput}`,
})`
  input:focus {
    border-color: ${colors.blue} !important;
  }

  input[type=number]::-webkit-inner-spin-button,
  input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  textarea:focus {
    border-color: ${colors.blue} !important
  }

  textarea[type=number]::-webkit-inner-spin-button,
  textarea[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  label {
    transform: none !important;
  }
`;

export const WrapInput = styled.div`
  flex: 1;
`;

export const SmallText = styled.div`
  font-size: 12px;
  opacity: 0.6;
  color: #3D4145;
`;
export const UperText = styled(SmallText)`
  text-transform: uppercase;
`;

export const PaddingWrap = styled(UperText)`
  padding: 10px 0;
`;

export const styleInput = {
  style: {
    height: '36px',
    width: 'auto',
    marginRight: '10px',
    display: 'flex',
    boxSizing: 'border-box',
    alignItems: 'center',
    fontSize: '14px',
  },
  inputStyle: {
    margin: 0,
    padding: '0.5em 0.25em 0.5em 0.5em',
    width: '90px',
    border: `2px solid ${colors.grayWhiteText}`,
    transition: 'border 300ms ease-in-out',
    float: 'right',
    borderRadius: '2px',
    background: `${colors.light}`,
    color: `${colors.grayBg}`,
  },
  floatingLabelStyle: {
    position: 'absolute',
    lineHeight: '36px',
    transform: 'none',
    top: '0',
    right: '0',
    width: '0',
    paddingRight: '1em',
  },
  floatingLabelFocusStyle: {
    transform: 'none',
  },
};

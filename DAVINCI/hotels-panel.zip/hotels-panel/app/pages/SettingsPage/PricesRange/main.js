import React from 'react';
import InputRange from 'react-input-range';
import 'react-input-range/lib/css/index.css';
import { defValueCurrency, BUDGET_MIN_VALUE, BUDGET_MAX_VALUE } from 'app/utils/global-constant';
import 'app/pages/SettingsPage/PricesRange/style.scss';

import {
  RangeWrapStyle,
  RangeInputsStyle,
  TextFieldStyle,
  WrapInput,
  PaddingWrap,
  styleInput,
} from './style';

export default ({ onChangeBudgetRange, handlerChangeBudget, budget }) => (
  <RangeWrapStyle>
    <RangeInputsStyle>
      <WrapInput>
        <PaddingWrap>Min</PaddingWrap>
        <TextFieldStyle
          {...styleInput}
          typeInput="min"
          type="number"
          underlineShow={false}
          value={budget.min || ''}
          onChange={handlerChangeBudget.bind(this, false, 'min')}
          onBlur={handlerChangeBudget.bind(this, true, 'min')}
          floatingLabelText={defValueCurrency.sign}
        />
      </WrapInput>
      <WrapInput>
        <PaddingWrap>Max</PaddingWrap>
        <TextFieldStyle
          {...styleInput}
          type="number"
          typeInput="max"
          underlineShow={false}
          value={budget.max || ''}
          onChange={handlerChangeBudget.bind(this, false, 'max')}
          onBlur={handlerChangeBudget.bind(this, true, 'max')}
          floatingLabelText={defValueCurrency.sign}
        />
      </WrapInput>
    </RangeInputsStyle>
    <InputRange
      formatLabel={value => `${value.toString()}${defValueCurrency.sign}`}
      minValue={BUDGET_MIN_VALUE}
      maxValue={BUDGET_MAX_VALUE}
      value={budget}
      onChange={onChangeBudgetRange}
    />
  </RangeWrapStyle>
);

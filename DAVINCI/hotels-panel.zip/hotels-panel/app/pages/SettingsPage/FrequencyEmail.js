import React from 'react';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';

import {
  TextWrap,
  radioStyle,
  styleRadioBtn,
} from './styles';

import { defineMessages, FormattedMessage } from 'react-intl';

const messages = defineMessages({
  freqEmailReq: {
    id: 'app.components.freqEmailReq',
    defaultMessage: 'Frequency of email requests',
  },
  PerDay: {
    id: 'app.components.OncePerDay',
    defaultMessage: 'Once per day',
  },
  Instant: {
    id: 'app.radio.Instant',
    defaultMessage: 'Instant',
  },
});

const msg = {
  freqEmailReq: <FormattedMessage {...messages.freqEmailReq} />,
  Instant: <FormattedMessage {...messages.Instant} />,
  PerDay: <FormattedMessage {...messages.PerDay} />,
};

const FrequencyEmail = ({ emailDeliveryDelay = 0, onChangeEmailFrequency }) => (
  <div>
    <TextWrap>
      {msg.freqEmailReq}
    </TextWrap>
    <RadioButtonGroup
      name="FrequencyEmail"
      style={radioStyle.block}
      valueSelected={emailDeliveryDelay}
      defaultSelected={emailDeliveryDelay}
      onChange={onChangeEmailFrequency}
    >
      <RadioButton
        labelStyle={styleRadioBtn}
        value={0}
        label={msg.Instant}
        style={radioStyle.radioButton}
      />
      <RadioButton
        labelStyle={styleRadioBtn}
        value={24}
        label={msg.PerDay}
        style={radioStyle.radioButton}
      />
    </RadioButtonGroup>
  </div>
);
export default FrequencyEmail;

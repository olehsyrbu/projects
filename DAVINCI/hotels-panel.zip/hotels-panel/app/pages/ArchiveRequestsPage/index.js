import React from 'react';
import PropTypes from 'prop-types';
import { adopt } from 'react-adopt';
import Archive from 'app/common/Archive';
import NewRequestProvider from 'app/providers/Requests/NewRequestsProvider';
import Loading from 'app/common/Loading/LoadingWrapPage';

const ArchiveRequests = ({ newRequestsQuery: { newRequests, loading } }) => {
  if (loading) return (<Loading />);
  return (<Archive sessions={newRequests} />);
};

ArchiveRequests.propTypes = {
  newRequestsQuery: PropTypes.object,
};

const Composed = adopt({
  newRequestsQuery: NewRequestProvider,
});

export default () => (
  <Composed>
    {props => (<ArchiveRequests {...props} />)}
  </Composed>
);

import React from 'react';
import PropTypes from 'prop-types';
import { colors } from 'app/style/variables';
import styled from 'styled-components';
import Add from 'material-ui/svg-icons/content/add-circle';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

const msg = {
  titleFAQ: <FormattedMessage {...messages.titleFAQ} />,
  question1: <FormattedMessage {...messages.titleQuestion1FAQ} />,
  question2: <FormattedMessage {...messages.titleQuestion2FAQ} />,
  question3: <FormattedMessage {...messages.titleQuestion3FAQ} />,
  question4: <FormattedMessage {...messages.titleQuestion4FAQ} />,
  question5: <FormattedMessage {...messages.titleQuestion5FAQ} />,
  answer1: <FormattedMessage {...messages.titleAnswer1FAQ} />,
  answer2: <FormattedMessage {...messages.titleAnswer2FAQ} />,
  answer3: <FormattedMessage {...messages.titleAnswer3FAQ} />,
  answer4: <FormattedMessage {...messages.titleAnswer4FAQ} />,
  answer5: <FormattedMessage {...messages.titleAnswer5FAQ} />,
};
const FAQWrap = styled.div`
  padding: 64px 0;
  position: relative;
  background-color: #FAFBFB;
  &::before{
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    background-color: #FAFBFB;
  }
  &::before {
    width: 100vw;
    left: 50%;
    transform: translateX(-50%);
  }
  
  .title {
    color: #3D4145;
    font-size: 26px;
    font-weight: bold;
    line-height: 36px;
    margin: 0 0 24px;
    position: relative;
  }
  .item {
    position: relative;
    padding-left: 32px;
    padding-bottom: 24px;
  }
  .question {
    color: #3D4145;
    font-size: 16px;
    font-weight: bold;
    padding-bottom: 6px;
    cursor: pointer;
  }
  .answer {
    opacity: 0.6;
    color: #3D4144;
    font-size: 14px;
    padding-bottom: 12px;
  }
`;

const stylesIcon = {
  style: {
    position: 'absolute',
    left: 0,
    top: 0,
    opacity: 0.6,
    color: colors.grayBg,
  },
};
const stylesIconActive = {
  style: {
    ...stylesIcon.style,
    transform: 'rotate(45deg)',
  },
};

class FAQ extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [
        {
          active: false,
          title: msg.question1,
          text: msg.answer1,
        },
        {
          active: false,
          title: msg.question2,
          text: msg.answer2,
        },
        {
          active: false,
          title: msg.question3,
          text: msg.answer3,
        },
        {
          active: false,
          title: msg.question4,
          text: msg.answer4,
        },
        {
          active: false,
          title: msg.question5,
          text: msg.answer5,
        },
      ],
    };
  }

  handleOpen(index) {
    const newList = this.state.list;
    newList[index].active = !newList[index].active;
    this.setState({ list: newList });
  }
  render() {
    const {
      className,
    } = this.props;
    const { list } = this.state;
    return (
      <FAQWrap className={className} >
        <h2 className="title" >{msg.titleFAQ}</h2>
        {
          list && list.map((item, index) => {
            const iconStyle = item.active ? stylesIconActive : stylesIcon;
            return (
            <div className="item" key={index} >
              <div className="question" onClick={this.handleOpen.bind(this, index)} >
                <Add {...iconStyle} />
                {item.title}
              </div>
              { item.active && <div className="answer" >{item.text}</div>}
            </div>
          );
        })
        }
      </FAQWrap>
    );
  }
}

FAQ.propTypes = {
  className: PropTypes.string,
  text: PropTypes.object,
  handleAddClick: PropTypes.func,
  disable: PropTypes.bool,
};

export default FAQ;

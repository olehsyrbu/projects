
import { defineMessages } from 'react-intl';

export default defineMessages({
  title: {
    id: 'app.components.SinglePage.HowItWorks.title',
    defaultMessage: 'How to make an offer easily',
  },
  title1: {
    id: 'app.components.SinglePage.HowItWorks.title1',
    defaultMessage: 'After receiving a group request click the{link}button',
  },
  title2: {
    id: 'app.components.SinglePage.HowItWorks.title2',
    defaultMessage: '{link}offer for your available room types',
  },
  title3: {
    id: 'app.components.SinglePage.HowItWorks.title3',
    defaultMessage: '{link}with agency and manage reservation',
  },
  title1HighLight: {
    id: 'app.components.SinglePage.HowItWorks.title1HighLight',
    defaultMessage: 'Make offer',
  },
  title2HighLight: {
    id: 'app.components.SinglePage.HowItWorks.title2HighLight',
    defaultMessage: 'Enter a price',
  },
  title3HighLight: {
    id: 'app.components.SinglePage.HowItWorks.title3HighLight',
    defaultMessage: 'Connect',
  },
  text1: {
    id: 'app.components.SinglePage.HowItWorks.subtitle1',
    defaultMessage: 'Instead of having to write e-mails, make an offer earsily with a few clickis.',
  },
  text2: {
    id: 'app.components.SinglePage.HowItWorks.subtitle2',
    defaultMessage: 'You only have to enter your hotel conditions once, they are then saved for all future reservations.',
  },
  text3: {
    id: 'app.components.SinglePage.HowItWorks.subtitle3',
    defaultMessage: 'When an agency chooses your offer, you will receive a confirmation email and contact details of Davinci manager who will be there to finalise details of the reservation.',
  },
  footer: {
    id: 'app.components.SinglePage.HowItWorks.footer',
    defaultMessage: 'For general inquiries: \nEmail: hotels@davincits.com \nPhone: +420 776 775 606 \n \nPlease reference the Session number when making \ninquiries about the reservation.',
  },

  titleShadow: {
    id: 'app.components.SinglePage.HowItWorks.titleShadow',
    defaultMessage: 'We’d like to help you!',
  },
  titleContactUs: {
    id: 'app.components.SinglePage.HowItWorks.titleContactUs',
    defaultMessage: 'Contact Us',
  },
  textContactUs: {
    id: 'app.components.SinglePage.HowItWorks.textContactUs',
    defaultMessage: 'We would love to talk to you about any questions you may have of the services that we offer.',
  },
  sideTitleContactUs: {
    id: 'app.components.SinglePage.HowItWorks.sideTitleContactUs',
    defaultMessage: 'For general inquiries',
  },
  sideTextContactUs: {
    id: 'app.components.SinglePage.HowItWorks.sideTextContactUs',
    defaultMessage: 'Please reference the Session number when making inquiries about the reservation.',
  },
  email: {
    id: 'app.components.SinglePage.HowItWorks.email',
    defaultMessage: 'Email',
  },
  phone: {
    id: 'app.components.SinglePage.HowItWorks.phone',
    defaultMessage: 'Phone',
  },
  titleFAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleFAQ',
    defaultMessage: 'FAQ',
  },
  titleQuestion1FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleQuestion1FAQ',
    defaultMessage: 'When will I receive the payment?',
  },
  titleQuestion2FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleQuestion2FAQ',
    defaultMessage: 'Whom should I contact?',
  },
  titleQuestion3FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleQuestion3FAQ',
    defaultMessage: 'When will I receive the rooming list?',
  },
  titleQuestion4FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleQuestion4FAQ',
    defaultMessage: 'Where can I enter my payment and cancellation conditions?',
  },
  titleQuestion5FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleQuestion5FAQ',
    defaultMessage: 'What is the nationality of my group of guests, and what is their reason for visiting?',
  },
  titleAnswer1FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleAnswer1FAQ',
    defaultMessage: 'After receiving and confirming the rooming list, you should then create an invoice for the accommodation and send it to our accounting department at accounting@davincits.com. The payment will be transferred to your account by the due date.',
  },
  titleAnswer2FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleAnswer2FAQ',
    defaultMessage: 'Once the tour operator has accepted your offer, you will receive an e-mail confirmation with contact details of your assigned Davinci manager. You can discuss all remaining details with them.',
  },
  titleAnswer3FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleAnswer3FAQ',
    defaultMessage: 'You will receive your rooming list with all necessary guest information 10 days before arrival.',
  },
  titleAnswer4FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleAnswer4FAQ',
    defaultMessage: 'Your cancellation policy as well as FOC (free of charge) and city tax can be filled in when entering your offer in the “Hotel conditions” section. You will be able to discuss payment conditions with your assigned Davinci manager after the reservation has been confirmed.',
  },
  titleAnswer5FAQ: {
    id: 'app.components.SinglePage.HowItWorks.titleAnswer5FAQ',
    defaultMessage: 'Your assigned Davinci manager will be able to give you more details on your group. Most groups are leisure groups unless stated otherwise.',
  },
});

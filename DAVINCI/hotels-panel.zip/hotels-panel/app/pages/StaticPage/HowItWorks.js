import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';

import messages from './messages';

import PageWrapper from 'app/common/PageWrapper/index';
import Content from 'app/common/PageWrapper/Content';
import ContactUs from './ContactUs';
import FAQ from './FAQ';

import { WrapContent, Text, Title, Block, BlockTitle, SubTitle, Media } from './style';

import block1 from './media/block1.svg';
import block2 from './media/block2.svg';
import block3 from './media/block3.svg';
import icon1 from './media/icon1.svg';
import icon2 from './media/icon2.svg';
import icon3 from './media/icon3.svg';

const msg = {
  title: <FormattedMessage {...messages.title} />,
  title1: <FormattedMessage {...messages.title1} values={{ link: <span className="highLight" ><FormattedMessage {...messages.title1HighLight} /></span> }} />,
  title2: <FormattedMessage {...messages.title2} values={{ link: <span className="highLight" ><FormattedMessage {...messages.title2HighLight} /></span> }} />,
  title3: <FormattedMessage {...messages.title3} values={{ link: <span className="highLight" ><FormattedMessage {...messages.title3HighLight} /></span> }} />,
  text1: <FormattedMessage {...messages.text1} />,
  text2: <FormattedMessage {...messages.text2} />,
  text3: <FormattedMessage {...messages.text3} />,
};

const HowItWorks = () => (
  <WrapContent>
    <PageWrapper>
      <Content style={{ boxSizing: 'border-box' }} >
        <Title>{msg.title}</Title>
        <Block>
          <BlockTitle>
            <img src={icon1} className="icon" />
            <SubTitle>{msg.title1}</SubTitle>
            <Text>{msg.text1}</Text>
          </BlockTitle>
          <Media>
            <img src={block1} />
          </Media>

        </Block>
        <Block>
          <BlockTitle>
            <img src={icon2} className="icon" />
            <SubTitle>{msg.title2}</SubTitle>
            <Text>{msg.text2}</Text>
          </BlockTitle>
          <Media>
            <img src={block2} />
          </Media>
        </Block>
        <Block>
          <BlockTitle>
            <img src={icon3} className="icon" />
            <SubTitle>{msg.title3}</SubTitle>
            <Text>{msg.text3}</Text>
          </BlockTitle>
          <Media>
            <img src={block3} />
          </Media>
        </Block>
        <FAQ />
        <ContactUs />
      </Content>
    </PageWrapper>
  </WrapContent>
);

HowItWorks.propTypes = {
  className: PropTypes.string,
};

export default HowItWorks;

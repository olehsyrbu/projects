import styled from 'styled-components';
import { colors } from 'app/style/variables';

export const WrapContent = styled.div`
  min-width: 780px;
`;

export const Title = styled.h1`
  margin: 12px 0 76px;
  padding-bottom: 8px;
  font-weight: 500;
  font-size: 40px;
  border-bottom: 1px solid #D4DCE4;
`;
export const Block = styled.div`
  position: relative;
  display: flex;
  position: relative;
  margin-bottom: 100px;
  counter-increment: s;
  &::before {
    content: counter(s);
    position: absolute;
    top: 0;
    left: -9px;
    font-weight: bold;
    color: ${colors.grayWhiteText};
    opacity: 0.4;
    font-size: 260px;
    line-height: 184px;
  }
  .icon {
    align-self: flex-start;
  }
`;
export const BlockTitle = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  padding-left: 70px;
  padding-bottom: 26px;
  width: 36%;
  box-sizing: border-box;
`;
export const SubTitle = styled.h2`
  margin: 0;
  font-weight: 700;
  line-height: 1.34;
  font-size: 26px;
  .highLight {
    padding: 6px;
    color: ${colors.blueText};
    background: ${colors.blue}20;
  }
`;
export const Media = styled.div`
  padding-bottom: 16px;
  text-align: center;
  margin-left: auto;
  max-width: 44%;
  img {
    max-width: 100%;
  }
`;
export const Text = styled.p``;

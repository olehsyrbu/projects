import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

const msg = {
  titleContactUs: <FormattedMessage {...messages.titleContactUs} />,
  titleShadow: <FormattedMessage {...messages.titleShadow} />,
  textContactUs: <FormattedMessage {...messages.textContactUs} />,
  sideTitleContactUs: <FormattedMessage {...messages.sideTitleContactUs} />,
  sideTextContactUs: <FormattedMessage {...messages.sideTextContactUs} />,
  email: <FormattedMessage {...messages.email} />,
  phone: <FormattedMessage {...messages.phone} />,
};
import HotelProvider from 'app/providers/Requests/HotelProvider';

const ContactUsWrap = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  .shadow {
    color: ${colors.grayWhiteText};
    opacity: 0.4;
    font-size: 64px;
    font-weight: bold;
    line-height: 72px;
    text-shadow: 0 0 20px 0 #ECF1F6;
    position: absolute;
    top: 34%;
    left: 0;
  }
  .aside {
    position: relative;
    max-width: 320px;
    
  }
  .title {
    color: #3D4145;
    font-size: 26px;
    font-weight: bold;
    line-height: 36px;
    margin: 0 0 8px;
  }
  .text {
    opacity: 0.6;
    color: #3D4145;
    font-size: 14px;
    line-height: 24px;
    margin: 0 0 12px;
    .light {
      color: ${colors.blueText};
    }
  }
  .side {
    z-index: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-left: auto;
    text-align: center;
    padding: 20px 64px;
    height: 366px;
    width: 444px;
    border-radius: 2px;
    background-color: #FFFFFF;
    box-shadow: 0 16px 60px 2px rgba(0,0,0,0.09), 0 6px 30px 5px rgba(0,0,0,0.12), 0 8px 10px 0 rgba(0,0,0,0.2);
    box-sizing: border-box;
  }
  .small-title {
    font-size: 16px;
  }
`;
import iconFooter from './media/iconFooter.svg';
import { adopt } from 'react-adopt';

class ContactUs extends React.PureComponent {
  render() {
    const {
      className,
      hotelQuery: { name },
    } = this.props;
    return (
      <ContactUsWrap className={className}>
        <span className="shadow" >{msg.titleShadow}</span>
        <div className="aside" >
          <h2 className="title" >{msg.titleContactUs}</h2>
          <p className="text" >{msg.textContactUs}</p>
        </div>
        <div className="side" >
          <img src={iconFooter} className="icon" />
          <h2 className="title small-title" >{msg.sideTitleContactUs}</h2>
          <p className="text" >{msg.sideTextContactUs}</p>
          <p className="text" >{msg.email}:
            <a href={`mailto:hotels@davincits.com?subject=Inquiry from HOTEL ${name}`} className="light" >hotels@davincits.com</a>
          </p>
          <p className="text" >{msg.phone}: <span className="light" >+420 776 775 606</span></p>
        </div>
      </ContactUsWrap>
    );
  }
}

ContactUs.propTypes = {
  className: PropTypes.string,
};

const Composed = adopt({
  hotelQuery: HotelProvider,
});

export default props => (
  <Composed>
    {data => (
      <ContactUs {...data} {...props} />
    )}
  </Composed>
);

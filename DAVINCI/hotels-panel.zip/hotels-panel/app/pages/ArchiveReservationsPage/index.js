import React from 'react';
import { adopt } from 'react-adopt';

import { getArchiveReservations } from 'app/utils/sessions';

import AllReservationsProvider from 'app/providers/Reservations/AllReservationsProvider';
import Archive from 'app/common/Archive';
import Loading from '../../common/Loading/LoadingWrapPage';
import SentryGraph from '../../utils/sentryGraphUtil';
import DialogError from '../../common/Errors/DialogError';

const ArchiveReservationsPage = ({ reservations: { data, loading, error }, ...props }) => {
  if (loading) return (<Loading />);
  if (error) {
    SentryGraph(error);
    return (<DialogError error={error} />);
  }
  return (
    <Archive sessions={getArchiveReservations(data.reservations)} {...props} />
  );
};

const Composed = adopt({
  reservations: AllReservationsProvider,
});

export default () => (
  <Composed>
    {props => (<ArchiveReservationsPage {...props} />)}
  </Composed>
);


import React from 'react';
import { adopt } from 'react-adopt';
import Reservations from 'app/common/Reservations';

import AllReservationsProvider from 'app/providers/Reservations/AllReservationsProvider';
import CurrencyProvider from 'app/providers/Requests/CurrencyProvider';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import { getSessionForConfirmedReservationPage } from 'app/utils/sessions';
import Loading from 'app/common/Loading/LoadingWrapPage';
import SentryGraph from 'app/utils/sentryGraphUtil';
import DialogError from 'app/common/Errors/DialogError';
import i18n from 'app/utils/i18n';

const ConfirmedReservationsPage = ({ reservations: { data, loading, error }, hotelQuery, currencies }) => {
  if (loading) {
    return (<Loading />);
  }
  if (error) {
    SentryGraph(error);
    return (<DialogError error={error} />);
  }
  return (
    <Reservations
      reservations={getSessionForConfirmedReservationPage(data.reservations)}
      hotelQuery={hotelQuery}
      currencies={currencies}
      textEmptyData={i18n('app.components.Reservations.emptyConfirmed')}
    />
  );
};

ConfirmedReservationsPage.displayName = 'ConfirmedReservationsPage';

const Composed = adopt({
  currencies: CurrencyProvider,
  hotelQuery: HotelProvider,
  reservations: AllReservationsProvider,
});

export default props => (
  <Composed>
    {data => (
      <ConfirmedReservationsPage {...data} {...props} />
    )}
  </Composed>
);

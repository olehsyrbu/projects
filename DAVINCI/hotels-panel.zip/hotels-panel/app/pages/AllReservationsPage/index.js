import React from 'react';
import { adopt } from 'react-adopt';
import Reservations from 'app/common/Reservations';

import AllReservationsProvider from 'app/providers/Reservations/AllReservationsProvider';
import CurrencyProvider from 'app/providers/Requests/CurrencyProvider';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import { getAllReservationSessions } from 'app/utils/sessions';
import Loading from 'app/common/Loading/LoadingWrapPage';
import i18n from 'app/utils/i18n';

const AllReservationsPage = ({ reservations: { data, loading, error }, hotelQuery, currencies }) => {
  if (loading) {
    return (<Loading />);
  }
  if (error) throw new Error(error);
  return (
    <Reservations
      reservations={getAllReservationSessions(data.reservations)}
      hotelQuery={hotelQuery}
      currencies={currencies}
      textEmptyData={i18n('app.common.Reservations.headerAllReservationsTitle')}
    />
  );
};

AllReservationsPage.displayName = 'AllReservationsPage';

const Composed = adopt({
  hotelQuery: HotelProvider,
  currencies: CurrencyProvider,
  reservations: AllReservationsProvider,
});

export default props => (
  <Composed>
    {data => (
      <AllReservationsPage {...data} {...props} />
    )}
  </Composed>
);

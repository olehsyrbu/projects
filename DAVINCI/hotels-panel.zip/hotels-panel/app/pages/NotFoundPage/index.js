import React from 'react';
import Base from '../BasePage';
import Page404 from 'app/common/Errors';
import { withRouter } from 'react-router-dom';
import { redirectToNewRequestsPage } from 'app/utils';
import * as Sentry from '@sentry/browser';
import i18n from 'app/utils/i18n';
import styled from 'styled-components';

const PageWrap404 = styled.div`
  min-width: 1400px !important;
  padding: 0 calc((107vw - 1160px)/2);
`;

class NotFound extends React.PureComponent {
  componentDidMount() {
    Sentry.captureMessage(`Page not found! href: [${location}], for Hotel:${localStorage.getItem('hotel')}`);
  }

  render() {
    return (
      <Base>
      <PageWrap404>
        <Page404
          code="404"
          title={i18n('app.components.Error.title404')}
          text={i18n('app.components.Error.text404')}
          btnText={i18n('app.components.Error.btn404')}
          onClick={() => redirectToNewRequestsPage(this.props.history)}
        />
        </PageWrap404>
      </Base>
    );
  }
}

export default withRouter(NotFound);

import React from 'react';
import { adopt } from 'react-adopt';
import Reservations from 'app/common/Reservations';
import AllReservationsProvider from 'app/providers/Reservations/AllReservationsProvider';
import CurrencyProvider from 'app/providers/Requests/CurrencyProvider';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import { getCompletedSessions } from 'app/utils/sessions';
import Loading from 'app/common/Loading/LoadingWrapPage';
import SentryGraph from '../../utils/sentryGraphUtil';
import DialogError from '../../common/Errors/DialogError';
import { i18n } from '../../providers/LanguageProvider';

const CompletedReservations = ({ reservations: { data, loading, error }, hotelQuery, currencies }) => {
  if (loading) {
    return (<Loading />);
  }
  if (error) {
    SentryGraph(error);
    return (<DialogError error={error} />);
  }
  return (
    <Reservations
      reservations={getCompletedSessions(data.reservations)}
      hotelQuery={hotelQuery}
      currencies={currencies}
      textEmptyData={i18n('app.components.Reservations.emptyCompleted')}
    />
  );
};

CompletedReservations.displayName = 'CompletedReservations';

const Composed = adopt({
  currencies: CurrencyProvider,
  hotelQuery: HotelProvider,
  reservations: AllReservationsProvider,
});

export default props => (
  <Composed>
    {data => (
      <CompletedReservations {...data} {...props} />
    )}
  </Composed>
);

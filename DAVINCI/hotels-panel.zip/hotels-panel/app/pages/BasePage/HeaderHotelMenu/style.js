import styled from 'styled-components';
import { colors } from '../../../style/variables';

export const labelStyleDrop = {
  color: `${colors.grayWhite}`,
  opacity: '.9',
  top: 0,
  lineHeight: '70px',
  height: '72px',
  paddingLeft: '10px',
};

export const menuStyleDrop = {
  background: 'white',
};

export const listStyleDrop = {
  padding: '0 !important',
  paddingBottom: '0 !important',
  paddingTop: '0 !important',
};

export const menuItemStyleDrop = {
  borderBottom: '1px solid #dedede',
  padding: '10px 0px',
};

export const iconStyleDrop = {
  fill: '#F5F5F5',
  opacity: '.5',
  height: '62px',
};

export const underlineStyleDrop = {
  border: 'none',
};

export const styleDrop = {
  height: '72px',
  display: 'flex',
  maxWidth: '250px',
};

export const selectedMenuItemStyleDrop = {
  color: `${colors.grayDarkText}`,
};

export const WrapAvatar = styled.div`
  display: flex;
  height: 72px;
  vertical-align: middle;
  align-items: center;
`;

export const WrapHotelName = styled.div`
  color: ${colors.grayWhite};
  opacity: .9
  display: table-cell;
  height: 72px;
  line-height: 72px;
  vertical-align: middle;
  padding-left: 10px;
  align-items: center;
`;

import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { initIntercom } from 'app/utils/global-constant';

import { adopt } from 'react-adopt/dist/index';
import HotelProvider from 'app/providers/Requests/HotelProvider';

import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';

import Avatar from 'app/common/Avatar';
import Flex from 'app/common/design/Flex';
import { setAccessToken } from 'app/utils';
import './style.scss';

import {
  iconStyleDrop,
  labelStyleDrop,
  listStyleDrop,
  menuStyleDrop,
  styleDrop,
  menuItemStyleDrop,
  underlineStyleDrop,
  selectedMenuItemStyleDrop,
  WrapAvatar,
  WrapHotelName,
} from './style';

class HeaderHotelMenu extends PureComponent {
  constructor(props, context) {
    super(props, context);
    this.state = this.getInitState(props.hotel);

    if (props.hotel && props.hotel.name) {
      localStorage.setItem('hotel', props.hotel.name);
    }

    initIntercom(props.hotel);
    this.handleChangeHotel = this.handleChangeHotel.bind(this);
  }

  getInitState = (hotel) => {
    const { groupMembers, name, media = {} } = hotel || {};
    const hotels = groupMembers ? this.modifyGroupMembers(groupMembers) : [];
    const selected = this.getSelected(name, hotels);

    return {
      name,
      hotels,
      srcLogo: media.logo,
      selected: selected ? selected.value : null,
    };
  };

  getSelected = (name, hotels = []) => hotels.find(member => member.name === name);

  modifyGroupMembers = (groupMembers) => {
    const groupMembersHotels = groupMembers || [];
    return groupMembersHotels
      .filter(({ token }) => token !== null)
      .map((hotel, i) => ({ ...hotel, label: hotel.name, value: i }));
  };

  handleChangeHotel = (e, i, v) => {
    const { hotels } = this.state;
    const { _id, token } = hotels[v];
    setAccessToken(_id, token);
    window.location.href = `${location.origin}/requests?access-token=${token}`;
    localStorage.removeItem('selectedNewLanguage');
    localStorage.removeItem('selectedNewFlag');
  };

  render() {
    const {
      srcLogo, name, hotels, selected,
    } = this.state;

    return (
      <Flex>
        <WrapAvatar>
          <Avatar src={srcLogo} size={40} name={!srcLogo && name} />
        </WrapAvatar>
        {hotels && hotels.length === 0
          ? <WrapHotelName>
            {name}
          </WrapHotelName>
          : <DropDownMenu
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
            selectedMenuItemStyle={selectedMenuItemStyleDrop}
            style={styleDrop}
            underlineStyle={underlineStyleDrop}
            iconStyle={iconStyleDrop}
            menuStyle={menuStyleDrop}
            labelStyle={labelStyleDrop}
            menuItemStyle={menuItemStyleDrop}
            listStyle={listStyleDrop}
            maxHeight={319}
            value={selected}
            onChange={this.handleChangeHotel}
          >
            {hotels.map(({ value, label, media }) => (
              <MenuItem
                className="menu-item"
                value={value}
                key={value}
                primaryText={label}
                leftIcon={
                  <Avatar src={media.logo} size={25} name={!media.logo && label} />
                }
              />
            ))}
          </DropDownMenu>
        }
      </Flex>
    );
  }
}

HeaderHotelMenu.propTypes = {
  hotel: PropTypes.object,
};

const Composed = adopt({
  hotel: HotelProvider,
});

export default props => (
  <Composed>
    {data => (<HeaderHotelMenu {...props} {...data} />)}
  </Composed>
);

import styled from 'styled-components';

export const LeftHeaderItems = styled.div`
  display: flex;
`;

export const RightHeaderItems = styled.div`
  justify-content: flex-end;
  margin-left: auto;
`;
export const HeaderWrap = styled.header`
    position: fixed;
    z-index: 999;
    width: 100%;
    display: flex;
    background-color: ${({ theme }) => theme.grayDark};
    padding: 0 calc((106vw - 1160px)/2);
    @media (min-width: 1550px) {
      padding: 0 calc((100vw - 1232px)/2);
    }
`;
export const CollapseLeftItems = styled.div`
  @media screen and (max-width: 780px) {
    position: fixed;
    background-color: #000;
    top: 71px;
    left: 0;
    right: 0;
    padding-left: 2em;
  }
`;
export const CollapseRightItems = styled.div`
  display: flex;
  position: relative;
  @media screen and (max-width: 780px) {
  }
`;

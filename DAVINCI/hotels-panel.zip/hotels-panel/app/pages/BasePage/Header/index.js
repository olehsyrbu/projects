import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';

import Hotel from 'app/pages/BasePage/HeaderHotelMenu';
import Logo from 'app/pages/BasePage/Logo';
import Menu from 'app/pages/BasePage/Menu';
import LocalizationSwitcher from 'app/common/LocalizationSwitcher';
import { changeLocale } from 'app/providers/LanguageProvider/actions';
import { getAccessToken, getHotelId } from 'app/utils';
import { LeftHeaderItems, RightHeaderItems, HeaderWrap, CollapseLeftItems, CollapseRightItems } from './style';

class Header extends PureComponent {
  componentDidMount() {
    const { history } = this.props;
    const { pathname, href } = window.location;
    let hotelId = getHotelId();

    if (!hotelId) {
      getAccessToken();
      hotelId = getHotelId();
    }

    if (href.includes('access-token')) {
      const token = href.split('access-token=')[1];
      const tokens = localStorage.getItem('access-token');
      localStorage.setItem('access-token', JSON.stringify({ [hotelId]: token, ...JSON.parse(tokens) }));
    }

    if (pathname.startsWith('/requests') || href.includes('access-token') || pathname === '/' || pathname === '') {
      if (hotelId === null) {
        history.push('/signin');
        return;
      }

      let newUrl = `/${hotelId}/requests/new`;

      let sessionId = null;
      const link = pathname.split('/requests/')[1];
      if (link) {
        sessionId = link.split('/')[0] ? link.split('/')[0] : link;
      }

      newUrl = sessionId ? `${newUrl}/${sessionId}` : newUrl;
      history.push(newUrl);
    }

    const DOUBLE_SLASH_REGEX = /\/{2,}/g;
    if (DOUBLE_SLASH_REGEX.test(pathname)) {
      window.location.replace(href.replace(pathname, pathname.replace(DOUBLE_SLASH_REGEX, '/')));
    }
  }

  handleChangeLocale = (selected) => {
    const { onChangeLocale } = this.props;
    localStorage.setItem('selectedNewFlag', selected);
    onChangeLocale(selected);
  };

  render() {
    return (
      <HeaderWrap fixedTop >
        <LeftHeaderItems>
          <Logo />
          <CollapseLeftItems>
            <Menu />
          </CollapseLeftItems>
        </LeftHeaderItems>
        <RightHeaderItems>
          <CollapseRightItems>
            <LocalizationSwitcher
              size={20}
              onChangeLanguage={this.handleChangeLocale}
            />
            <Hotel />
          </CollapseRightItems>
        </RightHeaderItems>
      </HeaderWrap>
    );
  }
}

Header.propTypes = {
  onChangeLocale: PropTypes.func,
  params: PropTypes.object,
  newRequestsQuery: PropTypes.object,
};

const mapDispatchToProps = dispatch => ({
  onChangeLocale: params => dispatch(changeLocale(params)),
});

export default connect(null, mapDispatchToProps)(withRouter(Header));

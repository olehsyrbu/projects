import { defineMessages } from 'react-intl';

export default defineMessages({
  support: {
    id: 'app.components.footer.support',
    defaultMessage: 'Support',
  },
  phone: {
    id: 'app.components.footer.phone',
    defaultMessage: 'Phone',
  },
  mobile: {
    id: 'app.components.footer.mobile',
    defaultMessage: 'Mob:',
  },
  skype: {
    id: 'app.components.footer.skype',
    defaultMessage: 'Skype',
  },
  email: {
    id: 'app.components.footer.email',
    defaultMessage: 'Email',
  },
  chat: {
    id: 'app.components.footer.chat',
    defaultMessage: 'Chat',
  },
  terms: {
    id: 'app.components.footer.terms',
    defaultMessage: 'Terms & Conditions',
  },
});

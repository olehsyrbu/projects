import styled from 'styled-components';
import { colors } from 'app/style/variables';

export const LinkStyle = styled.a`
  &, :visited, :link, :hover{
    color: ${colors.brandPrimary} !important;
  }
  font-weight: bold;
  text-transform: uppercase;
  margin-right: 10px;
`;

export const FooterWrap = styled.footer`
  flex: 0 0 auto;
  position: fixed;
  bottom: 0;
  display: block;
  background-color: ${colors.light};
  font-size: 14px;
  width: 100%;
  border-top: 1px solid ${colors.grayWhiteText};
  margin-top: auto;
  z-index: 999;
  padding: 10px calc((96vw - 1160px)/2);
  @media (min-width: 1550px) {
    padding: 10px calc((95vw - 1232px)/2);
  }
  & > span {
    padding-right: 16px;
  }
  .footer-text {
    text-transform: uppercase;
    font-weight: 500;
  }
  a, a:focus, a:link {
    color: ${colors.grayBg};
    text-decoration: none;
    b {
      color: ${colors.blue};
    }
    :hover {
      color: ${colors.grayBg};
      text-decoration: none;
      b {
        color: ${colors.blue};
      }
    }
  }
`;

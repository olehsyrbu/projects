import React from 'react';
import { FormattedMessage } from 'react-intl';

import messages from './messages';
import { email, mobile, phone } from './constants';
import { FooterWrap, LinkStyle } from './style';

const Footer = () => (
  <FooterWrap>
    <span className="footer-text"><FormattedMessage {...messages.support} />:</span>
    <span>
      <a href={`tel:${phone}`}>
        <FormattedMessage {...messages.phone} />: <b>{phone}</b>
      </a>
    </span>
    <span>
      <a href={`tel:${mobile}`}>
        <FormattedMessage {...messages.mobile} />: <b>{mobile}</b>
      </a>
    </span>
    <span>
      <a href={`mailto:${email}`}>
        <FormattedMessage {...messages.email} />: <b>{email}</b>
      </a>
    </span>
    <LinkStyle target="_blank" href="/terms">
      <FormattedMessage {...messages.terms} />
    </LinkStyle>
  </FooterWrap>
);

export default Footer;

export const phone = '+44 203 807 73 40';
export const mobile = '+420 776 775 606';
export const email = 'hotels@davincits.com';

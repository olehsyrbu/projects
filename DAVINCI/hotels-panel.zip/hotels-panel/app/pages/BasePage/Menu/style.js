import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

export const Menu = styled.div`
    display: inline-flex;
    vertical-align: top;
    line-height: 61px;
    > a:hover {
      color:  ${colors.light} !important;
      text-decoration: none !important;
    }
`;

export const TitleWrap = styled.div`
  font-size: ${font.m};
  text-transform: uppercase;
  letter-spacing: 0.5px;
  line-height: 16px;
  color: ${colors.light}
`;

export const SubMenuWrap = styled.div`
  display: flex;
  flex: 1;
  flex-direction: row;
  width: 100%;
  padding: 0px calc((100vw - 1060px)/2) 0px calc((100vw - 1060px)/2);
  border-bottom: none;
  background: rgb(55,55,55);
  position: fixed;
  height: 81px;
  z-index: 4;
  left: 0;
`;

export const Count = styled.sup`
  background-color: ${colors.red};
  color: ${colors.light};
  padding: 0 3px;
  margin-left: 4px;
  border-radius: 3px;
  font-size: 0.75em;
`;

export const Item = styled.div`
  display: flex;
  align-items: center;
  height: 85px;
  padding: 0 22px;
  border-bottom: 1px solid ${colors.grayBg};
  &.is-active,
  &:hover {
    background-color: ${colors.grayWhiteText};
  }
  span {
    display: inline-flex;
    align-items: center;
    margin-left: auto;
    &.is-marked {
      &:before {
        content: '';
        border-radius: 50%;
        background-color: ${colors.blue};
        width: 0.75em;
        height: 0.75em;
        margin-right: 6px;
      }
    }
  }
`;

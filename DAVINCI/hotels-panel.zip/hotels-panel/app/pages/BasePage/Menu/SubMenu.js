import React from 'react';
import { NavLink } from 'react-router-dom';
import { NavItem } from 'reactstrap';
import { Count, TitleWrap, SubMenuWrap } from './style';
import { ImgBody, ImgWrap } from 'app/common/design/ImageSvg';
import NavStyle from 'app/common/design/NavStyle';

// eslint-disable-next-line react/prefer-stateless-function
class SubMenu extends React.Component {
  render() {
    const { tabs, path, sessionsSize } = this.props;
    return (
      <div className="sub-menu">
        <NavStyle>
          <SubMenuWrap>
            {tabs && tabs.map(subItem => (
              <NavItem key={subItem.url} >
                <NavLink
                  className="subMenuTabActive"
                  activeClassName="active"
                  to={`${path}/${subItem.url}`}
                >
                  <ImgWrap>
                    <ImgBody src={subItem.img} className="imgWrap" />
                  </ImgWrap>
                  <TitleWrap className="textSubMenu">
                    {subItem.title}
                    {subItem.isShowNewSessionsSize && sessionsSize > 0 && <Count>{sessionsSize}</Count>}
                  </TitleWrap>
                </NavLink>
              </NavItem>
            ))}
          </SubMenuWrap>
        </NavStyle>
      </div>
    );
  }
}

export default SubMenu;


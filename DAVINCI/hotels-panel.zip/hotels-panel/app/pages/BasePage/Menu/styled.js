
import styled from 'styled-components';
import { NavLink } from 'react-router-dom';
import { colors } from 'app/style/variables';

export const MenuItemWrap = styled.div``;

export const MenuItem = styled(NavLink)`
  display: block;
  font-size: 16px;
  text-decoration: none;
  color: ${colors.lightGray};
  opacity: .5;
  line-height: 70px;
  height: 72px;
  margin-left: 2em;

  &.active {
    color:${colors.light};
    border-bottom: 4px solid ${colors.orange};
    opacity: 1;
  }

  @media screen and (max-width: 1070px) {
    font-size: 14px;
  }
`;

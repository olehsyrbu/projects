import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { size, has } from 'lodash';
import { withRouter } from 'react-router-dom';
import { MenuItemWrap, MenuItem } from './styled';
import { getActiveSessions } from 'app/utils/sessions';

import { Menu, Count } from './style';
import SubMenu from './SubMenu';
import { adopt } from 'react-adopt';
import NewRequestProvider from 'app/providers/Requests/NewRequestsProvider';
import Loading from 'app/common/Loading';
import './styles.scss';
import { getHotelId, redirectToNewRequestsPage, redirectToAllReservationPage } from 'app/utils';
import { subscribeNewRequests } from 'app/graph/subscriptionsActions';
import i18n from 'app/utils/i18n';

import imgRequests from 'app/media/ic-requests.svg';
import imgSentReq from 'app/media/ic_sent.svg';
import imgSentArchive from 'app/media/ic_archive.svg';
import imgReservations from 'app/media/Ic_allreserv.svg';
import imgConfirmed from 'app/media/ic_confirm.svg';
import imgOptional from 'app/media/ic_optional.svg';
import imageAssignment from 'app/media/outline-assignment_turned_in.svg';

class MenuComponent extends Component {
  constructor(props) {
    super(props);
    this.componentCleanup = this.componentCleanup.bind(this);
    this.redirectToPage = this.redirectToPage.bind(this);
  }

  getTabsHeaderMenu = () => [
    {
      name: 'Requests',
      url: 'requests',
      requests: 0,
      subMenu: [
        {
          title: i18n('app.components.Requests.title'),
          url: 'new',
          img: imgRequests,
          isShowNewSessionsSize: true,
        },
        {
          title: i18n('app.components.SentOffers.title'),
          url: 'sent',
          img: imgSentReq,
        },
        {
          title: i18n('app.components.Archive.title'),
          url: 'archive',
          img: imgSentArchive,
        },
      ],
    },
    {
      name: 'Reservations',
      url: 'reservations',
      subMenu: [
        {
          title: i18n('app.common.Reservations.headerAllReservationsTitle'),
          url: 'all',
          img: imgReservations,
        },
        {
          title: i18n('app.components.SentOffers.OperatorConfirmThisReservation'),
          url: 'confirmed',
          img: imgConfirmed,
        },
        {
          title: i18n('app.components.Reservations.optionalTitle'),
          url: 'optional',
          img: imgOptional,
        },
        {
          title: i18n('app.components.Reservations.headerCompleted'),
          url: 'completed',
          img: imageAssignment,
        },
        {
          title: i18n('app.components.Archive.title'),
          url: 'archive',
          img: imgSentArchive,
        },
      ],
    },
    {
      name: 'HowItWorks',
      url: 'how_it_works',
    },
    {
      name: 'Settings',
      url: 'settings',
    },
  ];

  componentDidMount() {
    const { newRequestsQuery: { subscribeToMore } } = this.props;

    this.unsub = subscribeNewRequests(subscribeToMore)();
    window.addEventListener('beforeunload', this.componentCleanup);
  }

  shouldComponentUpdate() {
    this.redirectToPage();
    return true;
  }

  componentCleanup() {
    this.unsub && this.unsub();
  }

  redirectToPage = () => {
    const { history } = this.props;
    const { pathname } = history.location;
    if (pathname === '/' || pathname.endsWith('requests')) {
      redirectToNewRequestsPage(history);
    }
    if (pathname.endsWith('reservations')) {
      redirectToAllReservationPage(history);
    }
  };

  componentWillUpdate({ newRequestsQuery: { error } }) {
    if (error) throw new Error(error);
  }

  render() {
    const { hotelId, newRequestsQuery: { loading, newRequests } } = this.props;
    if (loading) return (<Loading />);
    const sessionsSize = size(getActiveSessions(newRequests, 'checkIn'));
    const isOpenOfferPage = location.href.endsWith('/offer');
    return (
      <Menu className="head-menu">
        {this.getTabsHeaderMenu().map(item => (
          <MenuItemWrap key={`navbar-menu-${item.name}`}>
            <MenuItem
              onClick={this.redirectToPage}
              activeClassName="active"
              className={item.subMenu ? 'have-submenu' : ''}
              to={`/${hotelId}/${item.url}`}
            >
              {i18n(`${item.name}`)}
              {has(item, 'requests') && !!sessionsSize && <Count>{sessionsSize}</Count>}
            </MenuItem>
            {!isOpenOfferPage && item.subMenu &&
              <SubMenu
                sessionsSize={sessionsSize}
                path={`/${hotelId}/${item.url}`}
                tabs={item.subMenu}
              />
            }
          </MenuItemWrap>
        ))}
      </Menu>
    );
  }
}

MenuComponent.propTypes = {
  hotelId: PropTypes.string,
  newRequestsQuery: PropTypes.object,
};

const Composed = adopt({
  newRequestsQuery: NewRequestProvider,
});

const MenuWithData = data => (<Composed>
  {props => (<MenuComponent {...props} {...data} hotelId={getHotelId()} />)}
</Composed>);

export default withRouter(MenuWithData);

import React from 'react';

import Header from 'app/pages/BasePage/Header';
import Footer from 'app/pages/BasePage/Footer';
import { Base, Body } from './style';
import UpdateChecker from 'app/common/UpdateChecker';
import ErrorBoundary from 'app/common/ErrorBoundary';
import { DialogsContainer, ToastrContainer } from 'app/ui';

const BasePage = ({ children }) => (
  <ErrorBoundary >
    <Base>
      <Header />
      <Body>
        {children}
      </Body>
      <UpdateChecker />
      <Footer />
      <ToastrContainer />
      <DialogsContainer />
    </Base>
  </ErrorBoundary>
);

BasePage.displayName = 'BasePage';

export default BasePage;

import styled from 'styled-components';

export const Base = styled.div`
 .nav-item{
   margin-bottom: 0;
   display: flex;
   flex-direction: column;

   a {
     text-decoration: none;
   }

   .textSubMenu{
     opacity: 0.5;
   }
   .active {
     color: #FFF !important;
     opacity: 1;
     font-weight: 500;
     .textSubMenu{
       opacity: 1;
     }
     .imgWrap{
       opacity: 1;
     }
   }
 }

 .nav-link{
   padding: .5rem 1rem !important;
   font-size: 14px;
   cursor: pointer;
   border-radius: 0;
   color: rgba(255, 255, 255, 0.5) !important;
   border: none;
   text-transform: uppercase;
   background: rgba(33, 33, 33, 0);
   font-weight: 500;
   letter-spacing: 0.5px;
   line-height: 16px;
 }

`;

export const Body = styled.div`
  //padding: 72px calc((107vw - 1160px)/2);
`;

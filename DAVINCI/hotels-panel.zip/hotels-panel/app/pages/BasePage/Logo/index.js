import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

import logo from '../Header/img/logo.svg';

const LinkedLogo = styled(Link)`
  display: flex;
  align-items: center;
  justify-content: center;
  padding-right: 10px;
  padding-left: 12px;
`;

export default () => (
  <LinkedLogo to="/">
    <img src={logo} alt="DaVinci" />
  </LinkedLogo>
);

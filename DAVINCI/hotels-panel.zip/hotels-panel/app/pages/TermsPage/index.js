import React, { PureComponent } from 'react'; // eslint-disable-line no-unused-vars
import { connect } from 'react-redux';
import Terms from './Terms';

export class TermsContainer extends PureComponent {
  render() {
    return (
      <Terms {...this.props} />
    );
  }
}

const mapDispatchToProps = () => ({});

const mapStateToProps = state => ({
  locale: state.language.toJS().locale,
});

export default connect(mapStateToProps, mapDispatchToProps)(TermsContainer);

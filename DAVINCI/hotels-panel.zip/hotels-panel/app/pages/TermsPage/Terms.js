import React, { PureComponent } from 'react'; // eslint-disable-line no-unused-vars
import Paper from 'material-ui/Paper';
import styled from 'styled-components';
import logo from 'app/media/logo.svg';
import { colors } from 'app/style/variables';
import TermsEn from './en';

const LogoContainer = styled.div`
padding: 50px;
`;
const Page = styled.div`
  position: relative;
  z-index: 11111;
  background: ${colors.grayText};
  padding: 50px;
  text-align: center;
  width: 100%;
`;
const PaperBlock = styled(Paper)`
    text-align: left;
    max-width: 1000px;
    margin: 0 auto;
    padding: 24px;
`;

export default class Terms extends PureComponent { // eslint-disable-line react/prefer-stateless-function
  render() {
    const { locale } = this.props;
    return (
      <Page>
        <LogoContainer>
          <img src={logo} alt="DaVinci" width="300" />
        </LogoContainer>
        <PaperBlock>
          {locale !== 'ru' && (
            <TermsEn />
          )}
        </PaperBlock>
      </Page>
    );
  }
}

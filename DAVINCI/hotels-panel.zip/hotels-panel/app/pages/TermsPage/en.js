import React from 'react';

export default function TermsRu() {
  return (
      <div>
        <p className="p1" >
          <span className="s1" >01.06</span ><span className="s2" >.2019 DAVINCIts.com: General Business Terms and Conditions </span >
        </p >
        <p className="p2" ><span className="s2" ><strong >
          <center>
GENERAL BUSINESS TERMS AND CONDITIONS
APPLICABLE TO THE RELATIONSHIP BETWEEN DAVINCI TS AND PROVIDERS of Accommodation Services
          </center>

 </strong ></span >
        </p >
        <p className="p2" >
          <span className="s2" ><strong ><center>
            Preamble
          </center></strong ></span ></p >
        <ol className="ol1" >
          <li className="li3" ><span className="s2" >These General Business Terms and Conditions which may be amended from time to time apply to all arrangements made between DAVINCI TS on the one side and individual Providers on the other side in respect of Services provided by us through the Platform, unless explicitly agreed in writing otherwise by us and the respective Provider. By dealing with us, you confirm that you have read these General Business Terms and Conditions and that you acknowledge them, unconditionally agree with them and undertake to abide by them at all times. These General Business Terms and Conditions set out the rights and obligations governing the relationship between us, DAVINCI TS, as an intermediary and operator of the Platform, and you, as the Provider.</span >
          </li >
          <li className="li3" ><span className="s2" >The Platform, its contents and infrastructure, and the online accommodation reservation service being provided on the Platform are owned, operated and provided by DAVINCI TS for commercial purposes solely and are subject to these General Business Terms and Conditions.</span >
          </li >
        </ol >
        <ol className="ol2" >
          <center><strong>I.</strong ><span className="s2" ><strong >Definitions</strong ></span ></center>
        </ol >
        <ol className="ol1" >
          <li className="li3" ><span className="s2" >Terms such as "<strong >DAVINCI TS", "we", "us"</strong > and <strong >"our"</strong > refer to DAVINCI travel system s.r.o., company ID no. 05277949, which is governed by the laws of the Czech Republic, and is seated at Pavla Bene&scaron;e 750/12, Letňany, Prague 9, 199 00, Czech Republic. </span >
          </li >
          <li className="li3" >
            <span className="s2" >"<strong >Platform</strong >" means the website <a href="http://www.davincits.com" ><span className="s3" >www.davincits.com</span ></a > through which the service is provided, and which is owned, operated, managed, administrated, maintained and/or hosted by DAVINCI TS. </span >
          </li >
          <li className="li3" >
            <span className="s2" > "<strong >Service</strong >" means the mediation of Accommodation Services (including mediation of payments) between Providers and Clients.</span >
          </li >
          <li className="li3" >
            <span className="s2" >"<strong >Provider</strong >" means providers of accommodation services (at accommodation facilities such as hotels, motels, apartments, bed &amp; breakfasts, etc.), who provide these services as a part of their business.</span >
          </li >
          <li className="li3" >
            <span className="s2" ><strong >&ldquo;Accommodation services"</strong > means the services given by a Provider. </span >
          </li >
          <li className="li3" ><span className="s2" >"<strong >Client&ldquo;</strong > means an entrepreneur – a natural or a legal person as separate economic entities interested in mediation of Accommodation Services purchased from Providers through the Platform.</span >
          </li >
          <li className="li3" >
            <span className="s2" ><strong >"End-Customer"</strong > means a customer, an Interested person, who uses accommodation services.</span >
          </li >
          <li className="li3" ><span className="s2" ><strong >"Administrative Fee"</strong > means the DAVINCI TS's commission for mediation of Accommodation Services and the costs of related transactions. The amount of commission for a particular case is always determined by DAVINCI TS. </span >
          </li >
          <li className="li3" ><span className="s2" ><strong >"Terms"</strong > means these General Business Terms and Conditions.</span >
          </li >
        </ol >
        <p className="p6" >&nbsp;</p >
        <ol className="ol2" >
          <center><strong > II.</strong ><span className="s2" ><strong >Scope of Our Services </strong ></span ></center>
        </ol >
        <ol className="ol1" >
          <li className="li7" ><span className="s2" >DAVINCI TS provides the online Platform through which it offers mediation of Providers‘ Accommodation Services to Clients. By making a reservation via DAVINCITS.COM, the Client enters into a direct (legally binding) contractual relationship with the Provider where the Client makes a reservation or orders a product or service (as appropriate). From the very first moment the Client makes a reservation, DAVINCI TS has a status of an intermediary between such Client and the respective Provider. DAVINCI TS transfers information about reservations made by the Clients to the Providers and sends to the Clients emails on behalf of the Providers confirming the reservations. </span >
          </li >
          <li className="li7" ><span className="s2" >The Provider agrees that we may publish on our Platform or otherwise information that is based on information provided by Providers on their websites for the purposes of providing Services. The Provider bears at all times full responsibility for the accuracy, completeness and correctness of descriptive, pictorial and other information displayed on the Provider's website or provided to us by any means.</span >
          </li >
          <li className="li7" ><span className="s2" >The Provider explicitly agrees that DAVINCI TS may distribute on the Platform the offers provided by the Provider to the Clients.</span >
          </li >
          <li className="li7" ><span className="s2" >We provide the Services exclusively for commercial purposes. Therefore, the Provider may not disclose the offered prices of Accommodation Services to the End-Customers, or use, copy, monitor (such as through spiders or scraping techniques), display, download and reproduce the content, information, software, reservations, products and services available on our Platform for any commercial or competitive purposes.</span >
          </li >
        </ol >
        <p className="p8" >&nbsp;</p >
        <ol className="ol2" >
          <center><strong > III.</strong ><span className="s2" ><strong >Main Obligations of the Parties</strong ></span ></center>
        </ol >
          <ol className="li3" >
            <li>
              <span className="s2" >DAVINCI TS undertakes to</span >
              <ol>
                <li type="a">
                  ensure that the Provider enters into a direct (legally binding) contractual relationship with the Client;
                </li>
                <li type="a">
                  comply with all reasonable and lawful instructions of the Provider concerning the marketing and advertisement of the rooms;
                </li>

                <li type="a">
                  inform the Provider of the Clients which have booked the rooms with the Provider as a result of offering the rooms on the Platform; and
                </li>
                <li type="a">
                  collect the amounts due from the Clients on behalf of the Provider and to pay the amounts due to the Provider in accordance with these Terms.
                </li>
              </ol>
            </li>
            <li>
              <span className="s2" >The Provider undertakes to:</span >
              <ol>
                <li type="a">
                  provide End-Customers with the room type, board basis and all other inclusions as described in the confirmed reservation;
                </li>
                <li type="a">
                  promptly and efficiently respond to any substantial queries from DAVINCI TS in order to maximize potential bookings;

                </li>
                <li type="a">
                  promptly and efficiently deal with any substantial complaints or enquiries it receives from the End-Customer and/or the Client whilst the End-Customer is at the accommodation facility or after the departure of the End-Customer, including those received by DAVINCI TS. Failure to comply with this clause may result in DAVINCI TS withholding payment or part-payment of affected bookings in order to provide compensation to the End-Customer and/or the Client;
                </li>
                <li type="a">
                  comply with all applicable laws, regulations, rules and codes of conduct, including (but not limited to) laws on health and safety, laws on protection of personal data and on fair trading regulations;
                </li>
                <li type="a">
                  hold DAVINCI TS harmless and keep DAVINCI TS indemnified against (i) any liability arising from the failure of the Provider to comply with the provisions of the agreement concluded between the Provider and DAVINCI TS, (ii) any liability arising from the Provider’s failure to perform or properly perform its contract with the Client, and (iii) any liability arising from the failure of the Provider to comply with any applicable laws, regulations, rules and codes of conduct;
                </li>
                <li type="a">
                  to have liability insurance policy with sufficient limits in place at all times and to maintain the validity of such liability insurance policy for the whole duration of the contractual arrangement between the Provider and DAVINCI TS; and

                </li>
                <li type="a">
                  to refrain from directly offering to the same Client identical rates and policies that have already been offered to such Client via the Platform as long as the offer is still valid on the Platform; if the Provider breaches this obligation, DAVINCI TS shall become entitled to the payment of a contractual penalty amounting to 500 Euro by the Provider per each breach.
                </li>
              </ol>
            </li>

          </ol>
        <p className="p9" >&nbsp;</p >
        <ol className="ol2" >
            <strong > IV.</strong ><span className="s2" ><strong >Price of Accommodation Services, Payment and Taxes</strong ></span >
        </ol >
        <p className="p5" >&nbsp;</p >
        <ol className="ol1" >
          <li className="li7" ><span className="s2" >The prices of Accommodation Services which we offer to mediate on our Platform are wholesale and very favorable. The Provider agrees that the rates for the offers that it makes available to DAVINCI TS are Net Rates, i.e. all room rates (per room and per the whole stay) include breakfast, VAT, turnover tax and Administrative Fees, unless explicitly stated otherwise on our Platform or in the email confirming the reservation made by the Client. Prices are valid for orders of nine (9) or more rooms. If the number of rooms reserved is changed to less than nine (9) rooms, the Provider is entitled to change the price of Accommodation Services. The breakfast type shall be indicated in the reservation details. The Client must be informed in advance and in time during the booking process if breakfast is not included in the price of Accommodation Services.</span >
          </li >
          <li className="li7" ><span className="s2" >The Provider acknowledges and agrees that all payments for the Accommodation Services will be collected by DAVINCI TS from the Client and will be paid out to the Provider according to the agreement concluded between DAVINCI TS and the Provider, these Terms and applicable payment and cancellation policies.</span ></li >
          <li className="li7" ><span className="s2" >DAVINCI TS is entitled to deduct the Administrative Fee from payments for the Accommodation Services received by DAVINCI TS from the Client and keep such Administrative Fee. </span ></li >
          <li className="li7" ><span className="s2" >DAVINCI TS will pay the amounts collected from the Client as payments for the Accommodation Services (after deduction of the Administrative Fee) to the Provider after the final Rooming List is confirmed between the Client and the Provider. The final Rooming List will be uploaded and confirmed in the Platform.</span ></li >
          <li className="li7" ><span className="s2" >Payments from DAVINCI TS to the Provider may be completed by DAVINCI TS via the following payment methods: bank transfer, online credit card payment, or cash.</span ></li >
          <li className="li7" ><span className="s2" >In no circumstances shall the Provider charge the Client or the End-Customers for any booking or arrangements booked through the Platform as these sums are collected by DAVINCI TS on behalf of the Provider from the Client and then paid to the Provider in accordance with these Terms. The Client and/or the End-Customers shall be solely responsible for payment of all incidental charges that they may incur in excess of the confirmed booking. DAVINCI TS shall not be responsible for the payment, collection or billing of such incidentals.</span ></li >
          <li className="li7" ><span className="s2" >The Provider shall specify if a tourist tax, city tax or any other extra charges are included or excluded in the rate. The Provider shall specify it in each request via the Platform. If the price of Accommodation Services does not include applicable tourist tax, city tax or any other extra charges, the Provider is responsible for charging the Client and/or the End-Customers for such amounts separately at the accommodation facility. If the amounts are not paid to the Provider, DAVINCI TS is entitled to add the respective amounts to the price of Accommodation Services charged to the Client by DAVINCI TS. In cases where the applicable tourist tax, city tax or other extra charges are not included in the price of Accommodation Services, respective information shall be displayed on the Platform under the order summary, including the current amount. </span ></li >
          <li className="li7" ><span className="s2" >Some accommodation facilities offer free accommodation for each 21st/25st/30th/35th person. If such benefit is offered, the Client will be informed during the booking process and the discounted price will be deducted from the total price of Accommodation Services. Any potential additional surcharges, e.g. for extension of the stay, use of the carpark and other, will be charged separately according to the current pricelist of the respective accommodation facility.</span ></li >
          <li className="li7" ><span className="s2" >Conversion of currencies is for informational purposes only and should not be considered accurate and up-to-date; the accurate and current amounts at the time of booking may be different. </span ></li >
        </ol >
        <p className="p10" >&nbsp;</p >
        <ol className="ol2" >
            <strong > V.</strong ><span className="s2" ><strong >Booking of Accommodation, Reservation Changes, Rooming List</strong ></span >
        </ol >
        <p className="p5" >&nbsp;</p >
        <ol className="ol1" >
          <li className="li3" ><span className="s2" >On the Platform, the Clients may book selected accommodation without any obligation (optional reservation), if the accommodation facility offers such service. Optional reservations have a date until when such reservation is valid. If the reservation is not confirmed in time, the reservation is considered invalid.</span></li >
          <li className="li3" ><span className="s2" >Fixed reservation is a reservation already confirmed, which is then subject to cancellation terms and conditions of the Provider.
</span ></li >
          <li className="li3" ><span className="s2" >The Client is entitled to make changes to the reservation made, to change the number of rooms and to reserve extra optional rooms. The making of changes is subject to subsequent confirmation of the proposed changes by the Provider. Changes to reservations not confirmed by the Provider will be invalid.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider is responsible for all confirmed reservations, and by confirming a new structure, the Provider is obliged to provide accommodation in accordance with the confirmed structure of rooms proposed by the Client. </span ></li >
          <li className="li3" ><span className="s2" >The Client shall provide DAVINCI TS with a Rooming List with respect to each reservation made by the Client. The Rooming List is divided into the first proposed version (ten (10) days before the accommodation start date) and the final version (three (3) days before the accommodation start date). The Rooming List shows the structure of rooms and End-Customer information. </span ></li >
          <li className="li3" ><span className="s2" >If several versions of the Rooming List have been uploaded by the Client, the last Rooming List confirmed by the Provider is deemed to be current. The Provider is not responsible for any changes to the Rooming List made less than three (3) days before the accommodation start date. </span ></li >
          <li className="li3" ><span className="s2" >If the Provider fails to allow accommodation of the End-Customers while the payment conditions are fulfilled, fails to allow accommodation of the End-Customers in accordance with the structure previously confirmed, or otherwise wrongfully cancels a confirmed reservation made by the Client (e.g. because of overbooking or the Provider’s mistake), the Provider shall be obliged, at the Provider’s own expense, to find nearby replacement accommodation of the same or higher category for the Client and to cover the difference between (i) the cost of accommodation in the replacement accommodation facility and (ii) the cost of accommodation in the accommodation facility of the Provider, as well as any other associated costs. If the Provider for any reason does not comply with this obligation, DAVINCI TS may search for alternative accommodation facility to accommodate the arriving End-Customers and any price differences and extra costs will be invoiced to and paid by the original Provider.</span ></li>
        </ol >
        <p className="p11" >&nbsp;</p >
        <ol className="ol2" >
            <strong > VI.</strong ><span className="s2" ><strong > Availability and Overbooking, Booking Amendments</strong ></span >
        </ol >
        <ol className="ol1" >
          <li className="li7" ><span className="s2" >The Provider shall specify the following information for each booking request: rates, number of available rooms to offer, room types, cancellation policies, and any other related services or information that Clients and/or End-Customers should know.
</span ></li >
          <li className="li7" ><span className="s2" >The Provider agrees that offered availability and conditions of accommodation must stay valid (based on the Provider’s preference set in advance) if booking has been confirmed as Optional booking or Confirmed booking.
</span ></li >
          <li className="li7" ><span className="s2" >In the occurrence of an overbooking or refused booking, the Provider must contact DAVINCI TS team at the earliest opportunity either by email at hotels@davincits.com or by phone on +420 776 775 606.
</span ></li >
          <li className="li7" ><span className="s2" >If the Provider needs to change the rooming structure for the booking after the rooming structure has been confirmed to the Client, the Provider shall update this information on the Platform or contact DAVINCI TS via email. If the updated rooming structure does not meet the needs of the Client, DAVINCI TS has the right to cancel the booking without any cancellation fees.
</span ></li >
        </ol >
        <p className="p11" >&nbsp;</p >
        <ol className="ol2" >
            <strong > VII.</strong ><span className="s2" ><strong >Cancellation of Reservation, Non-Accommodation and Outstanding Amounts</strong ></span >
        </ol >
        <p className="p5" >&nbsp;</p >
        <ol className="ol1" >
          <li className="li3" ><span className="s2" >If the Client fails to comply with the applicable payment terms, the Provider has the right to cancel the reservation.
</span ></li >
          <li className="li3" ><span className="s2" >In the event of cancellation of the whole reservation, a part of the reservation or non-accommodation, the Provider may charge the Client with relevant cancellation fees according to applicable cancellation terms and conditions.
</span ></li >
          <li className="li3" ><span className="s2" >If the End-Customer damages any accommodation equipment during his/her stay or uses charged services (including a minibar) during his/her stay, the Provider is entitled to charge the Client for the respective due amount. Similarly, the Provider is entitled to charge the Client for any outstanding amounts resulting from a change in the room structure made by the Client or the End-Customer. The Provider and DAVINCI TS may also agree that the Client shall be charged for the outstanding amounts by DAVINCI TS based on an invoice.
</span ></li >

        </ol >
        <p className="p12" >&nbsp;</p >
        <ol className="ol2" >
          <strong > VIII.</strong ><span className="s2" ><strong >Communication, Support Line and Crisis Solving, Statement of Disclaimer
</strong ></span >
        </ol >
        <p className="p5" >&nbsp;</p >
        <ol className="ol1" >
          <li className="li7" ><span className="s2" >Any notice required to be given under the contractual arrangement between DAVINCI TS and the Provider shall be sent by fax, first class post or email to such address, fax number or email address as either party may from time to time notify to the other in writing.</span ></li >
          <li className="li7" ><span className="s2" >DAVINCI TS is not responsible for (i) any communication between the Provider and the Clients outside the Platform, or (ii) any circumstances or consequences arising from communication between the Provider and the Clients. DAVINCI TS cannot and does not guarantee that any request or communication will be delivered/read, fulfilled, executed or accepted by the Clients in due time and in a timely manner.
</span ></li >
          <li className="li7" ><span className="s2" >To resolve issues related to the Accommodation Service reserved through the Platform, Providers can use our NonStop business support line. It has been designed to deal with crisis situations related to accommodation. DAVINCI TS shall make every effort to resolve crisis situations promptly and in the best manner possible. The Provider acknowledges and agrees that DAVINCI TS only mediates communication and requirements between Clients and Providers through the Customer Service (Lines of Support) and that DAVINCI TS is not responsible for their resolution or answering of any queries.
</span ></li >
          <li className="li7" ><span className="s2" >To the extent permitted by law, we are liable only for direct damages actually suffered, paid or incurred by the Provider in connection with provable breach of our obligations within providing our Services, up to the amount of an Administrative Fee we actually received in connection with the relevant Services.
</span ></li >
        </ol >
        <p className="p8" >&nbsp;</p >
        <ol className="ol2" >
            <strong > IX.</strong ><span className="s2" ><strong >Intellectual Property Rights </strong ></span >
        </ol >
        <p className="p5" >&nbsp;</p >
        <ol className="ol1" >
          <li className="li7" ><span className="s2" >Unless stated otherwise, the software required for our Services or available and used on our Platform, and the intellectual property rights (including copyright) relating to the content and information on our Platform are owned by DAVINCI TS, its suppliers or providers.</span ></li >
          <li className="li3" ><span className="s2" />DAVINCI TS is the exclusive owner of all rights, legal entitlements and interests (associated with the intellectual property), the appearance and user aspect (including infrastructure) of the Platform where the Service is offered (including guest reviews and translated contents). In view of the above, without our express written permission the Provider is not entitled to copy, web-scrape, create links (hypertext/direct), publish, promote, integrate, use, combine, share or use the contents or our brand in any other way (including translations and guest reviews). Therefore, you hereby waive, surrender and transfer in favor of DAVINCI TS all the rights associated with (total or partial) use or combination of our (translated) content or any intellectual property rights to the website and your (translated) content or guest reviews. Any unlawful use or any behavior or conduct described above shall be deemed as serious infringement of intellectual property rights (including relevant copyrights and copyrights relating to the databases).</li >
        </ol >
        <p className="p13" >&nbsp;</p >
        <ol className="ol2" >
            <strong > X.</strong ><span className="s2" ><strong >Protection of End-Customers’ Personal Data</strong ></span >
        </ol >
        <p className="p5" >&nbsp;</p >
        <ol className="ol1" >
          <li className="li3" ><span className="s2" >In order to complete the process of booking of the Accommodation Services, DAVINCI TS shall forward to the Provider the Rooming List which DAVINCI TS receives from the Client. Each Rooming List will contain only the following types of personal data related to the End-Customers: (i) full name, (ii) date of birth, and (iii) identification number of passport or other travel document.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider acknowledges that it is responsible for the handling and security of the personal data it receives from DAVINCI TS. DAVINCI TS assumes no responsibility for the processing of personal data of End-Customers by the Provider to which DAVINCI TS forwarded the Rooming List containing personal data of End-Customers in accordance with the Client’s instructions.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider shall process any personal data related to the End-Customers received from the Client in compliance with Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016 on the protection of natural persons with regard to the processing of personal data and on the free movement of such data, and repealing Directive 95/46/EC („GDPR”), and/or other applicable legislation.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider shall make best efforts to ensure the reliability of its employees and representatives who may have access to personal data of End-Customers, ensuring in each case that access is strictly limited to those individuals who need to know or access the relevant personal data, as strictly necessary for the purposes of provision of Services, and to comply with applicable laws in the context of that individual’s duties to the Provider, ensuring that all such individuals are subject to confidentiality undertakings or professional or statutory obligations of confidentiality.
</span ></li >
          <li className="li3" ><span className="s2" >Taking into account the state of the art, the costs of implementation and the nature, scope, context and purposes of processing as well as the risk of varying likelihood and severity for the rights and freedoms of natural persons, the Provider shall in relation to the personal data of End-Customers implement appropriate technical and organizational measures to ensure a level of security appropriate to that risk. In assessing the appropriate level of security, the Provider shall take account in particular of the risks that are presented by processing, in particular from a personal data breach.</span ></li >
          <li className="li3" ><span className="s2" >The Provider shall process the personal data of the End-Customers forwarded to it by DAVINCI TS solely for the purposes associated with provision of Accommodation Services to the Client and the End-Customers.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider undertakes not to disclose any personal data of the End-Customers forwarded to it by DAVINCI TS to any third party, except in the following cases:
</span >
          <ol>
            <li type="a">
              the Provider may disclose such data to its representatives, employees and subcontractors regarding the provision of the Accommodation Services;
            </li>
            <li type="a">
              disclosure of such data is necessary for the fulfilment of obligations of the Provider;
            </li>
            <li type="a">
              disclosure of such data is required by public authorities or public officials who, under the applicable legislation, are authorized to request and collect such data;
            </li>
            <li type="a">
              and in any other cases specified by the applicable law.
            </li>
          </ol>
          </li >
          <li className="li3" ><span className="s2" >The Provider shall not store the personal data of the End-Customers longer than is necessary for the purposes for which the personal data need to be processed by the Provider in accordance with these Terms.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider shall cooperate with DAVINCI TS and the Client in good faith and provide assistance in the event End-Customers will wish to exercise their rights of access, correction, erasure, portability or any other right granted by applicable legislation, or if the competent authorities will request demonstration of compliance with statutory obligations related to protection of personal data.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider undertakes to make best efforts to protect the personal data of End-Customers against loss and unauthorized access, use, deletion and disclosure; and, as required by applicable laws, process personal data in a manner that ensures appropriate confidentiality and security of the personal data.
</span ></li >
          <li className="li3" ><span className="s2" >The Provider shall notify DAVINCI TS and the Client without undue delay upon the Provider becoming aware of a personal data breach affecting personal data of the End-Customers, and shall provide DAVINCI TS and the Client with sufficient information to allow DAVINCI TS and the Client to meet any obligations to report or inform the End-Customers of the personal data breach under the applicable laws. The Provider shall co-operate with DAVINCI TS and the Client and make best efforts as directed by DAVINCI TS and/or the Client to assist in the investigation, mitigation and remediation of each such personal data breach. If the Provider intends to communicate with the End-Customers, public authorities or other parties about a data breach involving personal data of the End-Customers, the Provider shall first, to the extent permitted by law, consult the draft of such communication with DAVINCI TS and the Client and cooperate with DAVINCI TS and the Client in preparation of final wording of such communication.</span ></li >

        </ol >
        <p className="p4" >&nbsp;</p >
        <ol className="ol2" >
            <strong > XI.</strong ><span className="s2" ><strong >Termination</strong ></span >
              <li>
                Either party may terminate the contractual arrangement between DAVINCI TS and the Provider at any time:

                <ol>
                  <li type="a">
                    on giving at least 7 days' written notice to the other party;
                  </li>
                  <li type="a">
                    the other party commits any material breach of the contractual arrangement between DAVINCI TS and the Provider and fails to remedy to the satisfaction of the non-breaching party, within 20 days of receiving a written request to do so, that breach;
                  </li>
                  <li type="a">
                    in one party’s reasonable opinion, there is any repeated or persistent failure by the other party to provide service of a sufficiently high standard to customer booking travel arrangements;
                  </li>
                  <li type="a">
                    the other party suspends or ceases trading or indicates that it intends to cease trading or becomes unable to pay its debts as they fall due; or
                  </li>
                  <li type="a">
                    the other party has a receiver or liquidator appointed, or passes an effective resolution for winding up or a Court makes an order to that effect or a similar event occurs; or
                  </li>
                  <li type="a">
                    execution is levied against the property of the other party.
                  </li>
                </ol>
              </li>
          <li>
            DAVINCI TS reserves the right to suspend any offer from publication on the Platform (temporarily or permanently) for any reason.
          </li>
          <li>
            If the contractual arrangement between DAVINCI TS and the Provider is terminated for any reason, the termination shall not apply in relation to bookings confirmed by the Provider to DAVINCI TS before the effective date of termination and the rights and obligations of the parties under this arrangement in respect of such bookings (including the contracts created between the Provider and Clients) shall survive the termination and be enforceable notwithstanding it.
          </li>
          <li>
            Termination of the contractual arrangement between DAVINCI TS and the Provider shall not affect the accrued rights or remedies of either party that accrued prior to the termination.
          </li>
        </ol >
        <p className="p4" >&nbsp;</p >
        <ol>
          <strong > XII.</strong ><span className="s2" ><strong >Miscellaneous</strong ></span >
        <li>
          To the extent permitted by law, these Terms, as well as provision of our Services, are governed and construed in line with the Czech law, and any dispute arising in connection with these Terms and our Services shall be settled solely by the competent court in the Czech Republic.
        </li>
          <li>
            The rights and obligations of the parties within the relationship established by these Terms are governed in particular by Act No. 89/2012 Coll., the Civil Code. For the avoidance of doubt, the contracting parties have agreed to exclude the application of the provisions of § 2450, 2451, 2452 and 2453 of the Civil Code to their mutual contractual relations under these Terms.

          </li>
          <li>
            If any part of these Terms becomes invalid, legally ineffective or non-binding, the other parts of these Terms shall survive. In such a case, the affected provision shall be enforced in full in accordance with the applicable law, and you shall adopt measures with an effect similar to the invalid, legally ineffective or non-binding measure, in accordance with the content and purpose of these Terms.

          </li>
          <li>
            These Terms enter into force and become effective on 01.06.2019. If necessary, DAVINCI TS may update these Terms by publishing updated Terms on its website, and such updated Terms shall apply and become effective from the date of such publication. By log-in and using the Platform, as well as using any of Services, you agree with the current wording of our Terms published on the Platform and you undertake to follow them.

          </li>
          <li>
            The Provider may not assign any rights or obligations towards DAVINCI TS to any third party without the prior written consent of DAVINCI TS.
          </li>
          <li>
            Nothing in these Terms confers or purports to confer on the Clients, End-Customers or any other third party any benefit or any right to enforce any term of these Terms.
          </li>
        </ol>
        <p className="p4" >&nbsp;</p >
        <ol>
          <strong > XIII.</strong ><span className="s2" ><strong >About DAVINCI travel system s.r.o.
</strong ></span >
          <p>
            The mediation of accommodation is provided by DAVINCI travel system s.r.o., Company ID no.: 05277949, VAT registration no. CZ05277949, which is subject to the Czech law, based at Pavla Beneše 750/12, Letňany, Prague 9, 199 00, Czech Republic, registered in the Register of the Municipal Court in Prague under file no. C 261111, according to these Terms. The authorized representative and managing director of the company is Alex Ilyash.
          </p>
        </ol>
      </div>
  );
}

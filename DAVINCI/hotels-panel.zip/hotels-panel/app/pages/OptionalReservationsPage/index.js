import React from 'react';
import { adopt } from 'react-adopt';
import Reservations from 'app/common/Reservations';

import AllReservationsProvider from 'app/providers/Reservations/AllReservationsProvider';
import CurrencyProvider from 'app/providers/Requests/CurrencyProvider';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import { getOptionalReservations } from 'app/utils/sessions';
import Loading from 'app/common/Loading/LoadingWrapPage';
import SentryGraph from 'app/utils/sentryGraphUtil';
import DialogError from 'app/common/Errors/DialogError';
import i18n from 'app/utils/i18n';

const OptionalReservationsPage = ({ reservations: { data, loading, error }, hotelQuery, currencies }) => {
  if (loading) {
    return (<Loading />);
  }
  if (error) {
    SentryGraph(error);
    return (<DialogError error={error} />);
  }
  return (
    <Reservations
      reservations={getOptionalReservations(data.reservations)}
      hotelQuery={hotelQuery}
      currencies={currencies}
      textEmptyData={i18n('app.components.Reservations.emptyOptional')}
    />
  );
};

OptionalReservationsPage.displayName = 'OptionalReservationsPage';

const Composed = adopt({
  reservations: AllReservationsProvider,
  currencies: CurrencyProvider,
  hotelQuery: HotelProvider,
});

export default props => (
  <Composed>
    {data => (
      <OptionalReservationsPage {...data} {...props} />
    )}
  </Composed>
);

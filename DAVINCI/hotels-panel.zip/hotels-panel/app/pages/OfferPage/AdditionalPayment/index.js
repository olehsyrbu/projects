import React from 'react';
import i18n from 'app/utils/i18n';
import TextInputWithTitle from 'app/common/TextInputWithTitle';

const AdditionalPayment = ({ error, onChangeText, text }) => (
  <TextInputWithTitle
    error={error}
    title={i18n('app.components.Offer.paymentsTitle')}
    placeholder={i18n('app.components.Offer.paymentsPlaceholder', {}, true)}
    onChangeText={onChangeText}
    text={text}
  />
);

AdditionalPayment.displayName = 'AdditionalPayment';

export default AdditionalPayment;

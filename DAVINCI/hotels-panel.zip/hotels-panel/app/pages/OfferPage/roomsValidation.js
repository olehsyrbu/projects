import { size } from 'lodash';

import Validation from 'app/utils/validator';
import Require from 'app/utils/validator/required';
import MinNumber from 'app/utils/validator/minNumber';

const roomValidation = new Validation([
  new Require('amount'),
  new MinNumber('amount'),
  new MinNumber('priceOne'),
]);

export default function (data) {
  return data.reduce((roomsErrors, room, index) => {
    let errors;
    if (room.active) {
      errors = roomValidation.getErrors(room, index);
    }
    if (size(errors) > 0) {
      roomsErrors[index] = errors;
    }
    return roomsErrors;
  }, []);
}

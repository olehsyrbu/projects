import React from 'react';
import PropTypes from 'prop-types';
import {
  Table,
  TR as Row,
  TH as Head,
  TD as Cell,
} from 'app/ui';

import i18n from 'app/utils/i18n';
import IconInfo from 'app/common/IconInfo';
import Toggle from 'app/common/Toggle';
import { activeToggleStyle, disableToggleStyle } from '../style';
import RowAmount from '../RowAmount';
import RowPrice from '../RowPrice';
import Center from 'app/common/design/Center';
import { formatPrice } from 'app/utils';
import { rooms as roomsGlobal } from 'app/utils/global-constant';

const getRoomNameByAbbr = name => name && i18n(`app.components.room.${roomsGlobal.find(item => item.abbr === name).name}`);

const TableRooms = ({
  sign, table, errors, totalPriceWithSign, onToggleTable, handlerChangePrice, handlerChangeAmount, handlerOnBlurPriceInput,
}) => (
  <Table cellsWidth={[30, 15, 30, 10, 15]}>
    <Row className="table-header">
      <Head>{i18n('app.components.Offer.RoomStructure.RoomTable.roomText')}</Head>
      <Head className="u-flex-align-right-end">{i18n('app.components.Offer.RoomStructure.RoomTable.amountText')}</Head>
      <Head className="u-flex-align-right-end">
        {i18n('app.components.Offer.RoomStructure.RoomTable.pricePerRoom')}
        <IconInfo
          text={i18n('app.components.Offer.RoomStructure.RoomTable.priceOneTextHint')}
          id="app.components.Offer.RoomStructure.RoomTable.priceOneTextHint"
        />
      </Head>
      <Head className="u-flex-align-right-end">
        {i18n('app.components.Offer.RoomStructure.RoomTable.nights')}
      </Head>
      <Head className="u-flex-align-right-end">
        {i18n('app.components.Offer.RoomStructure.RoomTable.priceTotalText')}{sign}
      </Head>
    </Row>
    {table.map(({
                  name, active, amount, priceOne, days, priceTotal, isUserCanChangePrice,
                }, index) => (
      <Row key={index} >
        <Cell>
          <Toggle
            className="toggle-rooms"
            label={getRoomNameByAbbr(name)}
            labelStyle={active ? activeToggleStyle : disableToggleStyle}
            onToggle={onToggleTable.bind(this, index)}
            toggled={active}
            labelPosition="right"
          />
        </Cell>
        <Cell className="u-flex-align-right-end">
          <RowAmount
            index={index}
            handlerChangeAmount={handlerChangeAmount.bind(this, index)}
            active={active}
            name={name}
            amount={amount}
            errors={errors}
            onToggleTable={onToggleTable}
          />
        </Cell>
        <Cell flex={2} className="u-flex-align-right-end">
          <RowPrice
            errors={errors}
            sign={sign}
            index={index}
            name={name}
            priceOne={priceOne}
            handlerOnBlurPriceInput={handlerOnBlurPriceInput.bind(this, index)}
            onToggleTable={onToggleTable}
            handlerChangePrice={handlerChangePrice.bind(this, index)}
            isUserCanChangePrice={isUserCanChangePrice}
            active={active}
          />
        </Cell>
        <Cell className="u-flex-align-right-end" active={active}>
          <Center className="offer-days row-text" >{days}</Center>
        </Cell>
        <Cell className="u-flex-align-right-end">
          {formatPrice(priceTotal, sign)}
        </Cell>
      </Row>
    ))}
    <Row>
      <Cell width="100">
        <div className="u-text-align-right">
          <span className="u-text-total-table">
            {i18n('app.components.Offer.RoomStructure.totalPriceText')}
          </span>
          <span className="u-text-font-bold">
            {totalPriceWithSign}
          </span>
        </div>
      </Cell>
    </Row>
  </Table>
);

TableRooms.propTypes = {
  sign: PropTypes.string,
  table: PropTypes.array,
  errors: PropTypes.array,
  totalPriceWithSign: PropTypes.string,
  onToggleTable: PropTypes.func,
  handlerChangePrice: PropTypes.func,
  handlerChangeAmount: PropTypes.func,
  handlerOnBlurPriceInput: PropTypes.func,
};

export default TableRooms;

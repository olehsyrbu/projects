import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { getPeriodLiving, getUpTo } from 'app/utils/date';
import { getCityTaxValue, formatPrice } from 'app/utils';
import { colors } from 'app/style/variables';
import { Dialog, Button, Row, Col } from 'app/ui';
import RoomsInfo from 'app/common/SentedOffer/TableRoomsSent';
import CancellationPolicyTable from 'app/pages/OfferPage/CancellationPolicyTable';
import HotelOptionsDataWithIcons from 'app/pages/OfferPage/HotelOptionsDataWithIcons';
import OfferValidTime from 'app/pages/OfferPage/OfferValidTime';
import Avatar from 'app/common/Avatar';
import Comment from 'app/pages/OfferPage/Comment';
import i18n from 'app/utils/i18n';
import { styleBtn, Title, BtnWrap } from 'app/common/design/style';
import { Header, WrapOfferData, TextStyleHotelConfirmationTerms } from './style.js';

const TextGray06 = styled.span`
  padding: 0 10px;
  color: ${colors.text};
  opacity: .6;
`;

class HotelConfirmation extends PureComponent {
  render() {
    const {
      hotel,
      offerInfo,
      onCancel,
      onApprove,
      paymentPolicy,
      handleChangeValidTime,
      partialCancellationComment,
    } = this.props;

    const {
      num,
      foc,
      sign,
      rooms,
      cityTax,
      checkIn,
      checkOut,
      validTime,
      totalPrice,
      hotelComments,
      errorValidTime,
      selectedMealLabel,
      handleChangeComment,
      textAdditionalPayments,
    } = offerInfo;
    const { name, media: { logo } } = hotel;

    const Btns = [
      <TextStyleHotelConfirmationTerms>
          {i18n('app.components.SentOffers.linkTermsText', {}, true)} &nbsp;
          <a target="_blank" href="/terms">
            {i18n('app.components.confirm.terms')}
          </a>
      </TextStyleHotelConfirmationTerms>,
      <BtnWrap>
        <Button
          autoFocus
          uppercase
          onClick={onCancel}
          styleData={styleBtn}
        >
          {i18n('app.components.Offer.RoomStructure.btnEditOffer')}
        </Button>
        <Button
          uppercase
          disabled={errorValidTime}
          primary
          onClick={onApprove}
        >{i18n('app.components.Offer.RoomStructure.btnConfirmOffer')}</Button>
      </BtnWrap>,
    ];

    return (
      <Dialog
        className="dialog"
        actions={Btns}
        onClose={onCancel}
        title={
          <Header>
            <Avatar src={logo} style={{ display: 'inline-block', marginRight: '20px' }} />
            <div>
              {i18n('app.components.Offer.RoomStructure.confirmationText')}
              <TextGray06 >/</TextGray06>
              <span>{`#${num}`}</span>
              <TextGray06 >/</TextGray06>
              <span>{`Hotel ${name} ${getPeriodLiving({ checkIn, checkOut })}`}</span>
            </div>
          </Header>
        }
      >
        <Row className="ui-flex">
          <Col width={57} className="u-margin-right">
            <RoomsInfo
              isOfferPage
              isNewStyle
              sign={sign}
              rooms={rooms}
              className="small-table-rows"
              styleTotal={{
                fontWeight: 'bold',
                color: 'rgba(0, 0, 0, 0.87) !important',
              }}
              totalPrice={
                `${i18n('app.components.Offer.RoomStructure.totalText', {}, true)}
               ${formatPrice(totalPrice, sign)}`
              }
              isShowTotal
            />
          </Col>
          <Col className="u-offer-valid u-block-padding">
            <OfferValidTime
              validTime={validTime}
              onChangeValidTime={handleChangeValidTime}
              errorValidTime={errorValidTime}
            />
          </Col>
        </Row>
        <WrapOfferData>
          <Row>
            <Col width={57} className="u-margin-right u-margin-top" >
              <HotelOptionsDataWithIcons
                sign={sign}
                textAdditionalPayments={textAdditionalPayments}
                paymentPolicy={paymentPolicy}
                mealValue={selectedMealLabel}
                foc={foc}
                cityTaxValue={getCityTaxValue(cityTax)}
                upTo={getUpTo(validTime) || '-'}
              />
              <Comment onChangeComment={handleChangeComment} text={hotelComments} />
            </Col>
            <Col className="u-block-padding">
              <Title>
                {i18n('app.components.HotelCancellationPolicy.title')}
              </Title>
              <CancellationPolicyTable
                {...this.props.cancellationPolicy}
              />
              {
                partialCancellationComment &&
                <Col className="u-padded-top">
                  <Title>{i18n('app.components.partialCancellation')}</Title>
                  <p className="u-text-small">{partialCancellationComment}</p>
                </Col>
              }
            </Col>
          </Row>
        </WrapOfferData>
      </Dialog>
    );
  }
}

HotelConfirmation.propTypes = {
  onCancel: PropTypes.func,
  onApprove: PropTypes.func,
  cancellationPolicy: PropTypes.object,
  offerInfo: PropTypes.object,
  hotel: PropTypes.object,
  rooms: PropTypes.array,
};

export default HotelConfirmation;

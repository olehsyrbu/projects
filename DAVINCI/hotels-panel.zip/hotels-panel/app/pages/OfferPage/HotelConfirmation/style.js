import styled from 'styled-components';

export const TextStyleHotelConfirmationTerms = styled.div`
  display: flex;
  flex: 2;
  align-items: center;
  text-align: left;
`;

export const Header = styled.p`
  font-size: 17px;
  width: 100%;
  font-weight: bold;
  justify-content: left;
  align-items: center;
  display: flex;
  line-height: 24px;
`;

export const WrapOfferData = styled.div`
  font-weight: 500;
  .row {
    line-height: 16px;
    font-size: 12px;
    padding: 2px 0;
  }
  .row-dotted {
    line-height: 36px;
    font-size: 13px;
    border-bottom: 1px dotted #D5DCE4;
  }
`;

export const Text = styled.div`
  font-size: 14px;
  line-height: 21px;
`;

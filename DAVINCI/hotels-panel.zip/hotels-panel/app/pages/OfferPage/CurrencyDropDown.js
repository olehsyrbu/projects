import React from 'react';
import PropTypes from 'prop-types';
import { Select } from 'app/ui';
import i18n from '../../utils/i18n';
import Flex from 'app/common/design/Flex';
import Center from 'app/common/design/Center';
import styled from 'styled-components';
import { colors } from 'app/style/variables';

const Title = styled(Center)`
  color: ${colors.grayTitle};
  padding-right: 8px;
  font-weight: normal;
`;

const CurrencyDropDown = props => (
  <Flex>
    <Title >
      {i18n('app.components.ChangeCurrency.title', {}, true).toUpperCase()}:
    </Title>
    <div className="currency-dropdown-button u-margin-right ui-font-weight-500">
      <Select {...props} />
    </div>
  </Flex>
);

CurrencyDropDown.propTypes = {
  isUserCanChangeCurrency: PropTypes.bool,
  activeCurrency: PropTypes.object,
  currencies: PropTypes.array,
  handlerChangeCurrency: PropTypes.func,
};

export default CurrencyDropDown;

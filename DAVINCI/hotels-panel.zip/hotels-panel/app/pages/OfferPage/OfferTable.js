import React from 'react';
import PropTypes from 'prop-types';
import { adopt } from 'react-adopt/dist/index';
import SessionsListSubscription from 'app/graph/subscriptions/sessionsList';
import * as Sentry from '@sentry/browser';
import moment from 'moment/moment';
import { isEqual, ceil, isFunction, isEmpty, isNaN, values, floor, get, differenceWith, size } from 'lodash';
import { colors } from 'app/style/variables';
import { getCityTaxValue, convertStringToNumber, formatPrice, checkMaxLengthForPriceInput } from 'app/utils';
import { getCurrencyByAbbr, getIsCurrencyDefault } from 'app/utils/currency';
import { createTable, getPricePerPerson, recalculatePriceTotal } from './helpers';
import { getDayNow, getUpToFullTime, getTimeForValidOffer } from 'app/utils/date';
import { getCapacity } from 'app/utils/rooms';
import { Col, Row, Button } from 'app/ui';
import i18n from 'app/utils/i18n';

import SubscriptionSessionProvider from 'app/providers/Requests/SubscriptionSessionProvider';
import SessionProvider from 'app/providers/Requests/SessionProvider';
import RoomsProvider from 'app/providers/Requests/RoomsProvider';
import CurrencyProvider from 'app/providers/Requests/CurrencyProvider';
import HotelProvider from 'app/providers/Requests/HotelProvider';
import MakeOfferProvider from 'app/providers/Proposals/MakeOfferProvider';
import UpdateHotelProvider from 'app/providers/General/UpdateHotelProvider';
import CurrencyDropDown from './CurrencyDropDown';
import MealDropDown from 'app/pages/OfferPage/MealDropDown';
import HotelCondition from 'app/pages/OfferPage/HotelCondition';
import OverPricePopUp from 'app/pages/OfferPage/OverPricePopUp';
import DialogNotification from 'app/common/DialogNotification';
import RoomTable from './TableRooms';
import AdditionalPayment from './AdditionalPayment';
import roomsValidation from './roomsValidation';
import Date from 'app/common/Date';
import {
  rooms,
  ROOM_TYPE_SINGLE,
  DEFAULT_DAYS_OPTIONAL,
  DEFAULT_DUE_DAYS_FIXED,
  defValueCurrency,
  DEFAULT_DAYS_VALID_OFFER,
} from 'app/utils/global-constant';

import {
  RoomStructureContainer,
  RoomStructureTitle,
  styleCondition,
  RoomBodyStyle,
  OfferTitle,
  OfferContainer,
  FlexTitle,
  styleContinue,
  styleDateOfferPage,
} from './style';

import rectangle from 'app/media/CityTax.svg';
import SettingIcon from 'material-ui/svg-icons/action/settings';

class OfferTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = this.getInitState(props);
    this.validate = this.validate.bind(this);
    this.handlerHotelConditionConfirm = this.handlerHotelConditionConfirm.bind(this);
    this.handlerChangeAdditionalPayments = this.handlerChangeAdditionalPayments.bind(this);
    this.handlerChangeAmount = this.handlerChangeAmount.bind(this);
    this.handlerChangePrice = this.handlerChangePrice.bind(this);
    this.handleChangeValidTime = this.handleChangeValidTime.bind(this);
  }

  getInitState(props) {
    const {
      session: {
        rooms, checkIn, checkOut, requestData: { meal } = {},
      } = {},
      currencies = [],
      hotel,
    } = props;

    currencies.forEach(c => Object.assign(c, { label: c.abbr, value: c.abbr }));
    const activeCurrency = hotel && hotel.currencyAbbr ? getCurrencyByAbbr(currencies, hotel.currencyAbbr) : defValueCurrency;
    const { showConfirmReservation, reservation } = this.setDefaultDate(checkIn);
    const table = rooms && createTable({
      rooms, checkIn, checkOut, hotel,
    }) || [];
    const isUserCanNotChangeCurrency = size(hotel.proposals);
    const { paymentPolicy, cancellationCommentText, partialCancellationComment } = hotel;

    const serialDates = [];
    if (checkIn && checkOut) {
      serialDates.push({
        checkIn,
        checkOut,
        isActive: true,
      });
    }
    const isShowAdditional = meal !== 'BB';
    const subObject = isShowAdditional ? { isClickedBtnContinue: false, isAdditionalError: false } : {};

    return {
      dates: [...serialDates],
      errors: [],
      hotelComments: '',
      validTime: getTimeForValidOffer(DEFAULT_DAYS_VALID_OFFER),
      isOpenHotelCondition: false,
      isSavedRequest: false,
      isOpenDirect: false,
      selectedMeal: {
        label: i18n('app.meal.BB'),
        value: 'BB',
      },
      table,
      activeCurrency,
      totalPrice: this.calculateTotal(table),
      reservation,
      showConfirmReservation,
      isUserCanNotChangeCurrency,
      cancellationCommentText,
      paymentPolicy,
      partialCancellationComment,
      textAdditionalPayments: '',
      isShowAdditionalPayment: isShowAdditional,
      currencies,
      totalPriceWithSign: formatPrice(this.calculateTotal(table), activeCurrency.sign),
      ...subObject,
    };
  }

  componentWillReceiveProps({ hotel, session = { rooms, checkIn, checkOut } }) {
    if (!this.state.table) {
      this.setState({
        table: createTable({
          rooms, checkIn, checkOut, hotel,
        }),
        totalPrice: this.calculateTotal(),
      });
    }
    if (session && !get(session, 'hotelsDeclined[0]') && differenceWith(this.props.session, session, isEqual).length > 0) {
      this.setState({ isChangedRequest: true });
    }
  }

  componentDidMount() {
    this.validate((errors) => { this.setState({ errors }); });
  }

  setDefaultDate = (checkIn) => {
    const optionalAllowed = moment(checkIn).subtract(DEFAULT_DAYS_OPTIONAL, 'days');
    const diffCheckInWithOptional = optionalAllowed.diff(moment(), 'days') > 0;
    return {
      reservation: diffCheckInWithOptional ? new Date(optionalAllowed) : null,
      showConfirmReservation: false,
    };
  };

  getDueDays = (checkIn) => {
    const { showConfirmReservation, reservation } = this.state;
    let dueDays;

    if (!showConfirmReservation) {
      dueDays = moment.duration(moment(checkIn).diff(getDayNow(-1))).asDays();
    } else {
      const daysForConfirm = reservation && moment(checkIn).diff(moment(reservation), 'days');
      dueDays = daysForConfirm && daysForConfirm > 0 && daysForConfirm || DEFAULT_DUE_DAYS_FIXED;
    }
    return dueDays;
  };

  validate = (cb, context) => {
    const { table } = this.state;
    const errors = roomsValidation(table);
    const isSentErrors = !isEqual(errors, []);
    const errorsData = isSentErrors ? errors : undefined;
    if (isFunction(cb)) cb(errorsData, context);
  };

  onOpenHotelCondition = (rooms = [], isOpenDirect) =>
    this.setState({ isOpenDirect, isOpenHotelCondition: true, rooms });

  getISPricePerPersonBiggerThanBudget = (rooms, budgetMax) =>
    rooms.some(({ room: { name }, prices }) => {
      const capacityRooms = getCapacity(name);
      const capacity = (name === ROOM_TYPE_SINGLE) ? 2 : capacityRooms;
      return floor((Number(prices[0].primeCost)) / capacity) > (budgetMax);
    });

  continueOffer = () => {
    const self = this;
    const { isShowAdditionalPayment, textAdditionalPayments } = self.state;
    const { requestData: { budgetMax } } = self.props.session;

    if (isShowAdditionalPayment && !textAdditionalPayments.trim()) {
      self.setState({
        isClickedBtnContinue: true,
        isAdditionalError: true,
      });
      return;
    }
    this.validate((errors) => {
      if (!isEmpty(errors)) return false;
      const rooms = this.getActiveRooms(true);
      // if have more budget per person
      // show popUp with changing price
      if (this.getISPricePerPersonBiggerThanBudget(rooms, budgetMax)) {
        self.setState({
          isShowOverPricePopUp: true,
          rooms,
        });
      } else {
        self.setState({
          isOpenHotelCondition: true,
          rooms,
        });
      }
    }, this);
  };

  handlerSendHotelProposal = ({ foc, cancellationPolicy, cityTax }) => {
    const { session: { checkIn, _id }, updateHotel } = this.props;
    const {
      validTime, selectedMeal, hotelComments, partialCancellationComment, paymentPolicy, textAdditionalPayments,
    } = this.state;

    this.validate((errors) => {
      if (!isEmpty(errors)) return false;
      updateHotel({
        hotel: {
          partialCancellationComment,
          paymentPolicy,
        },
        _id,
      });

      return this.makeOfferHandler({
        foc,
        meal: selectedMeal.value,
        partialCancellationComment,
        paymentPolicy,
        hotelComments,
        dinnerAdditionalPayment: textAdditionalPayments,
        cityTax: getCityTaxValue(cityTax),
        dueDays: Math.ceil(this.getDueDays(checkIn)),
        upTo: getUpToFullTime(validTime) || '-',
        proposals: {
          cancellationPolicy,
          rooms: this.getActiveRooms(),
        },
      });
    });
  };

  makeOfferHandler = async (hotelProposal) => {
    const { makeOffer, session } = this.props;
    try {
      await makeOffer({
        session: {
          _id: session._id,
          hotelProposal,
        },
      });
      this.setState({ isSavedRequest: true });
    } catch (e) {
      this.setState({ isMakeOfferPageFailed: true });
      Sentry.captureException(e);
    }
  };

  // round price
  // ex: value = 55.43 => 55.50
  roundEURPrice = number => (Math.ceil(+number * 10) / 10).toFixed(2);

  getPriceData = (activeCurrency, priceOne) => {
    let primeCost = priceOne;
    if (!getIsCurrencyDefault(activeCurrency.sign)) {
      primeCost = ceil(parseFloat(convertStringToNumber(priceOne) / activeCurrency.rate), 2); // convert to euro
    }
    primeCost = this.roundEURPrice(convertStringToNumber(primeCost));
    return {
      primeCost: convertStringToNumber(primeCost),
      localPrice: {
        value: convertStringToNumber(priceOne),
        currency: {
          abbr: activeCurrency.abbr,
          rateToEUR: activeCurrency.rate,
        },
      },
    };
  };

  getActiveRooms = (isGetRoomInfo) => {
    const { roomTypes } = this.props;
    const { table, activeCurrency } = this.state;
    const getRoomInfoByName = (isGetRoomInfo, name) => {
      const roomData = roomTypes.find(item => item.name === name);
      return isGetRoomInfo ? roomData : roomData._id;
    };

    return table.filter(row => row.active)
      .map(({ name, amount, priceOne }) => ({
        amount: +amount,
        room: getRoomInfoByName(isGetRoomInfo, name),
        prices: [{ ...this.getPriceData(activeCurrency, priceOne) }],
      }));
  };

  validateAndUpdateState = nextTable => this.validate((errors, context) => {
    context.setState({
      totalPrice: this.calculateTotal(),
      totalPriceWithSign: formatPrice(this.calculateTotal(), context.state.activeCurrency.sign),
      table: nextTable,
      errors,
    });
  }, this);

  handleToggleTable = (index) => {
    this.validateAndUpdateState(this.state.table.map((row, i) => {
      if (index === i) {
        row.active = !row.active;
        if (Number(row.amount) === 0) row.amount = '';
        if (Number(row.priceOne) === 0) row.priceOne = '';
      }
      return row;
    }));
  };

  handlerOnBlurPriceInput = (index, value = '0,00') => {
    const { table } = this.state;
    if (isNaN(Number(value))) {
      value = value.replace(',', '.');
    }
    const price = Number(value).toFixed(2).replace('.', ',');
    table[index].priceOne = price === 'NaN' ? value : price;
    this.validateAndUpdateState([...table]);
  };

  getIsValidatePriceRegExp = (value, regExp) => {
    const isValidLength = checkMaxLengthForPriceInput(value);
    return regExp.test(value) && isValidLength;
  };

  handlerChangePrice = (index, newValue) => {
    let value = newValue;
    if (typeof value === 'object') {
      value = value.target.value;
    }
    const { table } = this.state;
    const row = table[index];
    const isValidValue = this.getIsValidatePriceRegExp(value, new RegExp(/^$|^([0|[1-9]\d*|(,|\.))((\.|,)|(.|,)\d{1,2})?$/));

    row.priceOne = isValidValue ? value : row.priceOne;
    row.pricePerPerson = getPricePerPerson(row.name, `${row.priceOne}`.replace(',', '.'));
    row.priceTotal = recalculatePriceTotal(row.amount, row.days, `${row.priceOne}`.replace(',', '.'));
    this.validateAndUpdateState([...table]);
  };

  handlerChangeAmount = (index, value) => {
    const { table } = this.state;
    const row = table[index];
    const isValidValue = this.getIsValidatePriceRegExp(value, new RegExp(/^$|^[0-9]+$/));

    row.amount = isValidValue ? +value : row.amount;
    row.priceTotal = recalculatePriceTotal(row.amount, row.days, `${row.priceOne}`.replace(',', '.'));
    this.validateAndUpdateState([...table]);
  };

  calculateTotal = (tableData) => {
    let total = 0;
    const table = tableData || this.state.table;
    table.map(row => total += row.active ? ceil(row.priceTotal, 2) : 0);
    return ceil(total, 2);
  };

  handleChangeValidTime = (newValue) => {
    this.setState({
      validTime: newValue,
      errorValidTime: moment().isAfter(newValue),
    });
  };

  handlerCancelHotelCondition = () => this.setState({ isOpenDirect: false, isOpenHotelCondition: false });

  handlerHotelConditionConfirm = ({ hotel }) => {
    if (!this.state.isOpenDirect) this.handlerSendHotelProposal(hotel || {});
    this.setState({ isOpenHotelCondition: false, isOpenDirect: false });
  };

  handlerChangeCurrency = async (abbr) => {
    const { updateHotel, session: { _id: sessionId } } = this.props;
    const newCurrency = this.state.currencies.find(c => c.abbr === abbr);
    try {
      await updateHotel({
        hotel: {
          currencyAbbr: newCurrency.abbr ? newCurrency.abbr : defValueCurrency.abbr,
        },
        sessionId,
      });
      this.setState({
        activeCurrency: newCurrency || defValueCurrency,
      });
    } catch (e) {
      Sentry.captureException(e);
    }
  };

  handleChangeComment = event => this.setState({ hotelComments: event });

  handlerOpenCondition = isOpenDirectly => this.onOpenHotelCondition(this.getActiveRooms(true), isOpenDirectly);

  handlerCancelOverPricePopUp = () =>
    this.setState({ isShowOverPricePopUp: false }, () => {
      this.onOpenHotelCondition(this.state.rooms);
    });

  handlerConfirmChangePrice = () => {
    this.setState({ isShowOverPricePopUp: false });
  };

  handlerCloseOverPricePopUp = () =>
    this.setState({
      isShowOverPricePopUp: false, isOpenHotelCondition: false,
    });

  handlerUpdateInputs = ({ paymentPolicy, partialCancellationComment }) =>
    this.setState({
      paymentPolicy, partialCancellationComment,
    });

  handlerChangeAdditionalPayments = e =>
    this.setState({
      isAdditionalError: false, textAdditionalPayments: e,
    });


  getNotification = () => {
    const { isSavedRequest, isChangedRequest, isMakeOfferPageFailed } = this.state;
    const { sessionsListSubscription: { dialogAction } = {} } = this.props;
    return isChangedRequest && 'changed' || isSavedRequest && 'success' || isMakeOfferPageFailed && 'failed' || dialogAction;
  };

  getIsDisableContinueBtn = () => {
    const {
      showConfirmReservation,
      reservation,
      table,
      errors,
      textAdditionalPayments,
      isShowAdditionalPayment,
      isClickedBtnContinue,
    } = this.state;

    if (isClickedBtnContinue === false) return false;
    return isShowAdditionalPayment && !textAdditionalPayments.trim()
      || values(errors).some(x => x !== undefined)
      || showConfirmReservation && !(reservation instanceof Date)
      || table.every(r => r.active === false);
  };

  handlerChangeMeal = value => this.setState({ selectedMeal: value });

  render() {
    const {
      rooms,
      table,
      errors,
      currencies,
      totalPrice,
      isOpenDirect,
      hotelComments,
      isShowOverPricePopUp,
      activeCurrency,
      isOpenHotelCondition,
      isUserCanNotChangeCurrency,
      isShowAdditionalPayment,
      textAdditionalPayments,
      paymentPolicy,
      partialCancellationComment,
      dates,
      selectedMeal,
      totalPriceWithSign,
      validTime,
      isAdditionalError,
      errorValidTime,
    } = this.state;
    const {
      updateHotel,
      hotel,
      session: {
        checkIn, checkOut, num,
        // sessionRooms,
        requestData: { budgetMax } = {},
      } = {},
    } = this.props;

    const notificationAction = this.getNotification();
    const isDisable = this.getIsDisableContinueBtn();

    return (
      <OfferContainer>
        <RoomStructureContainer>
          <FlexTitle >
            <Col className="u-with-fit-context">
              <OfferTitle>{i18n('app.components.Offer.title')}</OfferTitle>
            </Col>
            <Col className="u-flex-center-block height-wrap">
              {dates.map((date, index) => (
                <Date
                  isNotShowIconCalendar
                  key={index}
                  style={styleDateOfferPage}
                  date={date}
                />
              ))}
            </Col>
            <Col className="u-flex-align-right height-wrap" width={34}>
              <CurrencyDropDown
                disabled={isUserCanNotChangeCurrency}
                value={activeCurrency.abbr}
                options={currencies}
                onChange={this.handlerChangeCurrency}
                className="currency-drop-down"
              />
            </Col>
            <span className="right-border-gray" />
            <Col auto className="u-margin-left condition-btn">
              <Button
                uppercase
                small
                className="height-wrap"
                onClick={this.handlerOpenCondition.bind(this, true)}
              >
                <SettingIcon color={colors.text} style={styleCondition} />
                <span>{i18n('app.components.Offer.RoomStructure.conditionText', {}, true)}</span>
              </Button>
            </Col>
          </FlexTitle>
          <RoomBodyStyle>
            <Row>
              <RoomStructureTitle>{i18n('app.components.Offer.RoomStructure.title')}</RoomStructureTitle>
            </Row>
            <Row className="u-padded-bottom-l">
              <img src={rectangle} className="u-margin-right-s u-padded-bottom-l" />
              <span className="text-notification-red">{i18n('app.components.Offer.RoomStructure.titleNotification')}</span>
            </Row>
            {table && <RoomTable
              table={table}
              errors={errors}
              sign={activeCurrency.sign}
              totalPriceWithSign={totalPriceWithSign}
              handlerOnBlurPriceInput={this.handlerOnBlurPriceInput}
              handlerChangePrice={this.handlerChangePrice}
              handlerChangeAmount={this.handlerChangeAmount}
              onToggleTable={this.handleToggleTable}
            />}
            <Row className="ui-margin-top">
              <Col className="u-margin-right u-with-fit-context">
                <MealDropDown
                  onChange={this.handlerChangeMeal}
                  meal={hotel.meal}
                  isHotelEditable={hotel.isHotelEditable}
                />
              </Col>
              <Col>
                {isShowAdditionalPayment && <AdditionalPayment
                  error={isAdditionalError}
                  onChangeText={this.handlerChangeAdditionalPayments}
                  text={textAdditionalPayments}
                />}
              </Col>
            </Row>
          </RoomBodyStyle>
          <Button
            disabled={isDisable}
            style={styleContinue}
            onClick={this.continueOffer}
            primary
            large
            uppercase
          >
            {i18n('app.components.Offer.RoomStructure.continue')}
          </Button>
        </RoomStructureContainer>
        {isOpenHotelCondition &&
          <HotelCondition
            dataHotelConfirmation={{
              errorValidTime,
              num,
              checkIn,
              checkOut,
              hotelComments,
              totalPrice,
              validTime,
              rooms,
              textAdditionalPayments,
              sign: activeCurrency.sign,
              selectedMealLabel: selectedMeal.label,
              handleChangeComment: this.handleChangeComment,
            }}
            paymentPolicy={paymentPolicy}
            hotel={hotel}
            abbr={activeCurrency.abbr}
            isOpenDirect={isOpenDirect}
            onUpdateHotel={updateHotel}
            partialCancellationComment={partialCancellationComment}
            handlerUpdateInputs={this.handlerUpdateInputs}
            onHandlerCancel={this.handlerCancelHotelCondition}
            onHandlerConfirm={this.handlerHotelConditionConfirm}
            onHandlerClose={this.handlerCancelHotelCondition}
            handleChangeValidTime={this.handleChangeValidTime}
          />
        }
        {isShowOverPricePopUp && <OverPricePopUp
          budgetMax={budgetMax}
          onHandlerClose={this.handlerCloseOverPricePopUp}
          onHandlerCancel={this.handlerCancelOverPricePopUp}
          onHandlerConfirm={this.handlerConfirmChangePrice}
        />}
        {notificationAction && <DialogNotification action={notificationAction} isOpen={notificationAction} />}
      </OfferContainer>
    );
  }
}

OfferTable.propTypes = {
  roomTypes: PropTypes.array,
  hotel: PropTypes.object,
  updateHotel: PropTypes.func,
  makeOffer: PropTypes.func,
  currencies: PropTypes.array,
  session: PropTypes.object,
};

const Composed = adopt({
  roomTypes: RoomsProvider,
  currencies: CurrencyProvider,
  hotel: HotelProvider,
  makeOffer: MakeOfferProvider,
  updateHotel: UpdateHotelProvider,
  session: SessionProvider,
  sessionsListSubscription: SubscriptionSessionProvider,
});

export default ({ sessionId }) => (
  <Composed sessionId={sessionId} subscription={SessionsListSubscription} >
    {({ session, sessionsListSubscription, ...data }) => (
      <OfferTable {...session} sessionsListSubscription={sessionsListSubscription} {...data} />
    )}
  </Composed>
);


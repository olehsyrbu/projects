import styled from 'styled-components';
import { colors } from 'app/style/variables';

export const WrapDaysPeriod = styled.span`

    display: inline-block;
    font-weight: 500;
color: ${colors.dark};
`;

export const WrapTextDays = styled.span`
    padding-left: 4px;
    display: inline-block;
    color: ${colors.dark};
    opacity: 0.6;
    font-weight: normal;
`;


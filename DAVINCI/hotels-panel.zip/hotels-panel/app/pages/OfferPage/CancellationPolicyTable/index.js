import React from 'react';
import { Row, Col } from 'app/ui';
import { WrapDaysPeriod, WrapTextDays } from './style';
import i18n from 'app/utils/i18n';

export default ({ free, periods }) => (
  <Row className="u-text-small">
    <Col xs="12">
      <Row>
        <Col width={40}>
          <WrapDaysPeriod>{free}</WrapDaysPeriod>
          <WrapTextDays>{i18n('app.components.Offer.HotelCondition.days')}</WrapTextDays>
        </Col>
        <Col width={60}>
          {i18n('app.components.Offer.HotelCondition.freeCancellation')}
        </Col>
      </Row>
      {
        periods.map(({ from, to, percent }, index) => (
        <Row key={index} >
          <Col width={40}>
            <WrapDaysPeriod>{from} - {to !== null ? to : 0 }</WrapDaysPeriod>
            <WrapTextDays>{i18n('app.components.Offer.HotelCondition.days', {}, true)} </WrapTextDays>
          </Col>
          <Col width={60}>{percent}% &nbsp; {i18n('app.components.ofPrice', {}, true)}</Col>
        </Row>))
      }
    </Col>
  </Row>
);

import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';

const AsideWrap = styled.aside`
  vertical-align:top;
  background-color: ${colors.grayBgAside};
  border-right: 1px solid ${colors.borderGray};
  padding: 24px 24px 24px calc((100vw - 1060px)/2);
  box-sizing: content-box;
  .aside-content-wrapper {
    min-width: 270px;
  }
  & + section {
    padding: 0 calc((106vw - 1160px)/2) 100px 24px;
  } 
  
  @media (max-width: 1550px) {
     & + section {
        padding: 0 calc((106vw - 1160px)/2) 100px 24px;
     } 
  }
  
  @media (max-width: 1445px) {
     & + section {
        padding: 0 calc((106vw - 1160px)/2) 100px 24px;
     } 
  }
  
  @media (max-width: 1350px) {
     & + section {
        padding: 0 calc((106vw - 1160px)/2) 100px 24px;
     } 
  }
`;

const Aside = ({ children, style }) => (
  <AsideWrap style={style} >
    <div className="aside-content-wrapper" >
      {children}
    </div>
  </AsideWrap>
);

Aside.propTypes = {
  children: PropTypes.node.isRequired,
  style: PropTypes.object,
};

export default Aside;

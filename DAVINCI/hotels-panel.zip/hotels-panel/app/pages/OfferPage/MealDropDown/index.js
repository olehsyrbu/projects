import React from 'react';
import i18n from 'app/utils/i18n';
import { Select } from 'app/ui';
import { mealDefault } from 'app/utils/global-constant';
import { HotelConditionSubTitle } from 'app/common/design/style';

class MealDropDown extends React.PureComponent {
  constructor(props) {
    super(props);
    const mealList = [
      {
        label: i18n('app.meal.BB', {}, true),
        value: 'BB',
      },
      {
        label: i18n('app.meal.CB', {}, true),
        value: 'CB',
      },
      {
        label: i18n('app.meal.AB', {}, true),
        value: 'AB',
      },
      {
        label: i18n('app.meal.NMP', {}, true),
        value: 'NMP',
      },
    ];
    const meal = mealList.find(({ label, value }) => [label, value].includes(mealDefault));
    this.state = { mealValue: meal.value, mealList };

    this.handleChangeMeal = this.handleChangeMeal.bind(this);
  }

  handleChangeMeal = event => this.setState({ mealValue: event }, this.props.onChange(this.state.mealList.find(meal => meal.value === event)));

  render() {
    const { mealValue, mealList } = this.state;
    return (
      <div>
        <HotelConditionSubTitle>
          {i18n('app.components.Offer.DropDownMealTitle')}
        </HotelConditionSubTitle>
        <Select
          options={mealList}
          value={mealValue}
          onChange={this.handleChangeMeal}
          className="meal-drop-down"
        />
      </div>
    );
  }
}

export default MealDropDown;

import React from 'react';
import { TextField } from 'app/ui';

import { getErrorData } from '../helpers';
import FakeInput from 'app/common/FakeInput';
import Center from 'app/common/design/Center';
import { colors } from 'app/style/variables';

const style = {
  width: '75px',
  inputStyle: {
    width: '75px',
    border: `1px solid ${colors.borderGray}`,
    borderRadius: '3px',
    backgroundColor: colors.light,
  },
};

const fakeInputStyle = {
  width: '75px',
  padding: '0 10px',
  textAlign: 'left',
};

export default ({
  index, handlerChangeAmount, active, name, amount, errors, onToggleTable,
}) => (
  <Center>{active ?
    <TextField
      value={amount}
      style={style}
      error={errors ? getErrorData(errors[index], 'amount') : null}
      onChange={handlerChangeAmount}
    />
    :
    <FakeInput
      style={fakeInputStyle}
      name={name}
      val={amount}
      index={index}
      onClickHandler={onToggleTable.bind(this, index)}
    />}</Center>
);

import styled from 'styled-components';
import { colors, font, fontWeight } from 'app/style/variables';

export const disableToggleStyle = {
  textTransform: 'capitalize',
  color: `${colors.grayTitle}`,
  fontWeight: `${fontWeight.bold}`,
  fontSize: `${font.m}`,
  width: '100%',
};

export const activeToggleStyle = Object.assign(disableToggleStyle, {
  color: `${colors.text}`,
});

export const FlexTitle = styled.div`
  display: flex;
  flex-direction: row;
  margin: 24px 0 18px;
`;

export const OfferContainer = styled.div`
  display: flex;
  flex:3;
  flex-direction: column;
`;

export const OfferTitle = styled.p`
  color: ${colors.dark};
  font-size: 24px;
  font-weight: ${fontWeight.bold};
  line-height: 32px;
`;

import Toggle from 'app/common/Toggle';

export const RoomStructureContainer = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  color: ${colors.text};
  font-size: ${font.m};
  .center {
    display: flex;
    align-items: center;
  }
`;

export const RoomBodyStyle = styled.div`
  width: 100%;
`;

export const RoomStructureTitle = styled.span`
  margin: 0 auto 0 0;
  color: ${colors.dark};
  font-size: ${font.m};
  padding-bottom: 8px;
  font-weight: bold;
`;

export const ToggleEl = styled(Toggle)`
  padding: 0 10px 0 0; 
`;

export const WrapDetailsRow = styled.div`
  width: 45%;
  display: flex;
  align-items: center;
  
  @media (max-width: 1080px) {
    width: 100%;
    margin-bottom: 10px;
  }
`;

export const styleDateOfferPage = {
  backgroundColor: `${colors.grayBGText}`,
  borderRadius: '4px',
  border: 'none',
  padding: '8px 12px',
  height: '100%',
};

export const styleContinue = {
  width: 'fit-content',
  marginTop: '16px',
  marginLeft: 'auto',
  letterSpacing: '0.5px',
  fontWeight: 500,
};

export const disableTextStyle = {
  color: colors.text,
  opacity: 0.35,
  fontWeight: 500,
  textTransform: 'capitalize',
};

export const styleDateInput = { width: 140 };
export const styleColorLabel = { color: colors.grayWhiteText };
export const styleCondition = { height: '15px', width: '15px' };
export const styleValidTime = { style: { width: '100px', display: 'inline-block' }, inputStyle: { width: 100 } };
export const styleTextDate = { color: colors.text, fontWeight: 500 };

export const styleTitleValidTime = {
  paddingBottom: '5px',
  fontSize: '16px',
};

export const Row = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;

export const DateStyle = styled.span`
  color: ${colors.grayDarkText};
  opacity: 0.6;
  font-size: 14px;
`;

export const WrapHotel = styled.div`
  display: flex;
    margin-left: auto;
`;
export const WrapHotelInfo = styled.div`
   display: flex;
`;

export const WrapImageLogo = styled.div`
  display: flex;
  padding-right: 18px;
`;

export const WrapTextHotel = styled.div`
  display: flex;
  flex-direction: column;
`;


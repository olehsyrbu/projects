import moment from 'moment/moment';
import { extendMoment } from 'moment-range/dist/moment-range';

const extendedMoment = extendMoment(moment);

import { round, ceil } from 'lodash';
import { changeNumberToPrice } from 'app/utils';
import { getRoomDays } from 'app/utils/sessions';
import {
  rooms as roomsGlobal,
  ROOM_TYPE_SINGLE,
  ROOM_TYPE_DOUBLE,
  ROOM_TYPE_TWIN,
  ROOM_TYPE_TRIPLE,
  ROOM_TYPE_QUAD,
  DAYS_OF_THE_WEEK,
  MSEC_IN_DAY,
} from 'app/utils/global-constant';

const getPricePrevValueByTypeRoom = (abbr, { lastOffer }) => {
  if (lastOffer === null) {
    lastOffer = {
      singleLocalCost: 0,
      twinLocalCost: 0,
      doubleLocalCost: 0,
      tripleLocalCost: 0,
      quadLocalCost: 0,
    };
  }

  switch (abbr) {
    case ROOM_TYPE_SINGLE:
      return lastOffer.singleLocalCost || 0;
    case ROOM_TYPE_TWIN:
      return lastOffer.twinLocalCost || 0;
    case ROOM_TYPE_DOUBLE:
      return lastOffer.doubleLocalCost || 0;
    case ROOM_TYPE_TRIPLE:
      return lastOffer.tripleLocalCost || 0;
    case ROOM_TYPE_QUAD:
      return lastOffer.quadLocalCost || 0;
    default:
      return 0;
  }
};

const getPriceTotal = (amount, priceOne, days) => +amount * +priceOne * +days;

export const getPricePerPerson = (abbr, price) => {
  price = Number(price);
  switch (abbr) {
    case ROOM_TYPE_SINGLE:
      return price;
    case ROOM_TYPE_TWIN:
    case ROOM_TYPE_DOUBLE:
      return round((price / 2), 2);
    case ROOM_TYPE_TRIPLE:
      return round((price / 3), 2);
    case ROOM_TYPE_QUAD:
      return round((price / 4), 2);
    default:
      return 0;
  }
};

export const createTable = ({
  rooms,
  checkIn,
  checkOut,
  hotel,
}) => {
  const { proposals = [] } = hotel;
  const days = getRoomDays({ checkIn, checkOut });
  const checkInTime = moment(checkIn).valueOf();
  const checkOutTime = moment(checkOut).valueOf();

  return roomsGlobal.map((roomType) => {
    const roomFiltered = rooms && rooms.find(r => r.room.name === roomType.abbr);
    const amount = roomFiltered ? Number(roomFiltered.amount) : 0;
    const priceOne = getPricePrevValueByTypeRoom(roomType.abbr, hotel);
    const pricePerPerson = getPricePerPerson(roomType.abbr, priceOne);
    let isUserCanChangePrice = false;
    let totalPrice = 0;
    let totalDaysWithPrice = 0;

    for (let dayTime = checkInTime; dayTime <= checkOutTime; dayTime += MSEC_IN_DAY) {
      const dayIndex = (new Date(dayTime)).getDay();
      const dayName = DAYS_OF_THE_WEEK[dayIndex];
      let hasMatch = false;

      for (let propI = 0, len = proposals.length; propI < len; propI++) {
        const {
          from, to, rooms, weekdays,
        } = proposals[propI];

        const proposalRange = extendedMoment.range(from, to);

        if (proposalRange.contains(dayTime) && weekdays.includes(dayName)) {
          const proposalRoom = rooms.find(r => r.room === roomType._id);
          if (proposalRoom.price) {
            totalPrice += proposalRoom.price;
            hasMatch = true;
            isUserCanChangePrice = false;
            totalDaysWithPrice++;
          }
        }
      }

      if (!hasMatch) {
        isUserCanChangePrice = true;
      }
    }

    const price = totalDaysWithPrice ? round(totalPrice / totalDaysWithPrice, 1) : priceOne;

    return {
      days,
      amount,
      name: roomType.abbr,
      active: !!roomFiltered,
      priceTotal: price ? ceil(getPriceTotal(amount, price, days), 2) : 0,
      priceOne: changeNumberToPrice(price) || 0,
      pricePerPerson: pricePerPerson || 0,
      isUserCanChangePrice,
    };
  });
};

export const recalculatePriceTotal = (amount, days, priceOne) => ceil(round(getPriceTotal(amount, days, priceOne), 1), 2);

export const getErrorData = (error, value) => (error && error[value] && error[value].errorText ? { ...error[value].errorText } : null);

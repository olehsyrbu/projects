import React from 'react';
import i18n from 'app/utils/i18n';
import TextInputWithTitle from 'app/common/TextInputWithTitle';

const Comment = ({ onChangeComment, text }) => (
  <TextInputWithTitle
    styleTitle={{ marginTop: '16px' }}
    title={i18n('app.components.Request.yourComment')}
    placeholder={i18n('app.components.commentPlaceHolder', {}, true)}
    name="hotelComments"
    text={text}
    onChangeText={onChangeComment}
  />
);

Comment.displayName = 'Comment';

export default Comment;

import React from 'react';
import i18n from 'app/utils/i18n';
import IconInfo from 'app/common/IconInfo';
import DatePicker from 'app/common/DatePicker';
import { DEFAULT_LOCALE } from 'app/utils/global-constant';
import { styleColorLabel, styleDateInput, ToggleEl, WrapDetailsRow } from '../style';

export default ({
  onReservationDate, onToggleReservationsDate, showConfirmReservation, checkIn, date,
}) => (<WrapDetailsRow>
  <ToggleEl
    className="conf-reservation"
    labelStyle={styleColorLabel}
    onToggle={onToggleReservationsDate}
    defaultToggled={showConfirmReservation}
    labelPosition="right"
  />
  {showConfirmReservation ?
    <span className="center"> {i18n('app.components.Offer.RoomStructure.optionalReservationText')}
      <IconInfo
        text={i18n('app.components.Offer.RoomStructure.optionalReservationHint')}
        className="opt-reservation-hint"
      />
      <DatePicker
        locale={localStorage.getItem('selectedNewLanguage') || DEFAULT_LOCALE}
        name="showConfirmReservation"
        value={date}
        onChange={onReservationDate}
        minDate={new Date()}
        maxDate={checkIn && new Date(checkIn)}
        style={date instanceof Date ? styleDateInput : { ...styleDateInput, borderColor: 'red' }}
        autoOk
      />
    </span>
    : <span className="center"> {i18n('app.components.Offer.RoomStructure.onlyForConfirmationText')}
      <IconInfo text={i18n('app.components.Offer.RoomStructure.onlyForConfirmationHint')} />
      </span>
  }
</WrapDetailsRow>);


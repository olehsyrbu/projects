import React from 'react';
import PropTypes from 'prop-types';
import { adopt } from 'react-adopt';
import InfoRequestProvider from 'app/providers/Requests/InfoRequestProvider';

import IconInfo from 'app/common/IconInfo';
import { Row } from 'app/common/OfferPageInfoWrap/style';
import Wrapper from 'app/common/OfferPageInfoWrap';
import Rating from 'app/common/SentedOffer/Rating';
import i18n from 'app/utils/i18n';

const RequestInfo = ({
  cityTax, sessionRequestComment, budgetValue, budgetSignText, stars,
} = {}) => (
  <Wrapper title={i18n('app.components.HotelCondition.Info.titleRequestInfo')} >
    <Row>
      <span className="label">
        <span className="ui-text-gray">
          {i18n('app.components.HotelCondition.Info.category')}
        </span>
      </span>
      <span className="text">
        <Rating rating={stars} />
      </span>
    </Row>
    <Row>
      <span className="label budgetLabel">
        <span className="ui-text-gray">{i18n('app.components.Request.budget')}</span>
        <IconInfo
          text={i18n('app.components.HotelCondition.Info.budgetHint')}
          id="app.components.HotelCondition.Info.budgetHint"
        />
      </span>
      <span className="text">{budgetValue}{budgetSignText}</span>
    </Row>
    <Row>
      <span className="label">
        <span className="ui-text-gray">{i18n('app.components.Request.city_tax')}</span>
        <IconInfo
          text={i18n('app.components.HotelCondition.Info.cityTaxHint')}
          id="app.components.HotelCondition.Info.cityTaxHint"
        />
      </span>
      <span className="text">{cityTax}</span>
    </Row>
    <Row>
      <span className="multiLine" >
        <span className="label">
          <span className="ui-text-gray">
            {i18n('app.components.Request.comment')}
          </span>
        </span>
      </span>
      <span className="text">{sessionRequestComment || '-' }</span>
    </Row>
  </Wrapper>
);

RequestInfo.propTypes = {
  stars: PropTypes.array,
  cityTax: PropTypes.object,
  budgetValue: PropTypes.string,
  sessionRequestComment: PropTypes.string,
};

const Composed = adopt({
  requestInfo: InfoRequestProvider,
});

export default ({ sessionId }) => (
  <Composed sessionId={sessionId}>
    {({ requestInfo }) => (<RequestInfo {...requestInfo} />)}
  </Composed>
);

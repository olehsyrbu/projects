import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

import Aside from 'app/pages/OfferPage/Aside';
import OfferTable from 'app/pages/OfferPage/OfferTable';
import InfoRequest from 'app/pages/OfferPage/RequestInfo';
import AdditionalInfo from 'app/pages/OfferPage/AdditionalInfo/index';
import FlexRow from 'app/common/design/FlexRow';

const OfferStyle = styled(FlexRow)`
  padding-top: 70px;
  display: flex;
  flex: 1;
  height: 100%;
`;

const Section = styled.section`
  display: flex;
  flex: 3;
`;

const OfferDetailPage = ({ match: { params: { _id } } }) => (
  <OfferStyle>
    <Aside>
      <AdditionalInfo sessionId={_id} />
      <InfoRequest sessionId={_id} />
    </Aside>
    <Section>
      <OfferTable sessionId={_id} />
    </Section>
  </OfferStyle>
);

OfferDetailPage.propTypes = {
  match: PropTypes.object,
};

export default OfferDetailPage;


import React from 'react';
import IconInfo from 'app/common/IconInfo';
import i18n from 'app/utils/i18n';
import Bold from 'app/common/design/Bold';
import { Row, styleTitleValidTime } from '../style';
import DatePicker from './DatePicker';

export default ({ validTime, errorValidTime, onChangeValidTime }) => (
  <div>
    <Bold style={styleTitleValidTime} className="ui-flex">
      {i18n('app.components.offerValid')}
      <IconInfo
        place="bottom"
        className="ui-valid-tip"
        text={i18n('app.components.Offer.RoomStructure.offerIsValidHint')}
        id="app.components.Offer.RoomStructure.offerIsValidHint"
      />
    </Bold>
    <Row className="u-text-font-500 ui-gray-text u-text-small">
      {i18n('app.components.SentOffers.Till')}
    </Row>
    <div className="u-margin-bottom">
      <DatePicker
        error={errorValidTime}
        Time={validTime}
        onChange={onChangeValidTime}
      />
    </div>
  </div>
);

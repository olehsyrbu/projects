import React from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import ExpandMore from 'app/ui/icons/ExpandMore';
import styled from 'styled-components';

const Wrap = styled.div`
input {
    border: ${props => (props.error ? '1px solid red' : '1px solid #D6D6D6')};
}
`;

const ImageWrap = styled.div`
    display: inline-block;
    left: -27px;
    position: relative;
    top: 6px;
`;

const getMinTime = () => {
  const time = new Date();
  if (time.getMinutes() > 0) {
    time.setHours(time.getHours() + 1);
    time.setMinutes(0);
    time.setSeconds(0);
  }
  return time;
};

const getNoonTime = () => {
  const noon = new Date();
  if (noon.getHours() >= 12) {
    noon.setDate(noon.getDate() + 1);
  }
  noon.setHours(12);
  noon.setMinutes(0);
  noon.setSeconds(0);
  return noon;
};

const DatePickerComp = ({ Time, error, onChange }) => (
    <Wrap error={error}>
    <DatePicker
      selected={Time}
      minDate={new Date()}
      minTime={getMinTime()}
      maxTime={getNoonTime()}
      onChange={date => onChange(date)}
      showTimeSelect
      timeFormat="HH:mm"
      dateFormat="dd/MM/yyyy HH:mm"
    />
    <ImageWrap><ExpandMore /></ImageWrap>
    </Wrap>
);

export default DatePickerComp;

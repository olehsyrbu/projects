import { colors, font } from 'app/style/variables';
import styled from 'styled-components';

export const Header = styled.h2`
  margin: 0 0 12px;
  width: 100%;
  font-size: ${font.xl};
  font-weight: 900;
`;

export const ColumnWrap = styled.span`
  font-weight: 500;
`;

export const TextTitle = styled.span`
  color: ${colors.grayLightText};
  opacity: .6;
  font-size: 12px;
  font-weight: normal;
`;

export const Text = styled.div`
  font-size: 14px;
  line-height: 21px;
`;

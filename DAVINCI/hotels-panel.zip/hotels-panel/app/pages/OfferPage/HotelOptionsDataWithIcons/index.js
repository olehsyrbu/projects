import React from 'react';
import { Col, Row } from 'app/ui';
import IconInfo from 'app/common/IconInfo';
import { Title } from 'app/common/design/style';
import { ColumnWrap, TextTitle } from './style';
import ImageIcon from 'app/common/design/ImageIcon';

import mealIcon from 'app/media/MealNew.svg';
import focIcon from 'app/media/foc.svg';
import cityTaxIcon from 'app/media/CityTaxNew.svg';
import reservationIcon from 'app/media/PaymentPolicyNew.svg';
import i18n from 'app/utils/i18n';

const SizeLeftColumn = 5;
const SizeRightColumn = 7;

export default ({
  mealValue, foc, cityTaxValue, paymentPolicy, textAdditionalPayments,
}) => (
  <div className="u-text-small">
    <Title>
      {i18n('app.components.Offer.RoomStructure.titleHotelOption')}
    </Title>
    <Row >
      <Col xs={SizeLeftColumn} width={40}>
        <ImageIcon src={mealIcon} />
        <TextTitle>
          {i18n('app.components.SentOffers.meal')}
        </TextTitle>
      </Col>
      <Col xs={SizeRightColumn} width={70}>
        <ColumnWrap >
          {mealValue || i18n('app.components.OfferHotelInfo.none')}
        </ColumnWrap>
      </Col>
    </Row>
    {textAdditionalPayments &&
      <Row >
        <Col xs={SizeLeftColumn} width={40} className="ui-flex">
          <ImageIcon src={mealIcon} />
          <TextTitle className="ui-flex">
            {i18n('app.components.fullBoardPayment')}
          </TextTitle>
          <IconInfo
            place="right"
            text={i18n('app.components.fullBoardPaymentHint')}
            id="app.components.fullBoardPaymentHint"
          />
        </Col>
        <Col xs={SizeRightColumn} width={70}>
          <ColumnWrap >
            {textAdditionalPayments}
          </ColumnWrap>
        </Col>
      </Row>
    }
    <Row >
      <Col xs={SizeLeftColumn} width={40}>
        <ImageIcon src={focIcon} />
        <TextTitle>
          {i18n('app.components.withFoc')}
        </TextTitle>
      </Col>
      <Col xs={SizeRightColumn} width={70}>
        <ColumnWrap>
          {foc
            ? i18n('app.components.OfferHotelInfo.focTextPerson', { foc })
            : i18n('app.components.OfferHotelInfo.none')
          }
        </ColumnWrap>
      </Col>
    </Row>
    <Row >
      <Col xs={SizeLeftColumn} width={40}>
        <ImageIcon src={cityTaxIcon} />
        <TextTitle>
          {i18n('app.components.Request.city_tax')}
        </TextTitle>
      </Col>
      <Col xs={SizeRightColumn} width={70}>
        <ColumnWrap>
          {cityTaxValue || i18n('app.components.includedInPrice')}
        </ColumnWrap>
      </Col>
    </Row>
    {
      paymentPolicy &&
      <Row >
        <Col xs={SizeLeftColumn} width={40}>
          <ImageIcon src={reservationIcon} />
          <TextTitle>
            {i18n('app.components.paymentPolicy')}
          </TextTitle>
        </Col>
        <Col xs={SizeRightColumn} width={70}>
          <ColumnWrap>
            {paymentPolicy}
          </ColumnWrap>
        </Col>
      </Row>
    }
  </div>
);

import React from 'react';
import Center from 'app/common/design/Center';
import IconPerson from 'app/media/single_blue.svg';

import InputPrice from 'app/common/InputPrice';
import FakeInput from 'app/common/FakeInput';
import styled from 'styled-components';
import { colors } from 'app/style/variables';
import { getCapacity } from 'app/utils/rooms';

export const WrapStyleRoomIcon = styled.span`
  padding-right: 10px;
  font-weight: 600;
  color: ${colors.blueText};
`;

const ImgWrap = styled.img`
  width: 8px;
`;
const style = {
  inputStyle: {
    width: '120px',
    borderRadius: '3px',
    backgroundColor: colors.light,
  },
};
const fakeInputStyle = {
  width: '120px',
  padding: '0 10px',
  textAlign: 'left',
};

import { getErrorData } from '../helpers';

const getIcon = name =>
  [...Array(getCapacity(name))]
    .map((e, i) => <ImgWrap src={IconPerson} key={i} />);

const getIconBlock = name => (
  <WrapStyleRoomIcon>
    {getIcon(name)}
  </WrapStyleRoomIcon>
);

export default ({
  handlerOnBlurPriceInput, errors, sign, index, name, priceOne, onToggleTable, handlerChangePrice, isUserCanChangePrice, active,
}) => (
  <Center>
    {getIconBlock(name)}
    {active && isUserCanChangePrice ?
        (<InputPrice
          style={style}
          floatingLabelText={sign}
          name={name}
          value={priceOne}
          onBlur={handlerOnBlurPriceInput}
          error={errors && getErrorData(errors[index], 'priceOne') && true}
          onChange={handlerChangePrice}
        />)
      : (
        <FakeInput
          name={name}
          val={priceOne}
          style={fakeInputStyle}
          onClickHandler={onToggleTable.bind(this, index)}
        />
      )
    }
  </Center>
);

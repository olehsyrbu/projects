import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import Paper from 'material-ui/Paper';
import Dialog from 'material-ui/Dialog';
import Close from 'app/common/CloseBtn';
import BtnGroup from 'app/common/BtnGroup';
import srcSvgInfo from 'app/media/ic_ done.svg';
import { withRouter } from 'react-router';

const msg = {
  text: budgetMax => <FormattedMessage id="app.components.overPrice.text" values={{ budgetMax: <span style={{ color: 'orange' }}>{`${budgetMax}€`}</span> }} />,
};

import {
  dialogOverPriceContentStyle,
  dialogBodyStyle,
  styleClosePopUp,
  styleError,
  styleBtnCancel,
  PaperStyle,
  ImgWrap,
  Header,
  WrapTitle,
  WrapText,
  WrapTextFooter,
  FooterOverPrice,
  SrcSvgInfoNoticeWrap,
  Row,
} from './style';

import i18n from 'app/utils/i18n';

const OverPricePopUp = ({
  onHandlerClose, onHandlerCancel, onHandlerConfirm, budgetMax, match: { params: { hotelId } },
}) => (
  <Dialog
    modal={false}
    contentStyle={dialogOverPriceContentStyle}
    bodyStyle={dialogBodyStyle}
    open
    autoScrollBodyContent
  >
    <Paper zDepth={0} style={PaperStyle}>
      <Close onClose={onHandlerClose} styleClose={styleClosePopUp} />
      <Header>
        <ImgWrap src={srcSvgInfo} />
        <WrapTitle>{i18n('app.components.overPrice.title')}</WrapTitle>
      </Header>
      <WrapText>
        {msg.text(budgetMax)}
      </WrapText>
      <BtnGroup
        size={46}
        className="hotel-conditions-btns"
        style={styleBtnCancel}
        onClickCancel={onHandlerCancel}
        onClickConfirm={onHandlerConfirm}
        labelCancel={i18n('app.components.overPrice.continueBtn')}
        labelConfirm={i18n('app.components.overPrice.updateOffer')}
      />
      <FooterOverPrice>
        <Row>
          <SrcSvgInfoNoticeWrap style={styleError} />
          <WrapTextFooter>{i18n('app.components.overPrice.textRoomCompetitive')}</WrapTextFooter>
        </Row>
        <Row>
          <SrcSvgInfoNoticeWrap style={styleError} />
          <WrapTextFooter>
            {i18n('app.components.overPrice.textBudgetToLow')}
            <a href={`/${hotelId}/settings`} target="_blank"> {i18n('app.components.textHere')}</a>
          </WrapTextFooter>
        </Row>
      </FooterOverPrice>
    </Paper>
  </Dialog>
);

OverPricePopUp.propTypes = {
  onHandlerClose: PropTypes.func,
  onHandlerCancel: PropTypes.func,
  onHandlerConfirm: PropTypes.func,
  budgetMax: PropTypes.string,
};

export default withRouter(OverPricePopUp);

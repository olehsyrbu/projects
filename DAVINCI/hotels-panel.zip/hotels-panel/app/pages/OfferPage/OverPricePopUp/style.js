import styled from 'styled-components';
import SrcSvgInfoNotice from 'material-ui/svg-icons/alert/error-outline';
import { colors, font } from 'app/style/variables';

export const dialogBodyStyle = {
  width: '100%',
  padding: 0,
};

export const dialogOverPriceContentStyle = {
  width: '520px',
  maxWidth: 'none',
};

export const SrcSvgInfoNoticeWrap = styled(SrcSvgInfoNotice)`
  flex: 1;
`;

export const PaperStyle = {
  position: 'relative',
  display: 'flex',
  flexDirection: 'column',
};

export const ImgWrap = styled.img`
  padding-right: 10px;
`;

export const Header = styled.h2`
  margin: 0 0 32px;
  width: 100%;
  font-size: ${font.xl};
  font-weight: 600;
  display: flex;
  padding: 24px;
  box-shadow: 0 1px 12px 0 rgba(0,0,0,0.1), 0 1px 0 0 ${colors.grayWhite};
`;

export const WrapTitle = styled.div`
  color: ${colors.dark};
  font-size: ${font.ml};
  font-weight: bold;
  line-height: 20px;
  margin-right: 20px;
`;

export const styleError = {
  color: 'orange',
};

export const styleBtnCancel = {
  padding: '24px',
};

export const WrapText = styled.div`
  color: ${colors.dark};
  font-size: ${font.l};
  font-weight: bold;
  line-height: 28px;
  text-align: center;
  padding: 24px;
`;

export const FooterOverPrice = styled.div`
  padding: 24px;
  font-size: 12px;
  border-radius: 0 0 2px 2px;
  background-color: ${colors.grayWhiteBG};
  box-shadow: inset 0 -1px 0 0 ${colors.grayWhite}, inset 0 1px 0 0 ${colors.grayWhite};
`;

export const WrapTextFooter = styled.p`
  flex: 14;
`;

export const Row = styled.div`
  display: flex;
  flex:1;
`;

export const styleClosePopUp = {
  top: '30px',
};

import React from 'react';
import PropTypes from 'prop-types';
import { adopt } from 'react-adopt/dist/index';
import AdditionInfoProvider from 'app/providers/Requests/AdditionInfoProvider';

import Location from 'app/common/Location';
import RoomStructureInfo from 'app/common/RoomStructureInfo';
import IconInfo from 'app/common/IconInfo';
import Wrapper from 'app/common/OfferPageInfoWrap';
import { Row } from 'app/common/OfferPageInfoWrap/style';
import Loading from 'app/common/Loading';
import i18n from 'app/utils/i18n';

class AdditionalInfo extends React.PureComponent {
  render() {
    const {
      num,
      meal,
      rooms,
      radius,
      loading,
      cityName,
      periodDates,
      groupTypeValue,
    } = this.props;
    if (loading) return <Loading />;
    return (
      <Wrapper title={i18n('app.components.HotelCondition.Info.title')} >
        <Row>
          <span className="label">
            <span className="ui-text-gray">
              {i18n('app.components.HotelCondition.Info.id')}
            </span>
            <IconInfo
              text={i18n('app.components.HotelCondition.Info.idHint')}
              id="app.components.HotelCondition.Info.idHint"
            />
          </span>
          <span className="text">{num}</span>
        </Row>
        <Row>
          <span className="label">
            <span className="ui-text-gray">
              {i18n('app.components.HotelCondition.Info.period')}
            </span>
          </span>
          <span className="text">{periodDates}</span>
        </Row>
        <Row>
          <span className="label">
            <span className="ui-text-gray">
              {i18n('app.components.HotelCondition.Info.rooms')}
            </span>
            <IconInfo
              text={i18n('app.components.HotelCondition.Info.roomsHint')}
              id="app.components.HotelCondition.Info.roomsHint"
            />
          </span>
          {rooms && <span className="text"><RoomStructureInfo rooms={rooms} /></span>}
        </Row>
        <Row>
          <span className="label">
          <span className="ui-text-gray">
            {i18n('app.components.HotelCondition.Info.meal')}
          </span>
            <IconInfo
              text={i18n('app.components.HotelCondition.Info.mealHint')}
              id="app.components.HotelCondition.Info.mealHint"
            />
          </span>
          <span className="text">{meal}</span>
        </Row>
        <Row>
          <span className="label">
            <span className="ui-text-gray">
              {i18n('app.components.Reservations.groupType')}
            </span>
          </span>
          <span className="text">
        <span className="text">{groupTypeValue}</span>
      </span>
        </Row>
        <Row>
          <span className="label">
            <span className="ui-text-gray">
              {i18n('app.components.HotelCondition.Info.location')}
            </span>
          </span>
          <span className="text">
        <Location city={cityName} radius={radius} hasIcon={false} />
      </span>
        </Row>
      </Wrapper>
    );
  }
}

AdditionalInfo.propTypes = {
  num: PropTypes.string,
  meal: PropTypes.oneOfType(PropTypes.string, PropTypes.object),
  periodDates: PropTypes.string,
  cityName: PropTypes.string,
  groupTypeValue: PropTypes.string,
  rooms: PropTypes.array,
  radius: PropTypes.number,
};

const Composed = adopt({
  additionInfo: AdditionInfoProvider,
});

export default ({ sessionId }) => (
  <Composed sessionId={sessionId}>
    {({ additionInfo }) => (<AdditionalInfo {...additionInfo} sessionId={sessionId} />)}
  </Composed>
);

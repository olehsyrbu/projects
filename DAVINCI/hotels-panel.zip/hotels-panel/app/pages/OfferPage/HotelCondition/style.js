import styled from 'styled-components';
import { colors, font } from 'app/style/variables';
import Flex from 'app/common/design/Flex';
import FlexOne from 'app/common/design/FlexOne';

export const Header = styled.h2`
  margin: 0 0 32px;
  width: 100%;
  font-size: ${font.xl};
  font-weight: 600;
`;

export const Row = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  width: 100%;
  font-size: ${font.m};
  flex-direction: row;
  &:not(:last-child) {
    padding-bottom: 20px;
    border-bottom: 1px solid ${colors.grayWhiteText};
    margin-bottom: 20px;
  }
`;

export const styleFakeInputCancellationPolicy = {
  padding: '0px 10px',
  opacity: '1',
};

export const FlexRow = styled(Flex)`
  height: 36px;
  border: 1px solid ${colors.borderGray};
  border-bottom: none;
  position: relative;
  :last-child {
     border-bottom: 1px solid ${colors.borderGray};
     border-radius: 0 0 4px 4px;
   }
`;

export const FlexOneCell = styled(FlexOne)`
  padding: 2px 16px;
  text-transform: uppercase;
  font-size: 14px;
  font-weight: 500;
  color: ${colors.text};
  line-height: 30px;
  height: 35px;
  label:first-letter {
    text-transform: capitalize;
  }
  .label {
    padding-left: 10px;
    color: ${colors.grayText85};
    font-size: 14px;
    font-weight: normal;
    line-height: 24px;
    text-transform: none;
    display: inline-block;
  }
  .icon-delete {
    opacity: 0;
  }
  &:hover {
    .icon-delete {
      opacity: 1;
    }
  }
  :last-child{
    .central.text {
      padding: 10px;
    }
  }
  .text {
    text-transform: lowercase;
  }
`;

export const FlexOneCellHeader = styled(FlexOneCell)`
  color: ${colors.text6};
  font-weight: 500;
  font-size: 11px;
  line-height: 30px;
  height: 32px;
  text-align: ${props => (props.right ? 'right' : 'left')};
`;

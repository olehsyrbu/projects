import React from 'react';
import PropTypes from 'prop-types';
import i18n from 'app/utils/i18n';

import InputLabel from 'app/common/InputLabel';
import Delete from 'app/common/DeleteBtn';
import FakeInput from 'app/common/FakeInput';
import TableHeaderRow from 'app/common/design/TableHeaderRow';
import {
  styleFakeInputCancellationPolicy,
  FlexOneCell,
  FlexOneCellHeader,
  FlexRow,
} from './style';

const CancellationPolicyTable = ({
  onChangeToDaysValue,
  onChangePercentValue,
  onDeletePeriod,
  isHotelEditable,
  periods,
}) => (
  <div>
    <TableHeaderRow>
      <FlexOneCellHeader>
        {i18n('app.components.Offer.HotelCondition.daysBeforeArrival')}
      </FlexOneCellHeader>
      <FlexOneCellHeader right>
        {i18n('app.components.Offer.HotelCondition.ofTotalamount')}
      </FlexOneCellHeader>
    </TableHeaderRow>
    {periods.map(({
      from, to, percent, hasCollision, hasCollisionPercent,
    }, index) => (
      <FlexRow key={index}>
        <FlexOneCell>
          <span className="text" >
            {from}
            {index !== 0 &&
              <span className="label">
                {i18n('app.components.Offer.HotelCondition.days', {}, true)}
              </span>
            }
          </span>
        </FlexOneCell>
        <FlexOneCell>
          <div className="central" >
            { periods.length - 1 !== index
              ? <InputLabel
                error={hasCollision}
                disabled={!isHotelEditable}
                value={to}
                style={{ floatingLabelStyle: { 'text-transform': 'capitalize' } }}
                floatingLabelText={i18n('app.components.Offer.HotelCondition.days')}
                onChange={onChangeToDaysValue.bind(this, index)}
              />
              : <FakeInput val={0} style={styleFakeInputCancellationPolicy} />
            }
          </div>
        </FlexOneCell>
        <FlexOneCell>
          <div>{index === 0
            ? <span className="text">{percent}</span>
            : <InputLabel
              error={hasCollisionPercent}
              disabled={!isHotelEditable}
              value={percent}
              floatingLabelText="%"
              onChange={onChangePercentValue.bind(this, index)}
              {...{ 'data-row': index }}
            />
          }</div>
          {!isHotelEditable || periods.length === 2 || index === 0 ? null :
            (<Delete className="icon-delete" onClick={onDeletePeriod.bind(this, index)} />)
          }
        </FlexOneCell>
      </FlexRow>
    ))}
  </div>
);

CancellationPolicyTable.propTypes = {
  onChangeToDaysValue: PropTypes.func,
  periods: PropTypes.array,
  onDeletePeriod: PropTypes.func,
};

export default CancellationPolicyTable;

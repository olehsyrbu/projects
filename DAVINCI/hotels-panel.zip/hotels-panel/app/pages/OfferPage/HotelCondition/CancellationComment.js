import React from 'react';
import i18n from 'app/utils/i18n';
import TextInputWithTitle from 'app/common/TextInputWithTitle';

const CancellationComment = ({ onChangeText, text }) => (
  <TextInputWithTitle
    title={i18n('app.components.CancellationComment.title')}
    placeholder={i18n('app.components.Placeholder', {}, true)}
    onChangeText={onChangeText}
    text={text}
  />
);

CancellationComment.displayName = 'CancellationComment';

export default CancellationComment;

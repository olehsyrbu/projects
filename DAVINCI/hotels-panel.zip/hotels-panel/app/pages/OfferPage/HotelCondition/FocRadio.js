/* eslint-disable jsx-quotes */
import React from 'react';
import i18n from 'app/utils/i18n';
import { colors } from 'app/style/variables';

import IconInfo from 'app/common/IconInfo';
import InputLabel from 'app/common/InputLabel';
import Bold from 'app/common/design/Bold';
import TextCenterHeight from 'app/common/design/TextCenterHeight';
import { FocStyle, Row, RowFocBlock, styleBodyTextarea } from 'app/common/design/style';
import { FOC, NO_FOC } from 'app/utils/global-constant';
import { Radio } from 'app/ui';

export default ({
  isHotelEditable, className, radioValue,
  // defaultSelected,
  focValue, handlerChangeFoc, handlerChangeValue, errors,
}) => (<FocStyle className={`${className}`}>
  <TextCenterHeight>
    <Bold>
      {i18n('app.components.Offer.RoomStructure.focText')}
    </Bold>
    <span style={{ color: `${colors.grayText85}`, paddingLeft: '5px' }}>
      {i18n('app.components.Offer.RoomStructure.focTextSubtext')}
    </span>
    <IconInfo
      place="bottom"
      className="ui-tip-foc"
      text={i18n('app.components.Offer.RoomStructure.focHint')}
      id="app.components.Offer.RoomStructure.focHint"
    />
  </TextCenterHeight>
  <div className={`${!isHotelEditable && 'ui-disable-radio'} u-margin-top-s`}>
    <Radio
      disabled={!isHotelEditable}
      value={NO_FOC}
      checked={radioValue === NO_FOC}
      onChange={handlerChangeFoc}
    >
      <span className="u-radio-btn-text">
        {i18n('app.components.withoutFoc', {}, true)}
      </span>
    </Radio>
    <Radio
      disabled={!isHotelEditable}
      value={FOC}
      checked={radioValue === FOC}
      onChange={handlerChangeFoc}
    >
    <span className="u-radio-btn-text">
      {i18n('app.components.withFoc', {}, true)}
    </span>
    </Radio>
  </div>
  {radioValue === FOC &&
    <Row style={styleBodyTextarea}>
      <RowFocBlock>
        <InputLabel
          type="number"
          label={i18n('app.components.Offer.HotelCondition.focEvery')}
          value={focValue}
          disabled={!isHotelEditable}
          error={errors && errors.focEveryValue && true}
          floatingLabelText={i18n('app.components.Offer.HotelCondition.person')}
          onChange={handlerChangeValue}
        />
      </RowFocBlock>
      <div>
        <InputLabel
          className="fake-input"
          label={i18n('app.components.Offer.HotelCondition.focFree')}
          value="Twin"
          disabled
        />
      </div>
    </Row>
  }
</FocStyle>);

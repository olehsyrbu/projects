import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { size, isNaN, isEmpty, isFunction, last } from 'lodash';
import i18n from 'app/utils/i18n';
import { Dialog, Button, TR as Row, TD as Cell } from 'app/ui';
import {
  focDefault,
  defValueCurrency,
  NO_FOC,
  FOC,
  CITY_TAX_INCLUDED,
  CITY_TAX_NOT_INCLUDED,
  defaultCancellationPolicy,
  MAX_INPUT_SIZE,
} from 'app/utils/global-constant';
import { getCityTaxValue, hasCollision, checkCancellation } from 'app/utils';
import validationData from './validation';
import Add from 'app/common/Add';
import CityTax from './CityTax';
import FocRadio from './FocRadio';
import CancellationPolicyTable from './CancellationPolicyTable';
import HotelConfirmation from 'app/pages/OfferPage/HotelConfirmation';
import CancellationComment from './CancellationComment';
import HotelPaymentPolicy from './HotelPaymentPolicy';
import { HotelConditionTitle } from 'app/common/design/style';
import IconClose from 'app/ui/icons/CloseAnim';
import Toastr from 'app/common/Toastr';

class HotelCondition extends PureComponent {
  constructor(props) {
    super(props);
    this.state = this.initState(props);
    this.handlerChangeFoc = this.handlerChangeFoc.bind(this);
    this.handlerChangeCityTax = this.handlerChangeCityTax.bind(this);
    this.handlerPrepareCancellationData = this.handlerPrepareCancellationData.bind(this);
    this.handlerChangeCityTaxValue = this.handlerChangeCityTaxValue.bind(this);
    this.handlerChangePartialCancellationComment = this.handlerChangePartialCancellationComment.bind(this);
    this.handlerChangePaymentPolicy = this.handlerChangePaymentPolicy.bind(this);
    this.handlerCloseCancellationTip = this.handlerCloseCancellationTip.bind(this);
  }

  initState({
    hotel: {
      cancellationPolicy, cityTax, foc, isHotelEditable,
    } = {},
    partialCancellationComment,
    paymentPolicy,
  }) {
    const taxValue = getCityTaxValue(cityTax);
    const periods = [...cancellationPolicy.periods] || [];
    const freeCancellationDays = cancellationPolicy ? cancellationPolicy.free : 0;

    periods.unshift({
      isFirst: true,
      to: freeCancellationDays,
      from: i18n('app.components.Offer.HotelCondition.freeCancel'),
      percent: i18n('app.components.Offer.HotelCondition.freeCancellation'),
    });

    const newPeriods = size(periods)
      ? this.setPeriods(checkCancellation(periods), freeCancellationDays)
      : defaultCancellationPolicy.periods;

    return {
      partialCancellationComment,
      paymentPolicy,
      taxValue,
      isHotelEditable,
      errors: null,
      confirmed: false,
      showCancellationTip: false,
      isShowConfirmationDialog: false,
      focValue: foc || focDefault,
      selectedRadioFoc: foc ? FOC : NO_FOC,
      selectedRadioCityTax: taxValue || this.props.hotel.cityTax ? CITY_TAX_NOT_INCLUDED : CITY_TAX_INCLUDED,
      periods: newPeriods,
      statePeriods: [],
    };
  }

  componentWillUnmount() {
    const el = document.getElementsByClassName('ui-toastr-item-type-danger')[0];
    if (el) {
      el.remove();
    }
  }

  validate(cb) {
    const { taxValue, focValue, selectedRadioCityTax } = this.state;
    const validationObj = {};
    if (selectedRadioCityTax !== CITY_TAX_INCLUDED) {
      Object.assign(validationObj, { taxValue });
    }

    Object.assign(validationObj, { focEveryValue: focValue });
    const errors = validationData(validationObj);
    this.setState({ errors });
    if (isFunction(cb)) cb(errors);
  }

  // TODO need to refactor
  getSendPeriods = () => {
    const { periods } = this.state;
    return periods.map(({
      from, to, percent, isFirst,
    }) => {
      if (isFirst) return;
      return {
        from: from ? parseInt(from, 10) : 0,
        to: to ? parseInt(to, 10) : 0,
        percent: parseInt(percent, 10),
      };
    }).filter(v => v);
  };

  getCancellationPolicy = () => ({
    free: +this.state.periods[0].to,
    periods: this.getSendPeriods(),
  });

  getLabelForConfirm = () => {
    const { isOpenDirect = false, hotel } = this.props;
    const makeOfferText = i18n('app.components.Offer.HotelCondition.btnRequest');
    const saveText = i18n('app.components.Offer.HotelCondition.btnRequestDirect');

    if (hotel.isHotelEditable) {
      return isOpenDirect ? saveText : makeOfferText;
    } else if (isOpenDirect) {
      return saveText;
    }
    return makeOfferText;
  };

  getOfferData = () => {
    const { taxValue, selectedRadioCityTax } = this.state;
    const { dataHotelConfirmation } = this.props;
    return {
      ...dataHotelConfirmation,
      cityTax: selectedRadioCityTax === CITY_TAX_INCLUDED ? null : taxValue,
      foc: this.getFocValue(),
    };
  };

  getFocValue = () => {
    const { selectedRadioFoc, focValue } = this.state;
    return selectedRadioFoc === NO_FOC ? null : focValue;
  };

  getPeriods = () => {
    const { periods } = this.state;
    periods.splice(periods.length - 1, 1, { ...last(periods), to: 0 });
    return checkCancellation(periods);
  };

  handleToggle = target => this.setState({ [target]: !this.state[target] });

  handlerChangeFocValue = (value) => {
    if (`${value}`.length < 8) {
      this.setState({ focValue: value }, () => { this.validate(); });
    }
  };

  handlerChangeCityTaxValue = (taxValue) => {
    this.setState({ taxValue }, () => { this.validate(); });
  };

  handlerGoToDetailPage = () => this.setState({
    isShowConfirmationDialog: false,
  }, () => {
    this.props.onHandlerClose();
  });

  handlerPrepareCancellationData = () => {
    const { isOpenDirect } = this.props;
    this.validate((errors) => {
      if (!isEmpty(errors)) return false;
      if (isOpenDirect) {
        this.handlerMakeOffer();
      } else {
        this.setState({ isShowConfirmationDialog: true });
      }
    });
  };

  handlerChangeToDaysValue = (index, val) => {
    const { periods } = this.state;
    const value = +val;
    // not passed validation situations
    const outOfRange = isNaN(value) || value < 0;
    const notLastButZero = periods.length !== index && value === 0;
    const inputNumberRegExp = new RegExp(/^$|^[0-9]+$/);

    if (`${value}`.length > MAX_INPUT_SIZE || !inputNumberRegExp.test(val)) return false;
    // set new value
    periods[index].to = val;

    if (outOfRange || notLastButZero) {
      periods[index + 1].from = '?';
      this.setState({
        periods: checkCancellation(periods),
      }, this.forceUpdate());
      return false;
    }

    // if last then replace to 0 always
    const isLast = periods.length === index;
    if (isLast) {
      periods[index].to = '0';
      this.setState({
        periods: hasCollision(periods, periods[index + 1].from, index + 1),
      }, this.forceUpdate());
      return true;
    }

    periods[index + 1].from = value - 1;

    this.setState({
      periods: hasCollision(periods, periods[index].from, index),
    }, this.forceUpdate());

    return true;
  };

  handlerChangePercentValue = (index, e) => {
    const { periods } = this.state;
    const value = +e;
    if (isNaN(value) || value > 101 || `${value}`.length > 4) return false;
    periods[index].percent = value;
    this.setState({ periods }, this.forceUpdate());
  };

  handlerMakeOffer = async () => {
    const {
      abbr, onUpdateHotel, onHandlerConfirm, handlerUpdateInputs,
    } = this.props;
    const {
      taxValue, selectedRadioCityTax, paymentPolicy, partialCancellationComment,
    } = this.state;

    const foc = this.getFocValue();
    const cancellationPolicy = this.getCancellationPolicy();
    const hotel = {
      foc,
      cancellationPolicy,
      paymentPolicy,
      partialCancellationComment,
      confirmedConditions: true,
      currencyAbbr: abbr || defValueCurrency.abbr,
      cityTax: selectedRadioCityTax === CITY_TAX_INCLUDED ? null : taxValue,
    };

    handlerUpdateInputs({ paymentPolicy, partialCancellationComment });

    try {
      await onUpdateHotel({ hotel });
      onHandlerConfirm({ hotel });
    } catch (e) {
      this.setState({ confirmed: false });
    }
  };

  handlerChangeFoc = (value) => {
    this.setState({
      selectedRadioFoc: value,
      focValue: value === NO_FOC ? this.props.hotel.foc : this.state.focValue || focDefault,
    }, () => this.validate());
  };

  handlerChangeCityTax = (value) => {
    this.setState({
      selectedRadioCityTax: value,
      taxValue: value === CITY_TAX_NOT_INCLUDED ? this.props.hotel.cityTax : this.state.taxValue,
    }, () => this.validate());
  };

  setPeriods = (mainPeriods = defaultCancellationPolicy.periods) =>
    mainPeriods.map((period, index) => ({
      edit: mainPeriods[index] && mainPeriods[index].edit || false,
      ...period,
    }));

  handleAddPeriod = () => {
    const { periods } = this.state;

    const lastValue = periods[periods.length - 1];
    periods.splice(periods.length - 1, 1, {
      ...lastValue, to: '', percent: '',
    });
    periods.push({
      to: 0, from: '?', percent: 100,
    });

    this.setState({ periods: [...periods] });
  };

  handleDeletePeriod = (index) => {
    const { periods } = this.state;
    periods.splice(index, 1);

    if (periods[index - 1] && periods[index]) {
      periods[index].from = periods[index - 1].to - 1;
    }
    this.setState({ periods: [...periods] });
  };

  getIsValidData = () => {
    const { errors, confirmed, periods } = this.state;
    return confirmed || periods.filter(v => !v.isFirst).length < 1 || size(errors) || this.checkCollisions();
  };

  checkCollisions = () => {
    const { periods } = this.state;
    const isHaveErorr = checkCancellation(periods).some(p => p.hasCollision || p.hasCollisionPercent);

    this.setState({
      showCancellationTip: isHaveErorr,
    });

    return isHaveErorr;
  };

  handlerChangePaymentPolicy = (paymentPolicy) => {
    this.setState({ paymentPolicy });
  };

  handlerChangePartialCancellationComment = (partialCancellationComment) => {
    this.setState({ partialCancellationComment });
  };

  handlerCloseCancellationTip = () => {
    this.setState({
      showCancellationTip: false,
    });
  };

  render() {
    const {
      errors,
      focValue,
      taxValue,
      statePeriods,
      isHotelEditable,
      selectedRadioFoc,
      paymentPolicy,
      partialCancellationComment,
      isShowConfirmationDialog,
      selectedRadioCityTax,
      showCancellationTip,
    } = this.state;

    const {
      hotel,
      onHandlerClose,
      onHandlerCancel,
      handleChangeValidTime,
    } = this.props;

    return (
      <div>
        {showCancellationTip &&
          <Toastr
            title={i18n('app.components.cancellationHintTitle')}
            message={i18n('app.components.cancellationHint')}
            closeElement={<div className="ui-toastr-close"><IconClose /></div>}
            onClose={this.handlerCloseCancellationTip}
          />
        }
        {!isShowConfirmationDialog ? <Dialog
          className="dialog"
          title={i18n('app.components.Offer.RoomStructure.conditionText', {}, true)}
          actions={[
            <Button
              onClick={onHandlerCancel}
              autoFocus
              uppercase
            >
              {i18n('app.components.Offer.HotelCondition.btnCancel')}
            </Button>,
            <Button
              primary
              uppercase
              disabled={this.getIsValidData()}
              onClick={this.handlerPrepareCancellationData}
            >
              {this.getLabelForConfirm()}
            </Button>,
          ]}
          onClose={onHandlerClose}
        >
          <Row className="ui-flex">
            <Cell width={29} style={{ marginRight: '32px' }}>
              <FocRadio
                className="u-margin-bottom"
                isHotelEditable={isHotelEditable}
                focValue={focValue}
                defaultSelected={selectedRadioFoc}
                radioValue={selectedRadioFoc}
                handleToggle={this.handleToggle}
                handlerChangeFoc={this.handlerChangeFoc}
                handlerChangeValue={this.handlerChangeFocValue}
                errors={errors}
              />
              <CityTax
                handlerChangeRadio={this.handlerChangeCityTax}
                handlerChangeCityTax={this.handlerChangeCityTaxValue}
                defaultSelected={selectedRadioCityTax}
                radioValue={selectedRadioCityTax}
                value={taxValue}
                errors={errors && errors.taxValue ? { ...errors.taxValue.taxValue.errorText } : null}
              />
            </Cell>
            <Cell width={67}>
              <HotelConditionTitle className="ui-flex">
                {i18n('app.components.Offer.HotelCondition.asideTitle')}
                {isHotelEditable && <Add
                  className="u-flex-one-right-end"
                  text={i18n('app.components.Offer.HotelCondition.addCondition')}
                  handleAddClick={this.handleAddPeriod}
                />}
              </HotelConditionTitle>
              <CancellationPolicyTable
                isHotelEditable={isHotelEditable}
                statePeriods={statePeriods}
                periods={this.getPeriods()}
                onChangeToDaysValue={this.handlerChangeToDaysValue}
                onChangePercentValue={this.handlerChangePercentValue}
                onChangeFreeCancellation={this.handlerChangeToDaysValue}
                onDeletePeriod={this.handleDeletePeriod}
              />
              <Row className="ui-flex u-margin-top u-flex-align-v-end">
                <Cell width={50} className="u-margin-right-s">
                  <CancellationComment
                    text={partialCancellationComment}
                    onChangeText={this.handlerChangePartialCancellationComment}
                  />
                </Cell>
                <Cell width={50} >
                  <HotelPaymentPolicy
                    hintId="app.components.hotelPaymentPolicy.tip"
                    text={paymentPolicy}
                    onChangeText={this.handlerChangePaymentPolicy}
                  />
                </Cell>
              </Row>
            </Cell>
          </Row>
        </Dialog> :
        <HotelConfirmation
          hotel={hotel}
          paymentPolicy={paymentPolicy}
          partialCancellationComment={partialCancellationComment}
          offerInfo={this.getOfferData()}
          cancellationPolicy={this.getCancellationPolicy()}
          onCancel={this.handlerGoToDetailPage}
          onApprove={this.handlerMakeOffer}
          handleChangeValidTime={handleChangeValidTime}
        />
      }
      </div>
    );
  }
}

HotelCondition.propTypes = {
  sigh: PropTypes.string,
  hotel: PropTypes.object,
  rooms: PropTypes.array,
  onUpdateHotel: PropTypes.func,
  onHandlerClose: PropTypes.func,
  onHandlerCancel: PropTypes.func,
  isOpenDirect: PropTypes.bool,
  totalPrice: PropTypes.number,
};

export default HotelCondition;

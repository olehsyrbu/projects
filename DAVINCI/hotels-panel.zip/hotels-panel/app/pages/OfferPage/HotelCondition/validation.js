import { has, size } from 'lodash';

import Validation from 'app/utils/validator';
import Require from 'app/utils/validator/required';
import MinLength from 'app/utils/validator/minLength';
import MinNumber from 'app/utils/validator/minNumber';

const validationFreeCancellationDays = new Validation([
  new Require('freeCancellationDays'),
]);

const validationTaxValue = new Validation([
  new Require('taxValue'),
  new MinLength('taxValue'),
]);

const validationFocEveryValue = new Validation([
  new Require('focEveryValue'),
  new MinNumber('focEveryValue'),
]);

export default function (data) {
  const errors = {};
  has(data, 'freeCancellationDays')
    && size(validationFreeCancellationDays.getErrors(data)) > 0
    && (errors.freeCancellationDays = validationFreeCancellationDays.getErrors(data));
  has(data, 'taxValue')
    && size(validationTaxValue.getErrors(data)) > 0
    && (errors.taxValue = (validationTaxValue.getErrors(data)));
  has(data, 'focEveryValue')
    && size(validationFocEveryValue.getErrors(data)) > 0
    && (errors.focEveryValue = (validationFocEveryValue.getErrors(data)));
  return errors;
}

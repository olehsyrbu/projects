import React from 'react';
import i18n from 'app/utils/i18n';
import TextInputWithTitle from 'app/common/TextInputWithTitle';
import { styleBodyTextarea } from 'app/common/design/style';

const HotelPaymentPolicy = ({ onChangeText, text, hintId }) => (
  <TextInputWithTitle
    hintStyleClass="ui-conditions-hint"
    styleTextArea={{ styleBodyTextarea }}
    title={i18n('app.components.hotelPaymentPolicy.title')}
    placeholder={i18n('app.components.Placeholder', {}, true)}
    hintId={hintId}
    onChangeText={onChangeText}
    text={text}
  />
);

export default HotelPaymentPolicy;

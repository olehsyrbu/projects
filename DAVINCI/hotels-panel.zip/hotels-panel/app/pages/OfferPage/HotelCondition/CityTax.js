import React from 'react';
import { Radio, TextField } from 'app/ui';
import {
  ErrorMsg,
  styleBodyTextarea,
} from 'app/common/design/style';

import { CITY_TAX_INCLUDED, CITY_TAX_NOT_INCLUDED } from 'app/utils/global-constant';
import i18n from 'app/utils/i18n';
import IconInfo from 'app/common/IconInfo';
import TextCenterHeight from 'app/common/design/TextCenterHeight';
import TitleBold from 'app/common/design/TitleBold';
import FlexColumn from 'app/common/design/FlexColumn';

export default ({
  handlerChangeRadio, handlerChangeCityTax,
  // defaultSelected,
  value, radioValue, errors,
}) => (
  <FlexColumn>
    <TextCenterHeight>
      <TitleBold className="ui-flex">
        {i18n('app.components.Request.city_tax')}
        <IconInfo
          place="right"
          text={i18n('app.components.HotelCondition.Info.cityTaxHint')}
          id="app.components.HotelCondition.Info.cityTaxHint"
        />
      </TitleBold>
    </TextCenterHeight>
    <div className="u-margin-top-s">
      <Radio
        value={CITY_TAX_INCLUDED}
        checked={radioValue === CITY_TAX_INCLUDED}
        onChange={handlerChangeRadio}
      >
        <span className="u-radio-btn-text">
          {i18n('app.components.includedInPrice', {}, true)}
        </span>
      </Radio>
      <Radio
        value={CITY_TAX_NOT_INCLUDED}
        checked={radioValue === CITY_TAX_NOT_INCLUDED}
        onChange={handlerChangeRadio}
      >
        <span className="u-radio-btn-text">
          {i18n('app.components.notIncludedInPrice', {}, true)}
        </span>
      </Radio>
    </div>
    {radioValue === CITY_TAX_NOT_INCLUDED && (
      <div style={styleBodyTextarea}>
        <TextField
          multiline
          value={value}
          error={errors}
          onChange={handlerChangeCityTax}
          placeholder={i18n('app.components.Offer.HotelConditions.PleaseSpecifyAmount', {}, true)}
        />
        {errors && <ErrorMsg>{i18n('app.components.errorCityTaxMsg')}</ErrorMsg>}
      </div>
    )}
  </FlexColumn>
);

import React from 'react';
import Avatar from 'app/common/Avatar';
import { BoldText, WrapPadLeft } from 'app/common/design/style';
import { WrapHotel, DateStyle, WrapTextHotel, WrapImageLogo, WrapHotelInfo } from '../style';

export default ({
  srcLogo, hotelName, periodsLiving, avatarProps,
}) => (
  <WrapHotel>
    <WrapImageLogo>
      <Avatar src={srcLogo} name={hotelName} avatarProps={avatarProps} size={avatarProps.size} />
    </WrapImageLogo>
    <WrapHotelInfo>
      <WrapTextHotel>
        <WrapPadLeft>
          <BoldText>
            {hotelName}
          </BoldText>
        </WrapPadLeft>
        <WrapPadLeft>
          <DateStyle>
            {periodsLiving}
          </DateStyle>
        </WrapPadLeft>
      </WrapTextHotel>
    </WrapHotelInfo>
  </WrapHotel>
);

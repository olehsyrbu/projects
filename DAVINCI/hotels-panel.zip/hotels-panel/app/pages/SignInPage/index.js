import React from 'react';
import PageWrapper from 'app/common/PageWrapper';
import Content from 'app/common/PageWrapper/Content';

const style = {
  zIndex: 999,
  position: 'relative',
  padding: 0,
  background: 'white',
};

export default () => (
  <PageWrapper style={style}>
    <Content>
      <h1>Your are not authorized</h1>
      <p>
        If the problem continues contact us at
      </p>
      <p>
        <a href={`mailto:hotels@davincits.com?subject=Not authorized, from HOTEL ${localStorage.getItem('hotel')}`} className="light" >hotels@davincits.com</a>
      </p>
    </Content>
  </PageWrapper>
);

import {
  INTERNAL_CANCELED_OFFER,
  INTERNAL_CHOISED_ANOTHER_HOTEL,
  INTERNAL_NO_AVAILABILITY,
  INTERNAL_OFFER_EXPIRED,
  INTERNAL_CHOISED_YOUR_HOTEL,
  INTERNAL_SUCCESSFULLY_COMPLETED,
  statuses,
} from './global-constant';

export const getIsCanceledOffer = status => status && status === INTERNAL_CANCELED_OFFER;
export const getIsChoseAnotherHotel = status => status && status === INTERNAL_CHOISED_ANOTHER_HOTEL;
export const getIsNoAvailability = status => status && status === INTERNAL_NO_AVAILABILITY;
export const getIsOfferExpired = status => status && status === INTERNAL_OFFER_EXPIRED;
export const getIsChoseYourHotel = status => status && status === INTERNAL_CHOISED_YOUR_HOTEL;
export const getIsAgencyRequest = status => status && status === statuses.AGENCY_SESSION_REQUEST;
export const getIsCompleted = status => status && status === INTERNAL_SUCCESSFULLY_COMPLETED;

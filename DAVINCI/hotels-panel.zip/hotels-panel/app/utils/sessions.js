import moment from 'moment';
import { has, size, sortBy, groupBy, toPairs, filter, round } from 'lodash';
import { formatDateYMDHMS, formatDateYMDSlash, statuses } from 'app/utils/global-constant';
import { getDate, getIsValidTime, changeDateType, getDateByField } from './date';

import { getIsCompleted } from './statuses';
import forEach from 'lodash/forEach';

const {
  HOTEL_PROPOSAL,
  AGENCY_CONFIRM,
} = statuses;

const getTour = session => session && session.trip && session.trip.tour || {};
const getTourId = session => getTour(session)._id;

export const sortSessionsByFieldReverse = (sessions, fieldName) =>
  sortBy(sessions, s =>
    moment(getDateByField(s[fieldName]), formatDateYMDHMS)).reverse();

export const sortSessionsByField = (sessions, fieldName) =>
  sortBy(sessions, s =>
    moment(changeDateType(s[fieldName]), formatDateYMDHMS));

export const sortAndPair = sessions => sortBy(toPairs(sessions), [d => d[0]]);

export const getSessionsGroupByField = (sessions, fieldName, period = 'day') =>
  groupBy(sessions, s =>
    moment(getDateByField(s[fieldName]), formatDateYMDHMS).startOf(period).format());

export const getUpToFromHotelsProposals = s => (has(s, 'hotelsProposals[0].upTo')
  ? s.hotelsProposals[0].upTo
  : null
);

export const getValidOffersByHotelProposalsUpTo = sessions =>
  filter(sessions, s => getIsValidTime(getUpToFromHotelsProposals(s)));


export const separateSessionByDate = sortedSessions =>
  groupBy(
    sortedSessions,
    s => moment(changeDateType(s.checkIn), formatDateYMDHMS).startOf('month').format(),
  );

// set addedAt from hotelsProposals or hotelsDeclined or create new Date
export const addToSessionAddedAt = sessions => sessions.map(s => ({
  ...s,
  addedAt: (!!size(s.hotelsProposals) && s.hotelsProposals[0].createdAt)
    ? s.hotelsProposals[0].createdAt
    : (!!size(s.hotelsDeclined) && s.hotelsDeclined[0].createdAt)
      ? s.hotelsDeclined[0].createdAt
      : new Date(0).toUTCString(),
}));

export const getRoomDays = ({ checkIn, checkOut }) => {
  if (checkIn && checkOut) {
    return getDate(checkOut).diff(getDate(checkIn), 'days');
  }
  return 1;
};

export const getSessionSerialKey = session => `${getTourId(session)}_${session.geonameid}`;

export const combineSessionsListBySerial = (requests) => {
  let sessions = [];
  const serial = {};

  if (!!requests && Array.isArray(requests) && requests.length > 0) {
    requests.forEach((s) => {
      if (has(s, 'trip.tour.isSerial') && s.trip.tour.isSerial) {
        const key = getSessionSerialKey(s);
        if (!serial[key]) {
          serial[key] = [];
        }
        serial[key].push(s);
      } else {
        sessions.push(s);
      }
    });
  }

  if (size(serial)) {
    sessions = [
      ...sessions,
      ...Object.keys(serial).map((tourId) => {
        const firstSession = serial[tourId][0];
        return {
          ...firstSession,
          isSerial: true,
          sessions: serial[tourId],
        };
      }),
    ];
  }

  return sessions;
};

export const getIsValidOptionsReservation = ({ checkIn, dueDays }) => {
  const days = moment(checkIn, formatDateYMDHMS).subtract(dueDays, 'd').format(formatDateYMDSlash);
  const now = moment(new Date(), formatDateYMDSlash).format(formatDateYMDSlash);
  return moment(now).isSame(days) || moment(now).isBefore(days);
};

const now = moment();

export const getArchiveReservations = reservations => sortSessionsByField(reservations, 'checkIn').filter(s => moment(s.checkIn).isBefore(moment()));

export const getArchiveSessions = newRequests => sortSessionsByField(combineSessionsListBySerial(newRequests), 'checkOut')
  .filter(s => moment(s.checkOut).isBefore(now));

export const getActiveSessions = (sessions, field) =>
  sortSessionsByField(sessions, field).filter(s => moment(s.checkIn).isAfter(moment()));

export const getBudgetByRequest = (budgetMin, budgetMax) => ((budgetMin && budgetMax)
  ? `${round(budgetMin, 2).toString()} - ${round(budgetMax, 2).toString()}`
  : `${round(budgetMax, 2).toString()} `);

export const prepareByFilter = (reservations) => {
  const sortedSessionsByCheckIn = sortSessionsByField(reservations, 'checkIn')
    .filter(s => getIsValidTime(getDateByField(s.checkOut)));

  const groupSessionsByDate = separateSessionByDate(sortedSessionsByCheckIn);
  return sortAndPair(groupSessionsByDate);
};

export const filterByStatus = (reservations, status) => reservations.filter(r => r.status === status);
const filterByStatus4Hotel = reservations => reservations.filter(r => getIsCompleted(r.status4Hotel));

export const getSessionForCompleted = (reservations) => {
  const sessions = addToSessionAddedAt(reservations);
  const groupedSessionsByMonth = separateSessionByDate(sortSessionsByField(filterByStatus4Hotel(sessions), 'checkIn'));
  const groupedSessionsByMonthReverse = {};
  forEach(groupedSessionsByMonth, (sessionsInMonth, month) => {
    groupedSessionsByMonthReverse[month] = sessionsInMonth.reverse();
  });

  return sortAndPair(groupedSessionsByMonthReverse).reverse();
};

export const getSessionForConfirmedReservationPage = sessions => prepareByFilter(filterByStatus(addToSessionAddedAt(sessions), AGENCY_CONFIRM));

export const getOptionalReservations = sessions => prepareByFilter(filterByStatus(sessions, HOTEL_PROPOSAL).filter(r => getIsValidOptionsReservation(r)));

export const getAllReservationSessions = sessions => prepareByFilter(addToSessionAddedAt(sessions));

export const getCompletedSessions = sessions => getSessionForCompleted(sessions);

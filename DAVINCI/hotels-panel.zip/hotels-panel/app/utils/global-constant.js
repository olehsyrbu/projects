import Intercom from 'app/utils/intercom';

export const CITY_SERVER = process.env.API_CITY;

export const actionsListSubscriptions = {
  CANCEL_REACTION: 'CANCEL_REACTION',
  NO_AVAILIBILITY: 'NO_AVAILIBILITY',
  MAKE_OFFER: 'MAKE_OFFER',
};

let intercomInited = false;
export const bootIntercom = (hotel) => {
  if (hotel && !intercomInited) {
    const { name, email, _id } = hotel;
    intercomInited = true;
    Intercom.init({
      email,
      name,
      user_id: _id,
    });
  }
};

export const stringToColor = (str = '', opacity = 0.7) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash); // eslint-disable-line no-bitwise
  }
  const color = [];
  for (let i = 0; i < 3; i++) {
    const value = parseInt((hash >> (i * 8)).toString(10).substr(-3) / 1000 * 200, 10); // eslint-disable-line no-bitwise
    color.push(value);
  }
  const min = Math.min(...color);
  color[color.indexOf(min)] = 0;
  return `rgba(${color.join(',')},${opacity})`;
};

export const initIntercom = (hotel) => {
  Intercom.load(() => bootIntercom(hotel));
};

const localGeo = localStorage.getItem('geoCities');
const citiesStorage = localGeo && JSON.parse(localGeo);
export const geoCities = citiesStorage ? [...citiesStorage] : [];

export const mealDefault = 'BB';
export const mealDefaultFullText = 'Buffet breakfast';
export const cityTaxDefault = null;
export const focDefault = 21;

export const statuses = {
  PROLONG_STATUS_REQUEST: 'PROLONG_STATUS_REQUEST',
  UNCONFIRMED_PROPOSALS_REQUEST: 'UNCONFIRMED_PROPOSALS_REQUEST',
  WAIT_FOR_CONFIRMATION: 'WAIT_FOR_CONFIRMATION',
  CONFIRMED: 'CONFIRMED',
  CANCELED: 'CANCELED',
  AGENCY_REQUEST: 'AGENCY_REQUEST',
  AGENCY_CANCEL_REQUEST: 'AGENCY_CANCEL_REQUEST',
  AGENCY_SESSION_REQUEST: 'AGENCY_SESSION_REQUEST',
  HOTEL_PROPOSAL: 'HOTEL_PROPOSAL',
  AGENCY_PROPOSAL: 'AGENCY_PROPOSAL',
  CANCEL_AGENCY_PROPOSAL: 'CANCEL_AGENCY_PROPOSAL',
  AGENCY_CONFIRM: 'AGENCY_CONFIRM',
  // AGENCY_CUSTOM_REQUEST: 'AGENCY_CUSTOM_REQUEST',
  CREATED: 'CREATED',
  // DEFAULT: 'DEFAULT',
  // UNCONFIRMED_PROPOSALS_CANCEL: 'UNCONFIRMED_PROPOSALS_CANCEL',
  // UNCONFIRMED_PROPOSALS_CONFIRMED: 'UNCONFIRMED_PROPOSALS_CONFIRMED',
  // UNCONFIRMED_PROPOSALS_STATUS_REQUESTED: 'REQUESTED',
  // UNCONFIRMED_PROPOSALS_STATUS_CONFIRMED: 'CONFIRMED',
  ROOMING_STATUS_CONFIRMED: 'CONFIRMED',
  // ROOMING_STATUS_CANCELED: 'CANCELED',
  // ROOMING_STATUS_WAIT_FOR_CONFIRMATION: 'WAIT_FOR_CONFIRMATION',
  // OPTION_RESTORE_STATUS_REQUEST: 'OPTION_RESTORE_STATUS_REQUEST',
};

export const ROOM_TYPE_SINGLE = 'ROOM_TYPE_SINGLE';
export const ROOM_TYPE_DOUBLE = 'ROOM_TYPE_DOUBLE';
export const ROOM_TYPE_TWIN = 'ROOM_TYPE_TWIN';
export const ROOM_TYPE_TRIPLE = 'ROOM_TYPE_TRIPLE';
export const ROOM_TYPE_QUAD = 'ROOM_TYPE_QUAD';

export const MSG_TYPE_EXPENSIVE = 'MSG_TYPE_EXPENSIVE';
export const MSG_TYPE_TOO_FAR = 'MSG_TYPE_TOO_FAR';
export const MSG_TYPE_HOTEL_LEVEL = 'MSG_TYPE_HOTEL_LEVEL';
export const MSG_TYPE_CUSTOM = 'MSG_TYPE_CUSTOM';
export const MSG_TYPE_HOTEL = 'MSG_TYPE_HOTEL';
export const MSG_TYPE_CANCEL = 'MSG_TYPE_CANCEL';
export const MSG_TYPE_RESTORE_OPTION = 'MSG_TYPE_RESTORE_OPTION';

export const declinedMessages = [
  MSG_TYPE_RESTORE_OPTION,
  MSG_TYPE_EXPENSIVE,
  MSG_TYPE_TOO_FAR,
  MSG_TYPE_HOTEL_LEVEL,
  MSG_TYPE_CUSTOM,
];

export const INTERNAL_OFFER_EXPIRED = 'OFFER_EXPIRED';
export const INTERNAL_CHOISED_YOUR_HOTEL = 'CHOISED_YOUR_HOTEL';
export const INTERNAL_CANCELED_OFFER = 'CANCELED_OFFER';
export const INTERNAL_NO_AVAILABILITY = 'NO_AVAILABILITY';
export const INTERNAL_CHOISED_ANOTHER_HOTEL = 'CHOISED_ANOTHER_HOTEL';
export const INTERNAL_SUCCESSFULLY_COMPLETED = 'SUCCESSFULLY_COMPLETED';

export const CORPORATE = 'CORPORATE';
export const email = 'office@davincits.eu';
export const emailInfo = 'hotels@davincits.com';

export const defValueCurrency = {
  abbr: 'EUR', name: 'Euro', sign: '€', rate: 1,
};

export const sign = '€';

export const BUDGET_MIN_VALUE = 10;
export const BUDGET_MAX_VALUE = 250;
export const BUDGET_DEFAULT = {
  min: BUDGET_MIN_VALUE,
  max: BUDGET_MAX_VALUE,
};

export const getBrowserLanguage = (lang) => {
  const selectedlangUser = localStorage.getItem('selectedNewLanguage');
  if (selectedlangUser) return selectedlangUser;

  let selectedLang = 'en';
  let selectedLangFlag = 'GB';
  if (lang.includes('pl')) {
    selectedLang = 'pl';
    selectedLangFlag = 'PL';
  } else if (lang.includes('de')) {
    selectedLang = 'de';
    selectedLangFlag = 'DE';
  } else if (lang.includes('cs')) {
    selectedLang = 'cs';
    selectedLangFlag = 'CZ';
  } else if (lang.includes('fr')) {
    selectedLang = 'fr';
    selectedLangFlag = 'FR';
  }
  localStorage.setItem('selectedNewFlag', selectedLangFlag);
  localStorage.setItem('selectedNewLanguage', selectedLang);
  return selectedLang;
};

export const DEFAULT_LOCALE = getBrowserLanguage(navigator.language);

export const rooms = [
  {
    _id: '5887434177ce1500fad4cfad',
    name: 'single',
    abbr: ROOM_TYPE_SINGLE,
    displayAbbr: 'SNGL',
    capacity: 1,
  },
  {
    _id: '5887436277ce1500fad4cfae',
    name: 'double',
    abbr: ROOM_TYPE_DOUBLE,
    displayAbbr: 'DBL',
    capacity: 2,
  },
  {
    _id: '58adb2a47aefe204ca56ca46',
    name: 'twin',
    abbr: ROOM_TYPE_TWIN,
    displayAbbr: 'TWN',
    capacity: 2,
  },
  {
    _id: '588743eb77ce1500fad4cfb0',
    name: 'triple',
    abbr: ROOM_TYPE_TRIPLE,
    displayAbbr: 'TRPL',
    capacity: 3,
  },
  {
    _id: '5887441077ce1500fad4cfb1',
    name: 'quadro',
    abbr: ROOM_TYPE_QUAD,
    displayAbbr: 'QDRO',
    capacity: 4,
  },
];

// this is 3 days for valid offer in make offer page.
export const DEFAULT_DAYS_VALID_OFFER = 3;

export const formatDateYMDHMS = 'YYYY/MM/DD HH:mm:ss';
export const formatDateYMDHMSMinus = 'YYYY-MM-DD HH:mm:ss';
export const formatDateYYMDHMS = 'DD/MM/YY HH:mm';
export const formatDateDMYHMS = 'DD/MM/YYYY H:mm:ss';
export const formatDateYMD = 'YYYY/MM/DD';
export const formatDateDMY = 'DD/MM/YYYY';
export const formatDateYMDSlash = 'YYYY-MM-DD';
export const formatDateDMYShourt = 'DD/MM/YY';
export const formatDMYhmA = 'DD.MM.YY, hh:mm A';
export const formatForServer = 'YYYY-MM-DD 00:00:00';
export const formatDMY = 'DD.MM.YY';
export const formatShort = 'DD/MM';
export const formatMonth = 'MMMM';
export const formatDateDMYDots = 'DD.MM.YYYY';

export const DEFAULT_DAYS_OPTIONAL = 30;
export const DEFAULT_DUE_DAYS_FIXED = 720;

export const normalizeBudget = ({ min, max }) => {
  min = min ? Math.max(Math.min(min, BUDGET_MAX_VALUE), BUDGET_MIN_VALUE) : BUDGET_MIN_VALUE;
  max = max ? Math.max(Math.min(max, BUDGET_MAX_VALUE), BUDGET_MIN_VALUE) : BUDGET_MAX_VALUE;
  return min > max ? { min, max: min } : { min, max };
};

export const defaultCancellationPolicy = {
  free: 31,
  periods: [
    { from: 30, to: 21, percent: 25 },
    { from: 20, to: 15, percent: 50 },
    { from: 14, to: 8, percent: 100 },
    { from: 7, to: '', percent: 100 },
  ],
};

export const DAYS_OF_THE_WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const MSEC_IN_SEC = 1000;
export const MSEC_IN_MINUTE = MSEC_IN_SEC * 60;
export const MSEC_IN_HOUR = MSEC_IN_MINUTE * 60;
export const MSEC_IN_DAY = MSEC_IN_HOUR * 24;
export const MSEC_IN_WEEK = MSEC_IN_DAY * 7;

export const CITY_TAX_INCLUDED = 'city_tax_included';
export const CITY_TAX_NOT_INCLUDED = 'city_tax_not_included';
export const FOC = 'foc';
export const NO_FOC = 'no_foc';

export const globalGroupTypes = [
  { key: 'LEISURE', val: 'Leisure' },
  { key: 'CORPORATE', val: 'MICE' },
  { key: 'STUDENTS', val: 'Students' },
];

export const MAX_INPUT_SIZE = 7;
export const MAX_INPUT_PRICE_SIZE = 7;

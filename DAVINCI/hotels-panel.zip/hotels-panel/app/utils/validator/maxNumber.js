import Validator from './validator';

export default class MaxNumber extends Validator {
  constructor(field, config = {}) {
    super(field, config);
    this.setType('max_number');
  }

  getError(data) {
    const name = this.getField();
    if (data[name] && data[name] > 999) {
      return this.getMessage();
    }
    return undefined;
  }
}

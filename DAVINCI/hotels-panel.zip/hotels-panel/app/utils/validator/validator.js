import React from 'react' // eslint-disable-line
import { FormattedMessage } from 'react-intl';
import i18n from 'app/utils/i18n';

export default class Validator {
  constructor(field, config = {}) {
    this.type = 'required';
    this.field = field;
    this.config = config;
    this.messageValues = {};
  }

  addError(errors, data, index) {
    const errorText = this.getError(data);
    if (errorText) {
      errors[this.getField()] = { errorText, index };
    }
    return errors;
  }

  setType(type) {
    this.type = type;
  }

  setMessageValues(obj) {
    this.messageValues = obj;
  }

  getConfig() {
    return this.config;
  }

  getField() {
    return this.field;
  }

  getMessage() {
    const { message, text } = this.config;
    if (text) {
      return text;
    }
    if (message) {
      return <FormattedMessage {...message} />;
    }
    return i18n(`validation_${this.type}_${this.field}`);
  }
}

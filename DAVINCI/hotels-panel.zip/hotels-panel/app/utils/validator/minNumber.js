import Validator from './validator';

export default class MinNumber extends Validator {
  constructor(field, config = {}) {
    super(field, config);
    this.setType('min_number');
  }

  getError(data) {
    const name = this.getField();
    const value = data[name];

    if (name === 'priceOne' && Number(`${value}`.replace(',', '.')) === 0 || !isNaN(value) && +value <= 0) {
      return this.getMessage();
    }
    return undefined;
  }
}

import { MAX_INPUT_PRICE_SIZE, rooms as roomsGlobal, mealDefault } from './global-constant';
import jwtDecode from 'jwt-decode';
import { last } from 'lodash';
import { accounting } from 'accounting';
import i18n from './i18n';

export const getRoomInfo = name => name && roomsGlobal.find(item => item.abbr === name);

export const getCityTaxValue = cityTax => (typeof cityTax === 'string' && cityTax.length > 0 ? cityTax : null);

// value `meal` = 'BB' short text should be
export const getMealName = (meal) => {
  const ml = meal || mealDefault;
  const mealList = [
    {
      name: i18n('app.meal.HB'),
      value: 'HB',
    },
    {
      name: i18n('app.meal.FB'),
      value: 'FB',
    },
    {
      name: i18n('app.meal.BB'),
      value: 'BB',
    },
    {
      name: i18n('app.meal.CB'),
      value: 'CB',
    },
    {
      name: i18n('app.meal.AB'),
      value: 'AB',
    },
    {
      name: i18n('app.meal.NMP'),
      value: 'NMP',
    },
  ];
  const { name } = mealList.find(m => m.value === ml) || {};
  return name;
};

let accessToken = null;
let hotelId = null;

export const getAccessToken = (token) => {
  if (!accessToken) {
    let tokens = {};
    try {
      tokens = JSON.parse(localStorage.getItem('access-token'));
      const id = new RegExp(/^[0-9a-fA-F]{24}$/).test(location.pathname.split('/')[1]) && location.pathname.split('/')[1];
      if (id) hotelId = id;
      if (hotelId) {
        accessToken = tokens[hotelId];
      } else if (token) {
        const hotelData = jwtDecode(token);
        hotelId = hotelData.hotelId;
        localStorage.setItem('access-token', JSON.stringify({ [hotelId]: token, ...tokens }));
        accessToken = token;
      } else if (Object.keys(tokens).length === 1) {
        accessToken = tokens[Object.keys(tokens)];
        hotelId = Object.keys(tokens)[0];
      } else {
        accessToken = tokens[last(Object.keys(tokens))];
        hotelId = last(Object.keys(tokens));
      }
    } catch (e) {
      accessToken = localStorage.getItem('access-token');
      if (!accessToken) return;

      const hotelData = jwtDecode(accessToken);
      hotelId = hotelData.hotelId;
      localStorage.setItem('access-token', JSON.stringify({ [hotelId]: accessToken, ...tokens }));
    }
  }
  return accessToken;
};

export const getHotelId = () => {
  if (hotelId) {
    return hotelId;
  }
  getParameterByName('access-token') && getAccessToken();
  return hotelId;
};

export const setAccessToken = (id, token) => {
  accessToken = token;
  if (id) {
    hotelId = id;
    const tokens = JSON.parse(localStorage.getItem('access-token'));
    localStorage.setItem('access-token', JSON.stringify({ [id]: token, ...tokens }));
  }
};

export const redirectToOfferPage = (offerId, h) => (h ? h.push(`/${hotelId}/requests/new/${offerId}/offer`) : location.pathname = `/${hotelId}/requests/new/${offerId}/offer`);

export const redirectToNewRequestsPage = (h) => {
  if (hotelId === null) {
    return h ? h.push('signin') : location.pathname = '/signin';
  }
  return h ? h.push(`/${hotelId}/requests/new`) : location.pathname = `${hotelId}/requests/new`;
};

export const redirectToAllReservationPage = h => (h ? h.push(`/${hotelId}/reservations/all`) : location.pathname = `/${hotelId}/reservations/all`);

export const getParameterByName = (name, url) => {
  if (!url) url = window.location.href;
  name = name.replace(/[[\]]/g, '\\$&');
  const regex = new RegExp(`[?&]${name}(=([^&#]*)|&|#|$)`);
  const results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
};

export const checkCancellation = periods =>
  periods.map((p, index) => {
    const { from, to, percent } = p;
    const isIndexZero = index === 0;
    const isLastIndex = index === periods.length;
    const lastPeriod = periods[periods.length - 1];
    const nextPeriod = periods[index + 1];
    const prevPeriod = periods[index - 1];

    if (nextPeriod) {
      p.hasCollision = !!(
        isIndexZero && to <= nextPeriod.from
        || nextPeriod && (+nextPeriod.from >= +to)
        || isLastIndex && +to <= 0
        || +to <= 0
        || +from < +to
        || lastPeriod && +lastPeriod.to !== +to && !to
      );
    }

    if (periods.length - 1 === index) p.hasCollision = false;

    if (!isIndexZero && prevPeriod) {
      p.hasCollisionPercent = !!(
        +percent < 0
        || +!percent
        || (prevPeriod && +percent <= +prevPeriod.percent)
      );
    } else {
      p.hasCollisionPercent = false;
    }
    return p;
  });

export const hasCollision = (periods = [], from, index = 0) => {
  for (let i = index; i < periods.length; i++) {
    const p = periods[i];
    const pTo = p.to;
    const pPercent = p.percent;

    p.hasCollision =
      pTo <= 0
      || from < pTo
      || pTo === ''
      || from === pTo;

    p.hasCollisionPercent = index > 0 && (!pPercent || pPercent <= periods[index - 1].percent) || !pPercent || p.percent < 0;
    p.to = i === periods.length ? '0' : pTo;
  }
  return periods;
};

export const convertStringToNumber = value => Number(`${value}`.replace(',', '.'));

export const formatPrice = (price, sign) =>
  accounting.formatMoney(price, sign, 2, '', ',', '%v %s');

export const changeNumberToPrice = number =>
  Number(number).toFixed(2).replace('.', ',');

export const checkMaxLengthForPriceInput = value =>
  `${value}`.replace('.', ',').split(',')[0].length < MAX_INPUT_PRICE_SIZE;

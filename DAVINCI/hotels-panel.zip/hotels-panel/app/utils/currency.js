import { defValueCurrency } from './global-constant';
import has from 'lodash/has';

const getCurrencySign = sign => (sign || defValueCurrency.sign);

export const currency = ({ num, sign }) => (num ? `${num.toString()} ${getCurrencySign(sign)}` : 0);

export const getCurrencyByAbbr = (currencies = [], currencyAbbr) => currencies.find(c => c.abbr === currencyAbbr);

export const getCurrencySignByRooms = (rooms = [], currencies) => {
  const localPrice = rooms.find(r => has(r, 'prices[0].localPrice') && r.prices[0].localPrice);
  if (localPrice) {
    return getCurrencyByAbbr(currencies, localPrice.prices[0].localPrice.currency.abbr).sign;
  }
  return defValueCurrency.sign;
};

export const getCurrencySignByProposals = (proposals, CurrencyData) => {
  const currencyAbbrProposals = proposals.rooms.map(room => room.prices.find((price) => {
    if (has(price, 'localPrice.currency.abbr') && price.localPrice.currency.abbr && price.localPrice.currency.abbr !== defValueCurrency.abbr) {
      return price.localPrice.currency.abbr;
    }
  }));
  const abbr = has(currencyAbbrProposals, '[0].localPrice.currency.abbr') && currencyAbbrProposals[0].localPrice.currency.abbr || defValueCurrency.abbr;

  let Currency = CurrencyData;

  if (has(Currency, 'currencies')) {
    Currency = Currency.currencies;
  }

  const curr = getCurrencyByAbbr(Currency, abbr);
  if (curr) return curr.sign;
  return defValueCurrency.sign;
};

export const getIsCurrencyDefault = sign => !!sign && sign === defValueCurrency.sign;

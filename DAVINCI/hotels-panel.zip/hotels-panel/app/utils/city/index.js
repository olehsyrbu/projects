import { size } from 'lodash';
import { getCitiesById } from './api';

export const city = geonameid => getCitiesById(geonameid).then(response => !!size(response.data) && response.data[0]);

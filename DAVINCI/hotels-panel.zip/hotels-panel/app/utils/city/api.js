import { CITY_SERVER } from 'app/utils/global-constant';
import { create } from 'apisauce';
import { getAccessToken } from 'app/utils';

const getHeaderConfig = token => ({
  Accept: '*/*',
  'Accept-Language': 'en',
  Authorization: `Bearer ${token}`,
});

export const cityApi = create({
  baseURL: CITY_SERVER,
  headers: getHeaderConfig(getAccessToken()),
});

export const getCitiesById = id => cityApi.get(`/cities?geonameids[]=${id}`);


import { API_INTERCOM_APP_ID } from 'app/utils/environment';

let intercom = {
  triggered: false,
};
const load = (cb) => {
  if (!intercom.triggered) {
    intercom = function (...args) {
      intercom.c(args);
    };
    intercom.q = [];
    intercom.c = function (args) {
      intercom.q.push(args);
    };
    window.Intercom = intercom;
    const s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = `https://widget.intercom.io/widget/${API_INTERCOM_APP_ID}`;
    const x = document.getElementsByTagName('body')[0];
    x.onload = cb;
    x.appendChild(s);
    intercom.triggered = true;
  }
};

export default {
  init: (data) => {
    window.Intercom('boot', {
      app_id: API_INTERCOM_APP_ID,
      ...data,
    });
  },
  load,
  update: (data = {}) => {
    window.Intercom('update', data);
  },
  shutdown: () => {
    window.Intercom('shutdown');
  },
};

export const env = process.env.NODE_ENV;
export const API_SENTRY_DSN = process.env.API_SENTRY_DSN;
export const GRAPH_URL = process.env.GRAPH_URL;
export const API_CITY = process.env.API_CITY;
export const WS_URL = process.env.WS_URL;
export const API_INTERCOM_APP_ID = process.env.API_INTERCOM_APP_ID;
export const __VERSION__ = process.env.VERSION_FROM_GIT_DESCRIBE;

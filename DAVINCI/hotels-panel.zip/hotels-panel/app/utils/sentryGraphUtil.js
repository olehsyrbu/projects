import * as Sentry from '@sentry/browser';
import has from 'lodash/has';

const graphError = (error) => {
  const mes = has(error, 'networkError.message') ? error.networkError.message : 'graphError';
  let body = '';
  if (has(error, 'networkError.result.errors')) {
    error.networkError.result.errors.map((f) => {
      body += `\n ${f.data.originalMessage}`;
    });
  } else {
    body = has(error, 'networkError.bodyText') ? error.networkError.bodyText : ' ';
  }
  return Sentry.captureException({ message: mes, body });
};

export default graphError;

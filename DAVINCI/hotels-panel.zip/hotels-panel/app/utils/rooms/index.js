
import { rooms } from '../global-constant';
import { getRoomInfo } from '../index';

export const getCapacity = name => rooms.find(r => r.abbr === name).capacity;
export const getRoomStructureInfoFlat = rooms => (
  rooms.map(({ room, amount }) => {
    const roomName = getRoomInfo(room.name);
    return `${amount} ${roomName && roomName.displayAbbr}`;
  }).join(', ')
);

import moment from 'moment';
import {
  formatDateDMY,
  formatDateDMYHMS,
  formatDateDMYShourt,
  formatDateYMD,
  formatDateYMDHMS,
  formatDMY,
  formatForServer,
  formatMonth,
  formatShort,
  formatDateDMYDots, formatDateYMDHMSMinus,
} from 'app/utils/global-constant';

export const getDate = date => moment(date);

export const toHHMMSS = (secs) => {
  const secNum = parseInt(secs, 10);
  const hours = Math.floor(secNum / 3600);
  const minutes = Math.floor(secNum / 60) % 60;
  const seconds = secNum % 60;

  return [hours, minutes, seconds]
    .map(v => (v < 10 ? `0${v}` : v))
    .join(':');
};

export const getIsValidTime = time => moment(time).isAfter(moment());

export const getPeriodLiving = ({ checkIn, checkOut }) => `${moment(checkIn).format(formatDMY)} - ${moment(checkOut).format(formatDMY)}`;

export const getHintDateText = ({ checkIn, checkOut }) =>
  `${moment(checkOut).diff(checkIn, 'days').toString()}`;

export const getDueDate = (checkIn, dueDays) => moment(checkIn, formatDateYMDHMS).subtract(dueDays, 'd');
export const getIsFixed = (checkIn, dueDays) => !dueDays || moment().isAfter(moment(checkIn).subtract(dueDays, 'd'));

export const getTimeForValidOffer = days => new Date(new Date().setDate(new Date().getDate() + days));
export const dateFormatDMY = date => moment(date).format(formatDateDMY);
export const dateFormatDMYDots = date => moment(date).format(formatDMY);
export const dateFormatDMYHMS = date => moment(date).format(formatDateDMYHMS);
export const dateFormatDM = date => moment(date).format(formatShort);
export const dateFormatDMYY = date => moment(date).format(formatDateDMYShourt);
export const getDayNow = days => moment().add(days, 'days').format(formatForServer);
export const getUpTo = (validTime, format) => moment().add(validTime, 'h').format(format || formatDateYMDHMSMinus);
export const getUpToFullTime = validTime => moment(validTime).format(formatDateYMDHMSMinus);
export const dateFormatMMMM = date => moment(date).format(formatMonth);
export const dateFormatDateDMYDots = date => moment(date).format(formatDateDMYDots);

export const getYear = date => moment(date, formatDateYMD).year();

export const changeDateType = (date) => {
  if (typeof date === 'string' && date !== undefined) {
    return date.split('-').join('/');
  }
  return date;
};

export const getDateByField = s => new Date(changeDateType(s));

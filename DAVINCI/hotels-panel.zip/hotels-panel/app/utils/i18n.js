import React from 'react';
import { formatMessage } from 'app/providers/LanguageProvider';

import { FormattedMessage } from 'react-intl';

export default (id, values, isNeedString) => (isNeedString ? formatMessage({ id }, values) : <FormattedMessage id={id} values={values} />);

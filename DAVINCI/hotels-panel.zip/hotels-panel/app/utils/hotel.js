import { has, isEmpty } from 'lodash';
import { getCurrencySignByProposals } from 'app/utils/currency';
import { getMealName } from 'app/utils/index';

import { focDefault, cityTaxDefault, mealDefault } from 'app/utils/global-constant';

export const getDataHotel = ({
  hotelsProposals, hotelsDeclined, hotelProposal, ...offer
}, currencies, hotelQuery) => {
  const { cancellationPolicy, rooms } = hotelProposal || {};

  if (!isEmpty(hotelsProposals)) {
    const {
      proposals, foc, meal, cityTax, upTo, declinedMsg, declined, dueDays,
    } = hotelsProposals[0];

    const mealRequest = has(offer, 'requestData.meal') && offer.requestData.meal;
    const sign = getCurrencySignByProposals(proposals, { currencies });

    return {
      foc,
      sign,
      dueDays,
      cityTax,
      declined,
      proposals,
      declinedMsg,
      rooms: proposals.rooms,
      meal: getMealName(meal || mealRequest),
      upTo,
    };
  }

  if (!isEmpty(hotelsDeclined)) {
    const { hotel = {} } = hotelQuery;
    const {
      foc, cityTax, proposals, cancellationPolicy,
    } = hotel;

    const meal = has(offer, 'requestData.meal') ? offer.requestData.meal : mealDefault;
    return {
      meal: getMealName(meal),
      proposals: { ...proposals, ...cancellationPolicy },
      isDeclined: true,
      rooms: offer.rooms,
      cityTax,
      foc,
    };
  }

  if (!isEmpty(cancellationPolicy) && !isEmpty(rooms) && !isEmpty(hotelsProposals)) {
    const {
      foc, meal, cityTax, upTo, declinedMsg, declined, dueDays,
    } = hotelsProposals[0];
    const sign = getCurrencySignByProposals({ rooms }, { currencies });

    return {
      foc,
      sign,
      dueDays,
      cityTax,
      declined,
      declinedMsg,
      rooms,
      meal: getMealName(meal) || mealDefault,
      proposals: { cancellationPolicy, rooms },
      upTo,
    };
  }

  return {
    isDeclined: false,
    proposals: { rooms: [] },
    meal: getMealName(mealDefault),
    foc: focDefault,
    cityTax: cityTaxDefault,
  };
};

export default {
  getDataHotel,
};

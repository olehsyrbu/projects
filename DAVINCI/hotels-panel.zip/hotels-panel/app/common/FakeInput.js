import React from 'react';
import { disableTextStyle } from 'app/pages/OfferPage/style';

export default ({
  style, className = '', val, onClickHandler,
}) => (
  <span
    className={`${className} text`}
    onClick={onClickHandler}
    style={{ ...disableTextStyle, ...style }}
  >
    {val}
  </span>
);

import React from 'react';

const style = { paddingRight: '4px' };
export default ({ src }) => (<img src={src} style={style} />);

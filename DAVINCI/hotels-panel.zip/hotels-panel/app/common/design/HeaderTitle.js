import styled from 'styled-components';
import { colors } from 'app/style/variables';

export default styled.h3`
  letter-spacing: 1px;
  display: flex;
  margin-bottom: 30px;
  color: ${colors.grayDarkText};
  line-height: 50px;
  max-height: 50px;
  font-weight: 300;  
`;

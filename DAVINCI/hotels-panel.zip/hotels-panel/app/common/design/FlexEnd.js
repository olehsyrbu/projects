
import styled from 'styled-components';

export default styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
  flex: ${props => (props.flex) || 1};  
  padding-right: ${props => ((props.isLast) ? '10px' : '0')};
`;

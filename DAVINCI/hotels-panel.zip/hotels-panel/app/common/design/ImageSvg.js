
import styled from 'styled-components';

export const ImgBody = styled.img`
  width: 24px;
  height: 24px;
  opacity: 0.5;
`;

export const ImgWrap = styled.div`
  display: flex;
  justify-content: center;
  padding-bottom: 10px;
`;

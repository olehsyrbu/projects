
import styled from 'styled-components';
import { colors } from 'app/style/variables';

export default styled.div`
  flex-basis: 26%;
  display: flex;
  font-weight: 300;
  align-items: baseline;
  color: ${colors.grayBg};
  line-height: 1.5;
`;

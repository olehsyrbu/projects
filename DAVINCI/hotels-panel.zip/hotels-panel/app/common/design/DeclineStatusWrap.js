import styled from 'styled-components';
import { colors } from 'app/style/variables';

export default styled.div`
  color: ${colors.red};
`;

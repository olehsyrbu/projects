import styled from 'styled-components';

export default styled.div`
  margin: 8px 0px 0px;
`;

import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

export const Title = styled.div`
  font-weight: bold;
  font-size: 14px;
  line-height: 16px;
  padding-bottom: 8px;
`;

export const BtnWrap = styled.div`
  display: flex;
  justify-content: flex-end;
  flex: 1;
  width: 100%;
  & > div {
    margin-left: 18px;
  }
`;

export const FocStyle = styled.div`
  width: 100%;
`;

export const Header = styled.p`
  height: 72px;
  width: 100%;
  font-size: ${font.ms};
  font-weight: bold;
  margin-bottom: 0px;
`;

export const HotelConditionTitle = styled.h3`
  font-size: 14px;
  font-weight: bold;
  color: ${colors.dark};
`;

export const HotelConditionSubTitle = styled.p`
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #333333;
  font-weight: bold;
  line-height: 16px;
  margin-bottom: 8px;
`;

export const Row = styled.div`
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  width: 100%;
  font-size: ${font.m};
  flex-direction: row;
  &:not(:last-child) {
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(51, 51, 51, 0.1);
    margin-bottom: 20px;
  }
`;

export const RowFocBlock = styled.div`
  padding-right: 8px;
  > .Title {
    font-size: 11px;
    color: rgba(51,51,51,0.6);
    text-transform: uppercase;
  }
`;

export const BoldText = styled.div`
  font-weight: 500;
`;

export const styleBodyTextarea = {
  paddingLeft: '24px',
  paddingTop: '8px',
};

export const WrapPadLeft = styled.span`
  padding-left: 10px;
`;

export const ErrorMsg = styled.span`
  width: 100%;
  font-size: 12px;
  display: flex;
  justify-content: flex-end;
  color: ${colors.red};
  text-transform: initial;
`;

export const styleSubMenuPage = {
  paddingTop: '190px',
};

const commonBtn = {
  borderRadius: '4px',
  fontWeight: 500,
  lineHeight: '45px',
};

export const styleBtn = {
  opacity: 0.8,
  color: `${colors.text}`,
  ...commonBtn,
};

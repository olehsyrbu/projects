import styled from 'styled-components';

export default styled.div`
  font-size: 14px;
  color: #333333;
  font-weight: 500;
  line-height: 16px;
`;

import styled from 'styled-components';
import FlexRowHeader from './FlexRow';
import { colors, font } from '../../style/variables';

export default styled(FlexRowHeader)`
  border-radius: 4px 4px 0 0;
  background: ${colors.grayBGText};
  border: 1px solid ${colors.borderGray};
  border-bottom: none;
  color: ${colors.text6};
  font-size: ${font.xs11} !important;
  line-height: 16px;
  height: 34px;
`;

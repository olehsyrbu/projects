import styled from 'styled-components';
import { Nav } from 'reactstrap';

export default styled(Nav)`
  width: 100%;
  padding: 0px calc((100vw - 1060px)/2) 0px calc((100vw - 1060px)/2);
  border-bottom: none;
  background: rgb(55,55,55);
  position: fixed;
  height: 81px;
  z-index: 4;
  margin: 0px;
  @media screen and (max-width: 780px) {
    top: 142px;
  }
`;

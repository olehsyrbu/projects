import styled from 'styled-components';

export default styled.span`
  opacity: 1;
  width: 25px;
  > img{
    width: 19px;
    height: 19px;
  }
`;

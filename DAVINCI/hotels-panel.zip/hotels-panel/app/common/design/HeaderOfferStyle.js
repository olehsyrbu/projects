import { colors } from 'app/style/variables';
import styled from 'styled-components';

export default styled.div`
  background: ${props => (props.isOfferNoAvailability ? colors.lightRed : colors.grayWhiteText)};
  border: 1px solid ${props => (props.isOfferNoAvailability ? colors.lightRed2 : colors.grayWhite)};
  padding: 8px 16px;
  cursor: pointer;
`;

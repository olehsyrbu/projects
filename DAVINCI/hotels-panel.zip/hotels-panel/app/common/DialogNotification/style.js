export const customDialogStyles = {
  contentStyle: {
    width: '520px',
    maxWidth: 'none',
  },
  bodyStyle: {
    padding: '28px 100px',
  },
};


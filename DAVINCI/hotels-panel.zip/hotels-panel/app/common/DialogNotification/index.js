import React from 'react';
import PropTypes from 'prop-types';
import Dialog from 'material-ui/Dialog';
import DialogWrap from 'app/common/Dialog';

import { customDialogStyles } from './style';
import { redirectToNewRequestsPage } from 'app/utils';
import { withRouter } from 'react-router';
import i18n from 'app/utils/i18n';
import { FormattedMessage } from 'react-intl';

const DialogNotification = ({
  isOpen, onClick, action, isHideIcon, history, match: { params: { hotelId } },
}) => (
  <Dialog
    modal
    open={isOpen}
    autoScrollBodyContent
    {...customDialogStyles}
  >
    {
      action && <DialogWrap
        isHideIcon={isHideIcon}
        title={i18n(`app.components.DialogNotification.${action}.title`)}
        tip={(action === 'notFound') ? i18n(`app.components.DialogNotification.${action}.tip`) : undefined}
        text={<FormattedMessage id={`app.components.DialogNotification.${action}.text`} values={{ link: <a href={`/${hotelId}/requests/new`}>Home</a> }} />}
        btnText={i18n(`app.components.DialogNotification.${action}.btnText`)}
        onClick={onClick || redirectToNewRequestsPage.bind(this, history)}
      />
    }
  </Dialog>
);

DialogNotification.propTypes = {
  onClick: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.bool,
  ]),
  action: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.bool,
  ]),
  isOpen: PropTypes.bool,
  isHideIcon: PropTypes.bool,
};

export default withRouter(DialogNotification);

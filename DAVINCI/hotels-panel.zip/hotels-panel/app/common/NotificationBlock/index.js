import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

const NotificationBlockWrap = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid ${colors.grayBg}60;
  border-bottom:  none;
  background-color: ${colors.lightGreen20};
  padding: 14px 14px 16px;
  color: ${colors.dark};
  font-size: ${font.m};
  white-space: pre-line;
  h3 {
    margin: 0 0 3px;
    font-weight: 500;
    line-height: 24px;
    font-size: ${font.m};
  }
  p {
    margin: 0;
    opacity: 0.6;
    line-height: 18px;
  }
`;
const Icon = styled.div`
  display: flex;
  min-width: 80px;
  width: 80px;
  height: 80px;
  margin-right: 18px;
  align-items: center;
  justify-content: center;
  background-color: ${colors.light};
  border: 1px solid ${colors.grayWhiteText};
  border-radius: 50%;
  color: ${colors.grayWhiteText};
  svg {
    fill: currentColor;
    opacity: 0.5;
  }
`;

class NotificationBlock extends React.PureComponent {
  render() {
    const { icon, title, text } = this.props;
    return (
      <NotificationBlockWrap>
        {icon && <Icon>{icon}</Icon>}
        <div>
          <h3>{title}</h3>
          <p>{text}</p>
        </div>
      </NotificationBlockWrap>
    );
  }
}

NotificationBlock.propTypes = {
  icon: PropTypes.object,
  title: PropTypes.node,
  text: PropTypes.node,
};

export default NotificationBlock;

import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import map from 'lodash/map';
import isEmpty from 'lodash/isEmpty';
import RequestBlock from 'app/common/RequestBlock';
import TitlePeriod from 'app/common/TitlePeriod';
import EmptyInfo from 'app/common/EmptyInfo';
import DialogError from 'app/common/Errors/DialogError';
import Loading from 'app/common/Loading';
import PageWrapper from 'app/common/PageWrapper/index';
import { styleSubMenuPage } from 'app/common/design/style';
import { separateSessionByDate, sortAndPair, getArchiveSessions } from 'app/utils/sessions';

import SentryGraph from 'app/utils/sentryGraphUtil';
import i18n from 'app/utils/i18n';

class ArchiveRequests extends PureComponent {
  constructor(props, context) {
    super(props, context);
    this.state = {
      ...this.getInitState(),
    };
  }

  componentWillReceiveProps() {
    this.setState(this.getInitState());
  }

  getInitState = () => {
    const { sessions, loading, error } = this.props;
    if (sessions) {
      const archiveSessions = getArchiveSessions(sessions);
      const groupSessionsByDate = separateSessionByDate(archiveSessions);

      return {
        loading,
        error,
        sessionsGroup: sortAndPair(groupSessionsByDate),
      };
    }
    return {
      loading, error,
    };
  };

  render() {
    const {
      sessionsGroup, loading, error,
    } = this.state;
    if (loading) return (<Loading />);
    if (error) {
      SentryGraph(error);
      return (<DialogError error={error} />);
    }

    if (isEmpty(sessionsGroup)) {
      return (
      <PageWrapper style={styleSubMenuPage}>
        <EmptyInfo
          text={i18n('app.components.Archive.title')}
        />
      </PageWrapper>
      );
    }

    return (
      <PageWrapper style={styleSubMenuPage}>
        {map(sessionsGroup, sessionsByDay => (
          // sessionsByDay[0] = date
          // sessionsByDay[1] = array sessions
          <div key={sessionsByDay[0]}>
            <TitlePeriod
              period="month"
              defMessage={i18n('app.components.SentOffers.Others')}
              date={sessionsByDay[0] === '0' ? moment() : sessionsByDay[0]} // if true set today date.
              count={sessionsByDay[1].length}
            />
            {map(sessionsByDay[1], session => (
              <RequestBlock
                isArchive
                key={session._id}
                session={session}
              />
            ))}
          </div>
        ))}
      </PageWrapper>
    );
  }
}

ArchiveRequests.propTypes = {
  sessions: PropTypes.array,
};

export default ArchiveRequests;

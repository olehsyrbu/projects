import React from 'react';
import PropTypes from 'prop-types';
import { getRoomInfo } from 'app/utils';

const RoomStructureInfo = ({ style, rooms = [] }) => (
  <div style={style} >
    {rooms.map(({ amount = 0, room = {} }, index, arr) => {
      if (!room) return null;
      const roomInfo = getRoomInfo(room.name);
      if (amount) {
        return (
          <span key={index}>
            {amount} {roomInfo && roomInfo.displayAbbr}{(index !== arr.length - 1) && ', '}
          </span>
        );
      }
      return null;
    })}
  </div>
);

RoomStructureInfo.propTypes = {
  rooms: PropTypes.array,
  style: PropTypes.object,
};

export default RoomStructureInfo;

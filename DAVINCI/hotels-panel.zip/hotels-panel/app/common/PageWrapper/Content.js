import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { colors } from 'app/style/variables';

const ContentWrap = styled.section`
  flex: 3 3 auto;
  max-width: 1232px;
  box-sizing: content-box;
  background-color: ${colors.light};
  margin: 0 auto;
  padding: 5px 0;
`;

const Content = ({ children, style }) => (
  <ContentWrap style={style} >
    {children}
  </ContentWrap>
);

Content.propTypes = {
  children: PropTypes.node,
  style: PropTypes.object,
};

export default Content;

import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';

const PageWrap = styled.div`
  flex-direction: column;
  position: relative;
  flex: 1 1 auto;
  padding: 72px calc((107vw - 1160px)/2);
  overflow: hidden;
`;

const PageWrapper = ({ children, style }) => (
  <PageWrap style={style} >
    {children}
  </PageWrap>
);

PageWrapper.propTypes = {
  children: PropTypes.node,
  style: PropTypes.object,
};

export default PageWrapper;

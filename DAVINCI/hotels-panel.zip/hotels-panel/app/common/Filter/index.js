import React from 'react';
import PropTypes from 'prop-types';
import DropDown from 'app/common/DropDown';
import { isEmpty } from 'lodash';

const FilterStyle = {
  style: {
    width: '350px',
  },
  iconStyle: {
    top: '-8px',
  },
};

class Filter extends React.PureComponent {
  render() {
    const { list, onChangeFilter, active } = this.props;
    return (
      <div>
        <DropDown defaultValue={active || !isEmpty(list) && list[0].value} list={list} styleDrop={{ ...FilterStyle }} onChange={onChangeFilter} />
      </div>
    );
  }
}
Filter.defaultProps = {
  list: [],
  onChangeFilter: () => {},
};

Filter.propTypes = {
  list: PropTypes.array,
  onChangeFilter: PropTypes.func,
};

export default Filter;


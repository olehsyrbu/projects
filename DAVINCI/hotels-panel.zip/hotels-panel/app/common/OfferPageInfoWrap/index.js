import React from 'react';
import PropTypes from 'prop-types';
import { InfoWrap, InfoWrapHeader, InfoWrapHeaderTitle, InfoWrapContent } from './style';

class InfoRequest extends React.PureComponent {
  render() {
    const { children, title } = this.props;
    return (
      <InfoWrap>
        <InfoWrapHeader>
          <InfoWrapHeaderTitle>
            {title}
          </InfoWrapHeaderTitle>
        </InfoWrapHeader>
        <InfoWrapContent>
          {children}
        </InfoWrapContent>
      </InfoWrap>
    );
  }
}

InfoRequest.propTypes = {
  children: PropTypes.any.isRequired,
  title: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
};

export default InfoRequest;

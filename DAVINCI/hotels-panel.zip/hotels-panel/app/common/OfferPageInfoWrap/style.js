import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

export const Row = styled.div`
  display: flex;
  align-items: flex-start;
  font-weight: 500;
  white-space: nowrap;
  &:not(:last-child) {
    padding-bottom: 4px;
  }
  .label {
    height: 24px;
    display: flex;
    align-items: center;
    align-self: flex-start;
    line-height: 24px;
    font-size: ${font.s13};
    font-weight: normal;
    margin-right: auto; 
  }
  .budgetLabel {
      white-space: initial;
      height: auto;
  }
  .text {
    white-space: pre-wrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-left: auto;
    text-align: right;
    font-size: ${font.s13};
    align-self: flex-start;
  }
  .multiLine {
    white-space: normal;
    .label {
      display: inline;
      padding-right: 25px;
    }
  }
`;

export const InfoWrap = styled.div`
  display: flex;
  flex-direction: column;
  max-width: 270px;
  width: 100%;
  border-radius: 3px;
  color: ${colors.dark};
`;
export const InfoWrapHeader = styled.div`
  border: 1px solid ${colors.borderGray};
  background-color: ${colors.grayBGText};
  color: ${colors.grayBg};
  font-size: ${font.m};
  font-weight: 500;
  text-transform: uppercase;
  height: 32px;
  border-radius: 4px;
  box-sizing: border-box;
`;

export const InfoWrapHeaderTitle = styled.div`
  color: rgba(51, 51, 51, 0.4);
  padding: 8px 8px 8px 16px;
  word-break: break-all;
  line-height: 14px;
  font-size: ${font.xs11};
`;

export const InfoWrapContent = styled.div`
  padding: 12px 16px;
  font-size: ${font.m};
`;

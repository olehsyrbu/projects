import React from 'react';
import PropTypes from 'prop-types';
import Snackbar from 'material-ui/Snackbar';
import { colors } from 'app/style/variables';

export default class NotifySnackbar extends React.Component {
  static propTypes = {
    open: PropTypes.bool,
  };
  static defaultProps = {
    open: false,
  };

  getStyle() {
    const { isError, isSuccess } = this.props;
    if (isError) {
      return {
        backgroundColor: `${colors.errorBgr}`,
        textAlign: 'center',
      };
    }
    if (isSuccess) {
      return {
        backgroundColor: `${colors.green2}`,
        textAlign: 'center',
      };
    }
    return {
      textAlign: 'center',
    };
  }

  handleRequestClose() {
    const { onClose } = this.props;
    if (typeof onClose === 'function') {
      onClose();
    }
  }

  render() {
    const { open = false, message } = this.props;
    return (
      <Snackbar
        open={open}
        bodyStyle={this.getStyle()}
        message={message}
        autoHideDuration={4000}
        onRequestClose={this.handleRequestClose.bind(this)}
      />
    );
  }
}

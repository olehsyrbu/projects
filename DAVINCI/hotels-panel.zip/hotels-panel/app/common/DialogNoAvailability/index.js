import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedBtn from 'app/common/RaisedBtn';
import i18n from 'app/utils/i18n';
import img from 'app/media/icons8-reply.svg';

import styled from 'styled-components';

const Header = styled.div`
  color: #222222;
  font-size: 16px;
  font-weight: bold;
  height: 24px;

`;
const Body = styled.div``;
const Btns = styled.div`
  display: flex;
  flex-direction: column;
  margin: auto;
  max-width: fit-content;
`;
const Image = styled.img`
  margin: 48px auto 14px;
  display: flex;
`;
const Text = styled.p`
  color: #333333;
  font-size: 18px;
  line-height: 24px;
  text-align: center;
  margin-bottom: 40px;
`;

const customDialogStyles = {
  contentStyle: {
    width: '450px',
    height: '500px',
    maxWidth: 'none',
  },
  bodyStyle: {
    padding: '16px 24px 40px',
    maxHeight: '500px',
  },
};

const btn = {
  fontSize: '13px',
};

const styleDefBtn = {
  height: 'none',
  marginTop: '8px',
  boxShadow: 'none',
  border: 'none',
  ...btn,
};
import Close from 'app/common/CloseBtn';

const DialogNoAvailability = ({ onClick, onClose }) => (
  <Dialog
    open
    modal
    {...customDialogStyles}
  >
    <div>
      <Close onClose={onClose} styleClose={{ top: '20px' }} />
      <Header>{i18n('app.dialog.notAvailability.title')}</Header>
      <Body>
        <Image src={img} />
        <Text>{i18n('app.dialog.notAvailability.text')}</Text>
        <Btns>
          <RaisedBtn
            onClick={onClick.bind(this, 'REMIND_LATER')}
            label={i18n('app.dialog.notAvailability.btnYes')}
            primary
            secondary
            size={40}
            styleData={btn}
          />
          <RaisedBtn
            size={40}
            styleData={styleDefBtn}
            onClick={onClick.bind(this, 'NO_ROOMS')}
            label={i18n('app.dialog.notAvailability.btnNo')}
          />
        </Btns>
      </Body>
    </div>
  </Dialog>
);

DialogNoAvailability.propTypes = {};

export default DialogNoAvailability;

import React from 'react';
import styled from 'styled-components';
import IconInfo from '../IconInfo';
import TextCenterHeight from 'app/common/design/TextCenterHeight';
import { TextField } from 'app/ui';
import { colors, font, fontWeight } from 'app/style/variables';

const Title = styled(TextCenterHeight)`
  font-size: ${font.m};
  color: ${colors.text};
  font-weight: ${fontWeight.bold};
  line-height: ${font.ml};
  margin-bottom: 8px;
`;

const TextInputWithTitle = ({
  title, placeholder, onChangeText, styleTitle, styleTextArea, style, text, hintId, error, hintStyleClass,
}) => (
  <div style={style}>
    <Title style={styleTitle}>{title} {hintId && <IconInfo id={hintId} className={hintStyleClass} />}</Title>
    <TextField
      error={error}
      multiline
      value={text}
      style={styleTextArea}
      placeholder={placeholder}
      onChange={onChangeText}
    />
  </div>
);

TextInputWithTitle.displayName = 'TextInputWithTitle';

export default TextInputWithTitle;

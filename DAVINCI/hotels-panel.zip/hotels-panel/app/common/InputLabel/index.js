import React from 'react';
import { TextField } from 'app/ui';

const InputLabel = ({
  errorText, className, floatingLabelText, error, ...props
}) => (
  <div className={`${className} u-input`}>
    <TextField
      error={error}
      {...props}
    />
    <i className="label">{floatingLabelText}</i>
  </div>
);

export default InputLabel;

import React from 'react';
import PropTypes from 'prop-types';

import isArray from 'lodash/isArray';
import size from 'lodash/size';
import { Container, Row, Col } from 'reactstrap';

import Filter from 'material-ui/svg-icons/image/filter-9-plus';
import RoomStructureInfo from 'app/common/RoomStructureInfo';

import Label from 'app/common/design/LabelKeys';
import HeaderOfferStyle from 'app/common/design/HeaderOfferStyle';
import Date from 'app/common/Date';
import More from 'app/common/More';
import Location from 'app/common/Location';
import i18n from 'app/utils/i18n';

import WrapMargColumn from 'app/common/design/WrapMargColumn';
import IconBed from 'app/common/IconBed';
import IconWrap from 'app/common/design/IconWrap';

import {
  DateEl,
  FilterStyle,
} from './style';

const renderLabelDate = (sessions) => {
  const maxLength = 4;
  // get first 4 (maxLength) element in session;
  return isArray(sessions) && sessions.slice(0, maxLength).map(({ checkIn, checkOut }, index) => [
      <DateEl date={{ checkOut, checkIn }} />,
      sessions.length > maxLength && maxLength - 2 < index && <More amount={sessions.length - maxLength} handleMoreClick={() => {}} />,
  ]);
};

class HeaderRequest extends React.PureComponent {
  render() {
    const {
      sessions, checkIn, checkOut, cityName, radius, rooms,
    } = this.props;

    return (
      <HeaderOfferStyle className="header" >
        <Container>
          <Row>
            <Col xs="12" lg="3" md="6">
              <WrapMargColumn>
                {size(sessions) > 0
                  ? <div><Filter style={FilterStyle} /> {renderLabelDate(sessions)}</div>
                  : <Date date={{ checkOut, checkIn }} />
                }
              </WrapMargColumn>
              <WrapMargColumn>
                <Location city={cityName} radius={radius} />
              </WrapMargColumn>
            </Col>
            <Col xs="12" lg="3" md="6">
              <WrapMargColumn>
                <Label>{i18n('app.components.Request.room')}:</Label>
              </WrapMargColumn>
              <WrapMargColumn>
                <Row>
                  <IconWrap>
                    <IconBed />
                  </IconWrap>
                  <Col xs="10">
                    <RoomStructureInfo rooms={rooms} />
                  </Col>
                </Row>
              </WrapMargColumn>
            </Col>
          </Row>
        </Container>
      </HeaderOfferStyle>
    );
  }
}

HeaderRequest.defaultProps = {
  sessions: [],
  checkIn: '',
  checkOut: '',
  cityName: '',
  radius: 0,
  rooms: [],
};

HeaderRequest.propTypes = {
  sessions: PropTypes.array,
  rooms: PropTypes.array,
  checkIn: PropTypes.any,
  checkOut: PropTypes.any,
  location: PropTypes.string,
  radius: PropTypes.number,
  cityName: PropTypes.string,
};

export default HeaderRequest;

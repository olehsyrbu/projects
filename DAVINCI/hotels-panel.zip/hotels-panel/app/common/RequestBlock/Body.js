import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import { get, round } from 'lodash';

import MealBlock from 'app/common/SentedOffer/MealBlock';
import RatingHotelBlock from 'app/common/SentedOffer/RatingHotelBlock';
import BudgetBlock from 'app/common/SentedOffer/BudgetBlock';
import CityTaxBlock from 'app/common/SentedOffer/CityTaxBlock';
import RequestWasSentBlock from 'app/common/SentedOffer/RequestWasSentBlock';
import CommentsBlock from 'app/common/SentedOffer/CommentsBlock';
import LabelGroupType from 'app/common/SentedOffer/LabelGroupType';
import BtnGroup from 'app/common/BtnGroup';
import { getMealName } from 'app/utils';
import { CORPORATE, defValueCurrency } from 'app/utils/global-constant';

import { RequestBlockContentStyle } from './style';
import i18n from 'app/utils/i18n';
import { getCurrencyByAbbr } from '../../utils/currency';
import CurrencyProvider from '../../providers/Requests/CurrencyProvider';
import HotelProvider from '../../providers/Requests/HotelProvider';
import { adopt } from 'react-adopt';

class Body extends React.PureComponent {
  render() {
    const {
      isRating,
      budget,
      createdAt,
      isArchive,
      requestData,
      disabledCancel,
      handleClickConfirm,
      handleDeclineSession,
      sessionRequestComment,
      hotel,
      currencies,
      isNewRequest,
    } = this.props;

    const mealFromReq = get(requestData, 'meal');
    const { sign: currencySign } = hotel && hotel.currencyAbbr && !isNewRequest
      ? getCurrencyByAbbr(currencies, hotel.currencyAbbr)
      : defValueCurrency;

    const budgetMaxLocal = round(get(requestData, 'budgetMax', ''), 2);
    const budgetMinLocal = round(get(requestData, 'budgetMin', ''), 2);
    const groupType = get(requestData, 'groupType', '');
    const groupTypeValue = groupType === CORPORATE ? i18n('app.components.Reservations.CORPORATE') : groupType;
    const meal = getMealName(mealFromReq);
    const budgetText = budgetMinLocal && budgetMaxLocal ? `${budgetMinLocal.toString()}-${budgetMaxLocal.toString()}` : budget;

    return (
      <RequestBlockContentStyle>
        <Row>
          <Col xs="12" lg="4" md="6">
            <MealBlock
              meal={meal || '-'}
              msg={i18n('app.components.Request.meal_plan')}
            />
            {isRating && (
              <RatingHotelBlock
                handleRating={this.handleRating}
                msg={i18n('app.components.Request.hotel_rating')}
                rating={get(requestData, 'stars', [])}
              />
            )}
          </Col>
          <Col xs="12" lg="4" md="6">
            <BudgetBlock
              sessionBudget={budgetText}
              sign={currencySign}
            />
            <CityTaxBlock
              msg={i18n('app.components.Request.city_tax')}
              cityTax={get(requestData, 'cityTax')}
            />
          </Col>
          <Col xs="12" lg="4" md="6">
            <RequestWasSentBlock
              classStyle="OfferWrapRowPadding"
              msg={i18n('app.components.Requests.wasSent')}
              createdAt={createdAt}
            />
            <LabelGroupType
              msg={i18n('app.components.Reservations.groupType')}
              value={groupTypeValue}
            />
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <CommentsBlock msg={i18n('app.components.Request.comment')} commentText={sessionRequestComment} />
          </Col>
          {!isArchive && <Col xs="12" lg="12" md="6">
              <BtnGroup
                size={46}
                disabledCancel={disabledCancel}
                labelCancel={i18n('app.components.Request.NoAvailability')}
                labelConfirm={i18n('app.components.Request.MakeOffer')}
                onClickConfirm={handleClickConfirm}
                onClickCancel={handleDeclineSession}
              />
            </Col>
          }
        </Row>
      </RequestBlockContentStyle>
    );
  }
}

Body.propTypes = {
  requestData: PropTypes.object,
  isNewRequest: PropTypes.bool,
  isRating: PropTypes.bool,
  budget: PropTypes.number,
  createdAt: PropTypes.string,
  sessionRequestComment: PropTypes.string,
  disabledCancel: PropTypes.bool,
  handleClickConfirm: PropTypes.func,
  handleDeclineSession: PropTypes.func,
};
const Composed = adopt({
  currencies: CurrencyProvider,
  hotel: HotelProvider,
});

export default props => (<Composed>
  {data => (<Body {...data} {...props} />)}
</Composed>);


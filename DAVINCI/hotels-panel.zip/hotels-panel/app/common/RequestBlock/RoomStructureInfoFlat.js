import { getRoomInfo } from 'app/utils';

export default rooms => (
  rooms.map(({ room, amount }) => {
    const roomName = getRoomInfo(room.name);
    return `${amount} ${roomName && roomName.displayAbbr}`;
  }).join(', ')
);

import React from 'react';
import { FormattedMessage } from 'react-intl';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import ContactIcon from 'material-ui/svg-icons/communication/mail-outline';

import { colors } from 'app/style/variables';
import i18n from 'app/utils/i18n';
import DialogNotification from 'app/common/DialogNotification';
import NotificationBlock from 'app/common/NotificationBlock';
import OfferInfoWrapWrap from 'app/common/SentedOffer';
import Header from './Header';
import Body from './Body';
import { withRouter } from 'react-router';
import { redirectToOfferPage, redirectToNewRequestsPage } from 'app/utils';
import { dateFormatDMYY } from 'app/utils/date';
import { getRoomStructureInfoFlat } from 'app/utils/rooms';
import DialogNoAvailability from 'app/common/DialogNoAvailability';
import DialogOfferConflicts from 'app/common/DialogOfferConflicts';
import { ToastDanger } from 'app/ui/Toastr';

const styleIcon = { width: 40, height: 40 };

class RequestBlock extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isChangedSession: false,
      isOpenDialogNotAvailable: false,
      declined: false,
      disabledCancel: false,
      isCheckConflicts: false,
      isRating: true,
    };
    this.handleClickConfirm = this.handleClickConfirm.bind(this);
    this.handleDeclineSession = this.handleDeclineSession.bind(this);
    this.handlerOk = this.handlerOk.bind(this);
    this.notify = this.notify.bind(this);
    this.handleRating = this.handleRating.bind(this);
    this.handlerCloseDialog = this.handlerCloseDialog.bind(this);
  }

  handleCheckConflictOffer = () => this.setState({ isCheckConflicts: true });

  handleClickConfirm = () => {
    const { session, history } = this.props;
    redirectToOfferPage(session._id, history);
  }

  handlerDeclineOffer = (decision) => {
    const {
      onDeclineSession, session, isHasNotificationTitle, history,
    } = this.props;

    this.notify();
    this.setState({
      declined: true,
      disabledCancel: true,
      isOpenDialogNotAvailable: false,
    });
    setTimeout(() => {
      onDeclineSession({
        sessionId: session && session._id, decision,
      });

      isHasNotificationTitle && redirectToNewRequestsPage(history);
    }, 400);
  };

  handleDeclineSession() {
    this.setState({ isOpenDialogNotAvailable: true, isCheckConflicts: false });
  }

  handlerOk() {
    this.setState({ isChangedSession: false });
  }

  notify = () => ToastDanger({ title: i18n('app.components.Request.declineSession') })

  handleRating(rating) {
    this.setState({ isRating: rating });
  }

  handlerCloseDialog = () => this.setState({
    isOpenDialogNotAvailable: false,
    isCheckConflicts: false,
  });

  render({
    session, isHasNotificationTitle, hotel, isArchive, isNewRequest,
  } = this.props) {
    const {
      num,
      checkIn,
      checkOut,
      createdAt,
      radius,
      sessions,
      requestData,
      sessionRequestComment,
      budget,
      _id,
    } = session;

    const {
      declined, isRating, disabledCancel, isOpenDialogNotAvailable, isChangedSession, isCheckConflicts,
    } = this.state;

    return (
      <OfferInfoWrapWrap
        num={num}
        declined={declined}
      >
        {isCheckConflicts && <DialogOfferConflicts
          sessionId={_id}
          onClickYes={this.handleClickConfirm}
          onClickNo={this.handleDeclineSession}
          onClose={this.handlerCloseDialog}
        />}
        {isHasNotificationTitle &&
          <NotificationBlock
            icon={<ContactIcon style={styleIcon} color={colors.grayBg} />}
            title={i18n('app.components.Request.infoTitle')}
            text={<FormattedMessage
              id="app.components.Request.infoText"
              values={{
                hotel: hotel ? hotel.name : '',
                arrive: dateFormatDMYY(checkIn),
                away: dateFormatDMYY(checkOut),
                structure: getRoomStructureInfoFlat(get(session, 'rooms', [])),
              }}
            />}
          />
        }

        {isOpenDialogNotAvailable && <DialogNoAvailability
          onClick={this.handlerDeclineOffer}
          onClose={this.handlerCloseDialog}
        />}

        {isChangedSession &&
          <DialogNotification
            isOpen
            isChangedSession={isChangedSession}
            onClick={this.handlerOk}
            action="changed"
          />
        }
        <Header
          checkIn={checkIn}
          checkOut={checkOut}
          cityName={requestData.geo.cityName}
          radius={radius}
          rooms={get(session, 'rooms', [])}
          sessions={sessions}
        />
        <Body
          isNewRequest={isNewRequest}
          isArchive={isArchive}
          requestData={requestData}
          isRating={isRating}
          budget={budget}
          createdAt={createdAt}
          sessionRequestComment={sessionRequestComment}
          disabledCancel={disabledCancel}
          handleClickConfirm={this.handleCheckConflictOffer}
          handleDeclineSession={this.handleDeclineSession}
        />
      </OfferInfoWrapWrap>
    );
  }
}

RequestBlock.propTypes = {
  session: PropTypes.object,
  checkIn: PropTypes.string,
  checkOut: PropTypes.string,
  isHasNotificationTitle: PropTypes.bool,
  isNewRequest: PropTypes.bool,
};

export default withRouter(RequestBlock);

import styled from 'styled-components';
import { colors, font, gap } from 'app/style/variables';
import Date from 'app/common/Date';

export const RequestBlockContentStyle = styled.article`
  padding-top: 20px;
  padding-bottom: 20px;
  border: 1px solid ${colors.grayWhite}
  border-top: none;

  display: flex;
  flex-wrap: wrap;
  padding: ${gap.g4};
  font-size: ${font.ml};
  border: 1px solid ${colors.grayWhite};
  border-top: none;
  .hotels-offers {
    padding-right: ${gap.g1};
  }
`;

export const WarnMessage = styled.span`
  font-size: 20px;
  padding-left: 20px;
`;

export const Text = styled.div`
  max-width: 250px;
  overflow: hidden;
  position: relative; 
  line-height: 1.25em;
  max-height: 4.8em; 
  text-align: justify;  
  margin-right: -1em;
  padding-right: 1em;
  &:before {
    content: '...';
    position: absolute;
    right: 0;
    bottom: 0;
  }
  &:after {
    content: '';
    position: absolute;
    right: 0;
    width: 1em;
    height: 1em;
    margin-top: 0.2em;
    background: white;
  }
`;

export const FilterStyle = {
  color: colors.grayBg,
  marginRight: gap.g2,
  height: gap.g6,
  width: gap.g6,
};

export const DateEl = styled(Date)`
  margin-right: ${gap.g1};
`;

import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';

import Close from 'material-ui/svg-icons/navigation/close';

const CloseWrap = styled.div`
  position: absolute;
  right: 32px;
  top: ${props => (props.top || '36px')};
  cursor: pointer;
`;

const CloseBtn = ({
  onClose, className, styleClose, top,
}) => (
  <CloseWrap onClick={onClose} className={className} style={styleClose} top={top}>
    <Close color={colors.grayBg} hoverColor={colors.grayWhiteText} />
  </CloseWrap>
);

CloseBtn.propTypes = {
  onClose: PropTypes.func,
};

export default CloseBtn;

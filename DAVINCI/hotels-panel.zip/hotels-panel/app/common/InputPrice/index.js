import React from 'react';
import { TextField } from 'app/ui';

const InputPrice = ({ floatingLabelText, ...props }) => (
  <div className="input-price">
    <TextField
      {...props}
    />
    <i className="label-sign">{floatingLabelText}</i>
  </div>

);

export default InputPrice;

import React, { Fragment } from 'react';
import { adopt } from 'react-adopt';
import Dialog from 'app/ui/Dialog';
import RaisedBtn from 'app/common/RaisedBtn';
import i18n from 'app/utils/i18n';
import styled from 'styled-components';
import { toHHMMSS, getPeriodLiving, getIsValidTime } from 'app/utils/date';
import ConflictOfferProvider from 'app/providers/Proposals/ConflictOfferProvider';
import Loading from 'app/common/Loading';
import RoomStructureInfo from 'app/common/RoomStructureInfo';

const Header = styled.div`
  color: #222222;
  font-size: 16px;
  font-weight: bold;
  height: 24px;
`;
const Body = styled.div`
    font-size: 14px;
`;
const Text = styled.p`
  color: #333333;
  font-size: 14px;
  line-height: 24px;
  text-align: left;
`;
const UpperText = styled.span`
    text-transform: uppercase; 
`;
const BlackText = styled.span`
    color: #333333;
    font-weight: 500;
    padding-right: 5px;
`;
const BodyContant = styled.div`
    background: #80808014;
    margin: 0 -24px;
    margin-bottom: 0px;
    padding: 5px 0;
    font-size: 14px;
`;
const Row = styled.div`
    border: 1px solid #3333336b;
    border-radius: 3px;
    padding: 10px;
    margin: 10px 24px;
`;
const IdOffer = styled.span`
    color: #23bbf5;
    padding-right: 10px;
`;
const Dates = styled.span`
    color: #d01414cc;
    font-weight: 500;
    padding-right: 10px;
`;
const Rooms = styled.span`
    color: #333333;
`;
const ValidStyle = styled.span`
    color: gray;
`;

const Space = styled.span`
  padding: 0 5px;
`;

const customDialogStyles = {
  contentStyle: {
    width: '450px',
    height: '500px',
    maxWidth: 'none',
  },
  bodyStyle: {
    padding: '16px 24px 40px',
    maxHeight: '500px',
  },
};

const btn = {
  fontSize: '13px',
};

const styleDefBtn = {
  height: 'none',
  marginRight: '8px',
  boxShadow: 'none',
  ...btn,
};

const renderRow = ({
  num, checkIn, checkOut, hotelsProposals,
}, i) => (
<Row key={i}>
  <div>
    <BlackText><UpperText>{i18n('app.OFFER')}</UpperText></BlackText>
    <IdOffer>#{num}</IdOffer>
    <ValidStyle>
      {
        getIsValidTime(hotelsProposals[0].upTo)
        ? <span><UpperText>{i18n('app.Valid')}</UpperText>
          <Space>{toHHMMSS(hotelsProposals[0].upTo)}</Space>
          <UpperText>{i18n('app.Hours')}</UpperText>
          </span>
        : <UpperText>{i18n('app.components.SentOffers.OFFER_EXPIRED')}</UpperText>
      }
    </ValidStyle>
  </div>
  <div>
    <Dates>{getPeriodLiving({ checkIn, checkOut })}</Dates>
    <Rooms><BlackText><RoomStructureInfo style={{ display: 'inline-block' }} rooms={hotelsProposals[0].proposals.rooms} /></BlackText></Rooms>
  </div>
</Row>
);

const DialogOfferConflicts = ({
  ConflictOfferQuery: { data, loading }, onClickYes, onClose, onClickNo,
}) => (
<Fragment>
  {loading && <Loading />}
  {data && data.intersectionSessions && data.intersectionSessions.length > 0 ?
    <Dialog
      open
      className="offer-conflict"
      title={<Header>{i18n('app.dialog.conflictsOffer.title')}</Header>}
      {...customDialogStyles}
      contentStyle={{ padding: '20px' }}
      bodyStyle={{ padding: '20px' }}
      onClose={onClose}
      actions={[
        <RaisedBtn
          size={40}
          styleData={styleDefBtn}
          onClick={onClickNo}
          label={i18n('app.dialog.conflictsOffer.btnNo')}
        />,
        <RaisedBtn
          onClick={onClickYes}
          label={i18n('app.dialog.conflictsOffer.btnYes')}
          primary
          secondary
          size={40}
          styleData={btn}
        />,
      ]}
    >
    <Fragment>
      <Body>
        <Text>{i18n('app.dialog.conflictsOffer.text')}</Text>
        <BodyContant>
          {data.intersectionSessions.map((item, i) => renderRow(item, i))}
        </BodyContant>
      </Body>
    </Fragment>
  </Dialog> : <div onClick={onClickYes()} />}
</Fragment>
);

DialogOfferConflicts.propTypes = {};

const Composed = adopt({
  ConflictOfferQuery: ConflictOfferProvider,
});

export default ({ ...data, sessionId }) => (<Composed sessionId={sessionId}>
  {props => (<DialogOfferConflicts {...props} {...data} />)}
</Composed>);

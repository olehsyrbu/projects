/**
 * Created by Max Kudla.
 */

import styled from 'styled-components';
import { nest } from 'recompose';

import LoadingSpinner from 'app/ui/LoadingSpinner';

const Loading = styled.div`
  display: flex;
  flex: 1;
  justify-content: center;
  align-items: center;
`;

export default nest(Loading, LoadingSpinner);

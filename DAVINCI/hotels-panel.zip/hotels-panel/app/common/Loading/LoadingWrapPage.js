import React from 'react';

import Loading from './index';
import PageWrapper from '../PageWrapper';
import { styleSubMenuPage } from '../design/style';
import Content from '../PageWrapper/Content';

export default () => (<PageWrapper style={styleSubMenuPage}><Content><Loading /></Content></PageWrapper>);

import React from 'react';

import styled from 'styled-components';
import { colors, font } from 'app/style/variables';
import { stringToColor } from 'app/utils/global-constant';

import AvatarEl from 'material-ui/Avatar';
import Done from 'material-ui/svg-icons/action/done';

const AvatarWrap = styled.div`
  position: relative;
  display: flex;
  justify-content: center;
  overflow: hidden;
  border-radius: 50%;
  width: ${props => props.size};
  height: ${props => props.size};
  background-color: ${props => !props.name && stringToColor(props.name)};
`;

const Checked = styled.div`
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${colors.blue}60;
`;

const Text = styled.span`
  text-transform: uppercase;
  font-size: ${font.m};
`;

const AvatarStyle = {
  display: 'flex',
  backgroundColor: 'inherits',
};

class Avatar extends React.PureComponent {
  render() {
    const {
      src, size = 40, name, style, checked,
    } = this.props;
    const avatarProps = {
      style: AvatarStyle,
      size,
    };

    return (
      <AvatarWrap size={`${size.toString()}px`} style={style}>
        {src
          ? <AvatarEl src={src} {...avatarProps} />
          : <AvatarEl {...avatarProps} ><Text>{ name && name.slice(0, 3)}</Text></AvatarEl>
        }
        { checked && <Checked><Done color={colors.light} /></Checked>}
      </AvatarWrap>
    );
  }
}

export default Avatar;

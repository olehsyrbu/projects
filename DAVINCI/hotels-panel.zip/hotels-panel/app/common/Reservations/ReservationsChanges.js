import React from 'react';
import size from 'lodash/size';
import { colors } from 'app/style/variables';

import Hint from 'app/common/Hint';
import imgConfirmed from 'app/media/confirmed.svg';
import { BodyWrap, CountStyle, ImgWrap, TextWrap, WrapChanges } from './Notification/style';

const prepareText = changes => changes.map((c, id) => <div key={id} >{c.msg} <br /> </div>);

class ReservationsChanges extends React.PureComponent {
  render() {
    const { changes, isConfirmed } = this.props;
    const color = isConfirmed ? colors.green : colors.orange;
    const message = changes && size(changes) > 0 && changes[0].msg;
    return (
      <WrapChanges>
        <BodyWrap>
          {isConfirmed ?
            <ImgWrap>
              <img src={imgConfirmed} />
            </ImgWrap> :
            <CountStyle>{changes.length}</CountStyle>
          }
          <TextWrap color={color}>
            <span>{message}</span>
          </TextWrap>
        <Hint className="date-notify" text={prepareText(changes)} />
        </BodyWrap>
      </WrapChanges>
    );
  }
}

export default ReservationsChanges;

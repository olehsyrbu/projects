import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import styled from 'styled-components';

import { INTERNAL_NO_AVAILABILITY } from 'app/utils/global-constant';
import { getIsCompleted } from 'app/utils/statuses';
import { colors } from 'app/style/variables';
import RoomStructureInfo from 'app/common/RoomStructureInfo';
import HeaderOfferStyle from 'app/common/design/HeaderOfferStyle';
import Label from 'app/common/design/LabelKeys';
import IconWrap from 'app/common/design/IconWrap';

import SendEmail from 'app/common/SentedOffer/SendEmail';
import WrapMargColumn from 'app/common/design/WrapMargColumn';
import FlexEnd from 'app/common/design/FlexEnd';
import IconBed from 'app/common/IconBed';
import Date from 'app/common/Date';

import HotelInfo from 'app/common/HotelInfo';
import LabelStatus from 'app/common/Reservations/LabelStatus';
import Notification from './Notification';
import size from 'lodash/size';
import i18n from 'app/utils/i18n';

const FlexEndStyle = styled(FlexEnd)`
  height: 100%;
`;

class ReservationOfferHeader extends PureComponent {
  render() {
    const {
      offer: {
        rooms, status4Hotel, checkIn, checkOut, num, status, dueDays, roomings, optionalProlongRequestStatus,
      } = {}, onClickHeader, name, logo,
    } = this.props;

    let roomingData = [];
    if (size(roomings) > 0) roomingData = roomings;

    return (
      <HeaderOfferStyle
        isOfferNoAvailability={status4Hotel === INTERNAL_NO_AVAILABILITY}
        onClick={onClickHeader}
      >
        <Row>
          <Col xs="3">
            <WrapMargColumn>
              <Date date={{ checkOut, checkIn }} />
            </WrapMargColumn>
            <WrapMargColumn>
              <HotelInfo
                hotelName={name}
                hotelLogo={logo}
                sizeAvatar={25}
                color={colors.grayDarkText}
              />
            </WrapMargColumn>
          </Col>
          <Col xs="2">
            <WrapMargColumn>
              <Label>{i18n('app.components.Request.room')}:</Label>
            </WrapMargColumn>
            <WrapMargColumn>
              <Row>
                <IconWrap>
                  <IconBed />
                </IconWrap>
                <RoomStructureInfo rooms={rooms} />
              </Row>
            </WrapMargColumn>
          </Col>

          <Col xs="3">
            <WrapMargColumn>
              <Label>{i18n('app.components.Requests.ReservationsStatus')}:</Label>
            </WrapMargColumn>
            <WrapMargColumn>
              <LabelStatus
                status={status}
                status4Hotel={status4Hotel}
                checkIn={checkIn}
                dueDays={dueDays}
              />
            </WrapMargColumn>
          </Col>
          <Col xs="2">
            <WrapMargColumn>
              <Label>{i18n('app.common.changes')}:</Label>
            </WrapMargColumn>
            <WrapMargColumn>
              <Notification
                status={status}
                optionalProlongRequestStatus={optionalProlongRequestStatus}
                roomings={roomingData}
              />
            </WrapMargColumn>
          </Col>
          {!getIsCompleted(status4Hotel) &&
              <FlexEnd>
                <FlexEndStyle>
                  <SendEmail
                    msg={i18n('app.common.sendEmail')}
                    id={num}
                  />
                </FlexEndStyle>
              </FlexEnd >
          }
        </Row>
      </HeaderOfferStyle>
    );
  }
}

ReservationOfferHeader.propTypes = {
  offer: PropTypes.shape({
    status4Hotel: PropTypes.string,
    checkIn: PropTypes.string,
    checkOut: PropTypes.string,
    num: PropTypes.string,
  }),
  hotel: PropTypes.shape({
    name: PropTypes.string,
  }),
};

export default ReservationOfferHeader;

import React, { PureComponent } from 'react';

import ReservationOfferBody from './ReservationOfferBody';
import ReservationOfferHeader from './ReservationOfferHeader';

import OfferInfoWrapWrap from 'app/common/SentedOffer';
import { getCurrencySignByProposals } from 'app/utils/currency';
import { statuses, mealDefaultFullText } from 'app/utils/global-constant';
import { getMealName, getCityTaxValue } from 'app/utils';
import { has } from 'lodash';
import OfferCollapseContainer from '../SentedOffer/OfferCollapseContainer';

const {
  AGENCY_SESSION_REQUEST,
} = statuses;

class Reservations extends PureComponent {
  constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
    this.state = { collapse: false };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  render() {
    const { offer, hotelQuery: { name, media: { logo } = {} } = {}, currencies } = this.props;
    const { collapse } = this.state;
    const {
      foc,
      meal,
      rooms,
      status,
      checkIn,
      checkOut,
      cityTax,
      createdAt,
      requestData,
      hotelProposal,
    } = offer;
    const signByCurrency = getCurrencySignByProposals(hotelProposal, currencies);

    // need get confirmed rooms and merge w/ prices
    const hotelProposalsData = {
      cancellationPolicy: hotelProposal.cancellationPolicy,
      rooms: [
        ...rooms.map(r => ({
          ...hotelProposal.rooms.find(hr =>
            has(hr, 'room.abbr') && has(r, 'room.abbr') && hr.room.abbr === r.room.abbr), // get price
          ...r,
        })),
      ],
    };

    const mealSession = status === AGENCY_SESSION_REQUEST && meal ? meal : requestData && requestData.meal;
    const findMeal = getMealName(mealSession);
    const mealText = findMeal ? findMeal.name : mealDefaultFullText;
    const cityTaxValue = getCityTaxValue(cityTax);

    return (
      <OfferInfoWrapWrap
        num={offer.num}
      >
        <ReservationOfferHeader
          logo={logo}
          name={name}
          onClickHeader={this.toggle}
          offer={offer}
        />
        <OfferCollapseContainer collapse={collapse} toggle={this.toggle}>
          {collapse ?
              <ReservationOfferBody
                foc={foc}
                meal={mealText}
                sign={signByCurrency}
                cityTaxValue={cityTaxValue}
                proposals={hotelProposalsData}
                checkIn={checkIn}
                checkOut={checkOut}
                createdAt={createdAt}
              />
              : null}
        </OfferCollapseContainer>
      </OfferInfoWrapWrap>
    );
  }
}

export default Reservations;

import React from 'react';
import isEmpty from 'lodash/isEmpty';
import size from 'lodash/size';
import i18n from 'app/utils/i18n';

import { statuses } from 'app/utils/global-constant';
import ReservationsChanges from '../ReservationsChanges';

const {
  PROLONG_STATUS_REQUEST,
  UNCONFIRMED_PROPOSALS_REQUEST,
  WAIT_FOR_CONFIRMATION,
  AGENCY_PROPOSAL,
  CONFIRMED,
} = statuses;

class Notification extends React.PureComponent {
  render() {
    const { status = '', roomings = [], optionalProlongRequestStatus = '' } = this.props;
    const notificationsData = [];

    let roomingStatus = '';
    let isConfirmed = false;

    const isRoomingHasStatus = _.last(roomings);
    if (isRoomingHasStatus) {
      roomingStatus = isRoomingHasStatus.status;
    }
    // Prolong option
    if (!isEmpty(optionalProlongRequestStatus) && optionalProlongRequestStatus === PROLONG_STATUS_REQUEST) {
      notificationsData.push({ msg: i18n('app.components.Reservations.PROLONG_STATUS_REQUEST') });
    }

    if (!isEmpty(optionalProlongRequestStatus) && optionalProlongRequestStatus === UNCONFIRMED_PROPOSALS_REQUEST) {
      notificationsData.push({ msg: i18n('app.components.Reservations.UNCONFIRMED_PROPOSALS_REQUEST') });
    }

    if (!isEmpty(status) && status === AGENCY_PROPOSAL) {
      notificationsData.push({ msg: i18n('app.components.Reservations.AGENCY_PROPOSAL') });
    }

    // Rooming list
    if (!isEmpty(roomingStatus) && roomingStatus === WAIT_FOR_CONFIRMATION) {
      notificationsData.push({ msg: i18n('app.components.Reservations.WAIT_FOR_CONFIRMATION') });
    }

    if (!isEmpty(roomingStatus) && roomingStatus === CONFIRMED) {
      notificationsData.push({ msg: i18n('app.components.Reservations.CONFIRMED') });
      isConfirmed = true;
    }

    return size(notificationsData) ? <ReservationsChanges changes={notificationsData} isConfirmed={isConfirmed} /> : null;
  }
}

export default Notification;

import { colors } from '../../../style/variables';
import styled from 'styled-components';

export const WrapChanges = styled.div`
  display: flex;
  &:hover {
    .date-notify {
      opacity: 1;
    }
  }
`;

export const CountStyle = styled.span`
  border-radius: 50%;
  background-color: ${colors.orange};
  width: 16px;
  height: 16px;
  display: inline-block;
  text-align: center;
  color: #fff;
  margin: auto;
  line-height: 17px;
`;

export const BodyWrap = styled.span`
 display: flex;
 line-height: 25px;
 width: 100%;
`;

export const ImgWrap = styled.span`
  img {
    width: 16px;
    height: 16px
    display: inline;
  }
`;

export const TextWrap = styled.span`
  white-space: nowrap;
  width: calc(100% - 20px);
  overflow: hidden;
  display: inline-block;
  text-overflow: ellipsis;
  padding-left: 5px;
  color: ${props => props.color};
`;


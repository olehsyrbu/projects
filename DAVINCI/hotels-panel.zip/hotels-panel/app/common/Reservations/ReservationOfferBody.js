import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import styled from 'styled-components';

export const WrapPadding = styled.div`
  padding-right: 10px;
`;

import TableRoomsSent from 'app/common/SentedOffer/TableRoomsSent';
import OfferHotelInfo from 'app/common/SentedOffer/OfferHotelInfo';
import CancelationPolicy from 'app/common/SentedOffer/CancelationPolicy';
import RequestWasSentBlock from 'app/common/SentedOffer/RequestWasSentBlock';
import i18n from 'app/utils/i18n';

const ReservationOfferBody = ({
  proposals,
  cityTaxValue,
  meal,
  foc,
  sign,
  createdAt,
}) => (
  <div>
    <Row>
      {(_.size(proposals.rooms)) &&
      <Col xs="4">
        <WrapPadding>
          <TableRoomsSent sign={sign} rooms={proposals.rooms} />
        </WrapPadding>
      </Col>
      }
      <Col xs="4">
        <OfferHotelInfo
          sign={sign}
          cityTaxValue={cityTaxValue}
          meal={meal}
          foc={foc}
        />
      </Col>
      <Col xs="4">
        <CancelationPolicy
          msg={i18n('app.components.HotelCancellationPolicy.title')}
          Policy={proposals.cancellationPolicy}
        />
        <RequestWasSentBlock
          msg={i18n('app.components.Requests.wasSent')}
          createdAt={createdAt}
        />
      </Col>
    </Row>
  </div>
);

ReservationOfferBody.displayName = 'ReservationOfferBody';

ReservationOfferBody.propTypes = {
  proposals: PropTypes.object,
  cityTax: PropTypes.string,
  meal: PropTypes.string,
  createdAt: PropTypes.string,
};
export default ReservationOfferBody;

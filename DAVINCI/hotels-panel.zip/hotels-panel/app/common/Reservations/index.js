import React from 'react';
import PropTypes from 'prop-types';
import size from 'lodash/size';
import map from 'lodash/map';

import Item from './Item';
import TitleBlockByDay from 'app/common/TitlePeriod';
import PageWrapper from 'app/common/PageWrapper';
import Content from 'app/common/PageWrapper/Content';

import EmptyInfo from 'app/common/EmptyInfo';
import { styleSubMenuPage } from 'app/common/design/style';
import i18n from 'app/utils/i18n';

const Reservations = ({
  reservations, textEmptyData, isCompleted, hotelQuery, currencies,
}) => (
  <PageWrapper style={styleSubMenuPage}>
    <Content>
      {size(reservations)
        ? <div>
          {map(reservations, offers => (
            <div key={offers[0]}>
              <TitleBlockByDay
                period="month"
                defMessage={i18n('app.components.SentOffers.Others')}
                date={offers[0]}
                count={size(offers[1])}
              />
              {map(offers[1], offer => (
                <Item
                  key={offer._id}
                  offer={offer}
                  hotelQuery={hotelQuery}
                  currencies={currencies}
                  isCompleted={isCompleted}
                />
              ))}
            </div>
          ))}
        </div>
        : <EmptyInfo text={textEmptyData} />
      }
    </Content>
  </PageWrapper>
);

Reservations.propTypes = {
  reservations: PropTypes.array,
  textEmptyData: PropTypes.object,
  hotelQuery: PropTypes.shape({
    name: PropTypes.string,
    media: PropTypes.shape({
      logo: PropTypes.string,
    }),
  }),
};

export default Reservations;

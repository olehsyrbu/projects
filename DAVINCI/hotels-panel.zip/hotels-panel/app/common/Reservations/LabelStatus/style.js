import styled from 'styled-components';

export const WrapStyle = styled.div`
  display: flex;
  &:hover {
    .date-notify {
      opacity: 1;
    }
  }
`;

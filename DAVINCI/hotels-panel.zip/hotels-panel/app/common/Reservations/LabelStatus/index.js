import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment/moment';

import { getDueDate, dateFormatDMY } from 'app/utils/date';
import { statuses } from 'app/utils/global-constant';
import { colors } from 'app/style/variables';

import DateFormat from 'app/common/DateFormat';
import Label from './Label';
import IconWrap from 'app/common/design/IconWrap';

import imgConfirmed from 'app/media/ic_reserved.svg';
import imgCanceled from 'app/media/ic_cancel1.svg';
import imgProlong from 'app/media/timer.svg';
import { getIsCompleted } from 'app/utils/statuses';
import i18n from 'app/utils/i18n';

const {
  HOTEL_PROPOSAL,
  AGENCY_CONFIRM,
  AGENCY_CANCEL_REQUEST,
  AGENCY_PROPOSAL,
} = statuses;

class ReservationLabelStatus extends React.PureComponent {
  render() {
    const {
      dueDays, checkIn, status, status4Hotel,
    } = this.props;
    const DueDate = getDueDate(checkIn, dueDays);
    const completedStatus = i18n('app.components.SentOffers.SUCCESSFULLY_COMPLETED');
    const operatorConfirmThisReservation = i18n('app.components.SentOffers.OperatorConfirmThisReservation');
    const OperatorCancelReservation = i18n('app.components.SentOffers.OperatorCancelReservation');
    const OptReservationExpired = i18n('app.components.SentOffers.OptReservationExpired');
    const till = i18n('app.components.SentOffers.till');

    if (getIsCompleted(status4Hotel)) {
      return (
        <Label hintText={completedStatus}>{completedStatus}</Label>
      );
    }
    if (status === AGENCY_CONFIRM) {
      return (<Label
        hintText={operatorConfirmThisReservation}
      >
        <IconWrap><img src={imgConfirmed} /></IconWrap>
        {operatorConfirmThisReservation}
        </Label>);
    }

    if (status === AGENCY_CANCEL_REQUEST) {
      return (<Label
        color={colors.red}
        hintText={OperatorCancelReservation}
      >
        <IconWrap><img src={imgCanceled} /></IconWrap>
        {OperatorCancelReservation}
        </Label>);
    }

    const isExpiredOptional = moment().isAfter(moment(checkIn).subtract((dueDays - 1), 'd'));
    if (status === HOTEL_PROPOSAL && isExpiredOptional) {
      return (<Label color={colors.red} hintText={OptReservationExpired}>
        <IconWrap><img src={imgProlong} /></IconWrap>
        {OptReservationExpired}
      </Label>);
    }
    if (status === HOTEL_PROPOSAL || status === AGENCY_PROPOSAL) {
      return (<Label hintText={<span>{till} {dateFormatDMY(DueDate)}</span>} >
        <IconWrap><img src={imgProlong} /></IconWrap>
        <span>
          {till} {' '}
          <DateFormat date={DueDate} />
        </span>
      </Label>);
    }
    return null;
  }
}

ReservationLabelStatus.propTypes = {
  status: PropTypes.string,
  status4Hotel: PropTypes.string,
  checkIn: PropTypes.string,
  dueDays: PropTypes.number,
};

export default ReservationLabelStatus;

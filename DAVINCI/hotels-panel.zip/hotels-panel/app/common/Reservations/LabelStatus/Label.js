import React from 'react';
import { WrapStyle } from './style';
import Label from 'app/common/LabelStatusStyle';

import Hint from 'app/common/Hint';

export default ({ hintText, children, ...props }) => (
  <WrapStyle>
    <Label {...props}>
      {children}
    </Label>
    <Hint className="date-notify" text={hintText} />
  </WrapStyle>
);

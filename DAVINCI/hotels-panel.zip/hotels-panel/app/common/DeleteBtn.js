import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';

import Delete from 'material-ui/svg-icons/action/delete-forever';

const DeleteWrap = styled.i`
  position: absolute;
  right: 6px;
  top: 50%;
  transform: translateY(-55%);
  cursor: pointer;
`;

class DeleteBtn extends React.PureComponent {
  render() {
    const { onClick, className } = this.props;
    return (
      <DeleteWrap className={className} onClick={onClick} >
        <Delete color={colors.red} hoverColor={`${colors.red}50`} />
      </DeleteWrap>
    );
  }
}

DeleteBtn.propTypes = {
  className: PropTypes.string,
  onClick: PropTypes.func,
};

export default DeleteBtn;

import React from 'react';
import PropTypes from 'prop-types';

import moment from 'moment/moment';
import styled from 'styled-components';
import { font } from 'app/style/variables';
import { changeDateType } from 'app/utils/date';
import { formatDMYhmA } from 'app/utils/global-constant';

const DateWrap = styled.div`
  display: flex;
  font-size: ${font.m};
  letter-spacing: 1px;
`;

export class DateFlat extends React.PureComponent {
  render() {
    const { date, className } = this.props;
    if (!date) return null;
    return (
      <DateWrap className={className} >
        {moment(new Date(changeDateType(date))).format(formatDMYhmA)}
      </DateWrap>
    );
  }
}

DateFlat.propTypes = {
  className: PropTypes.string,
};

export default DateFlat;

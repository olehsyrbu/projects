import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { colors, font } from 'app/style/variables';
import Calendar from 'material-ui/svg-icons/action/today';
import Hint from '../Hint';
import i18n from 'app/utils/i18n';
import { getHintDateText, getPeriodLiving } from 'app/utils/date';

const DateWrap = styled.div.attrs({
  className: 'date-wrap',
})`
  position: relative;
  display: inline-flex;
  align-items: center;
  padding: 1px 10px;
  background-color: ${props => (props.active ? colors.blue : colors.light)};
  border-radius: 1em;
  border: 1px solid ${props => (props.active ? colors.blue : colors.grayBg)};
  font-size: ${font.m};
  color: ${props => (props.active ? colors.light : colors.dark)};
  font-weight: 500;
  user-select: none;
  cursor: pointer;
  .date-notify {
    left: 26px;
  }
  &:hover {
    .date-notify {
      opacity: 1;
    }
  }
`;

export class DateComponent extends React.PureComponent {
  render() {
    const {
      style, onClick, className, active, date, isNotShowIconCalendar,
    } = this.props;

    const styleCalendar = {
      height: '1em',
      width: '1.8em',
      paddingRight: '8px',
      color: this.props.active ? colors.light : colors.grayBg,
    };

    return (
      <DateWrap
        onClick={onClick}
        className={className}
        active={active}
        style={style}
      >
        <Hint
          className="date-notify"
          text={<span>{getHintDateText(date)} {i18n('app.components.Offer.RoomStructure.RoomTable.nights')}</span>}
        />
        {!isNotShowIconCalendar && <Calendar style={{ ...styleCalendar }} />}
        {getPeriodLiving(date)}
      </DateWrap >
    );
  }
}

DateComponent.propTypes = {
  onClick: PropTypes.func,
  className: PropTypes.string,
  active: PropTypes.bool,
};

export default DateComponent;

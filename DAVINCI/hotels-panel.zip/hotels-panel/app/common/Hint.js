import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';

const HintWrap = styled.div`
  position: absolute;
  left: 10px;
  transform: translateX(-20px);
  bottom: calc(100% + 12px);
  padding: 6px;
  background-color: ${colors.grayDarkText};
  color: ${colors.light};
  opacity: 0;
  font-weight: 400;
  pointer-events: none;
  transition: opacity 0.2s ease-in-out;
  z-index: 1000;
  width: auto;
  white-space: pre-line;
  text-transform: none;
  border-radius: 3px;
  &::after {
    content: '';
    position: absolute;
    left: 14px;
    width: 0;
    height: 0;
    border-left: 7px solid transparent;
    border-right: 7px solid transparent;
    top: 100%;
    border-top: 7px solid ${colors.grayDarkText};
  }
`;

const Hint = ({ className, text, style }) => (
  <HintWrap className={className} style={style}>
    {text}
  </HintWrap>
);

Hint.propTypes = {
  className: PropTypes.string,
  style: PropTypes.object,
};

export default Hint;

import React from 'react';
import styled from 'styled-components';
import { colors, fontWeight, gap } from 'app/style/variables';
import i18n from 'app/utils/i18n';

import { dateFormatDMY, dateFormatMMMM, getYear } from 'app/utils/date';

const getTitleText = (date, period = 'day') => {
  if (period === 'day') {
    return dateFormatDMY(date);
  }
  return dateFormatMMMM(date);
};

const TitleStyle = styled.div`
 font-size: ${gap.g6}
 font-weight: ${fontWeight.lighter};
 padding-bottom: 10px;
 color: ${colors.grayBg};
`;

export default ({
  date, count, defMessage, period,
} = this.props) => (
  <TitleStyle>
    <span>
      {getYear(date) === 1970 ? defMessage :
        period
          ? i18n(`app.common.${getTitleText(date, period)}`)
          : getTitleText(date, period)
      }
      {' '} ({count})
    </span>
  </TitleStyle>
);

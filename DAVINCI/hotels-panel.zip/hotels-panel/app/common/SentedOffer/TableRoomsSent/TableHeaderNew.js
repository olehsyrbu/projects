import React from 'react';

import i18n from 'app/utils/i18n';
import { ThWrap } from './style';
import styled from 'styled-components';
import { colors } from 'app/style/variables';

const Header = styled.div`
  display:flex;
  flex:1;
  border: 1px solid ${colors.borderGray};
  border-bottom: none;
  border-radius: 4px 0 0 0;
  > div:first-child{
    border-radius: ${props => (props.isOfferPage ? '4px 0 0 0' : '14px 0 0 0')};
  }
`;

export default ({ isOfferPage }) => (
  <Header isOfferPage={isOfferPage}>
    <ThWrap>
      {i18n('app.components.Request.room')}
    </ThWrap>
    <ThWrap>
      {i18n('app.components.SentOffers.amount')}
    </ThWrap>
    <ThWrap>
      {i18n('app.components.SentOffers.price')}
    </ThWrap>
  </Header>
);

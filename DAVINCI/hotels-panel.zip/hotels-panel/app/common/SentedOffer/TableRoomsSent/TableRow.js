import React from 'react';

import { TdWrapOld } from './style';
import { getRoomInfo } from 'app/utils';

export default ({
  amount, price, name, styleTotal,
}) => (
  <tr>
    <TdWrapOld>
      {name && getRoomInfo(name).name}
    </TdWrapOld>
    <TdWrapOld>
      {amount}
    </TdWrapOld>
    <TdWrapOld style={styleTotal}>
      {price}
    </TdWrapOld>
  </tr>
);

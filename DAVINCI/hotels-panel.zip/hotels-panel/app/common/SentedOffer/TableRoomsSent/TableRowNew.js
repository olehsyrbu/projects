import React from 'react';

import { TdWrap } from './style';
import { getRoomInfo } from 'app/utils';
import Flex from 'app/common/design/Flex';
import styled from 'styled-components';
import { colors } from 'app/style/variables';

const RoomsRow = styled(Flex)`
  border: 1px solid ${colors.borderGray};
  border-bottom: none;
  font-weight: 500;
  :last-child{
    border-bottom: 1px solid ${colors.borderGray};
    border-radius: 0 0 0 4px;
  }
`;

export default ({
  amount, price, name, styleTotal,
}) => (
  <RoomsRow>
    <TdWrap>
      {name && getRoomInfo(name).name}
    </TdWrap>
    <TdWrap>
      {amount}
    </TdWrap>
    <TdWrap style={styleTotal}>
      {price}
    </TdWrap>
  </RoomsRow>
);

import React from 'react';
import PropTypes from 'prop-types';
import isArray from 'lodash/isArray';
import has from 'lodash/has';
import { getRoomInfo, formatPrice } from 'app/utils';
import i18n from 'app/utils/i18n';

import { TableStyledOld, ThWrapOld } from './style';
import TableRow from './TableRow';

import {
  Table,
  TR as Row,
  TH as Head,
  TD as Cell,
} from 'app/ui';

const getIsLocalPrice = price => has(price, 'localPrice.value') && price.localPrice.value;

const getIsValidRow = (price, amount) => {
  if (+amount === 0) return;
  return getIsLocalPrice(price) || price.primeCost;
};

const getPriceTotal = ({ primeCost, ...price }) => {
  const localPrice = getIsLocalPrice(price);
  return localPrice || primeCost;
};

const getRowNew = (room, sign, i) => {
  if (!room || room && !room.room) return null;
  const { room: { name }, amount, prices } = room;
  const [price] = prices;
  if (getIsValidRow(price, amount)) {
    return (
      <Row key={i}>
        <Cell className="u-text-capitalize">
        {name && getRoomInfo(name).name}
        </Cell>
        <Cell>
          {amount}
        </Cell>
        <Cell className="u-flex-align-right-end">
          {formatPrice(getPriceTotal(price), sign)}
        </Cell>
      </Row>
    );
  }
  return null;
};

const getRow = (room, sign, i) => {
  if (!room || room && !room.room) return null;
  const { room: { name }, amount, prices } = room;
  const [price] = prices;
  if (getIsValidRow(price, amount)) {
    return (<TableRow
      key={i}
      name={name}
      amount={amount}
      price={formatPrice(getPriceTotal(price), sign)}
    />);
  }
  return null;
};
const TableRoomsSent = ({
  rooms, sign, isShowTotal, totalPrice, styleTotal, isNewStyle, className,
}) => {
  if (isNewStyle) {
    return (
      <Table cellsWidth={[30, 20, 50]} className={`${className} ui-height-small`}>
        <Row className="table-header">
          <Head>{i18n('app.components.Request.room')}</Head>
          <Head>{i18n('app.components.SentOffers.amount')}</Head>
          <Head className="u-flex-align-right-end">{i18n('app.components.SentOffers.price')}</Head>
        </Row>
        {rooms.map((room, i) => room && getRowNew(room, sign, i))}
        {isShowTotal &&
          <Row>
            <Cell width="100" className="u-flex-align-right-end">
              <span className="u-text-total-table">{totalPrice}</span>
            </Cell>
          </Row>
        }
      </Table>
    );
  }
  return (<TableStyledOld className={className}>
      <thead >
        <tr>
          <ThWrapOld>
            {i18n('app.components.Request.room')}
          </ThWrapOld>
          <ThWrapOld >
            {i18n('app.components.SentOffers.amount')}
          </ThWrapOld>
          <ThWrapOld>
            {i18n('app.components.SentOffers.price')}
          </ThWrapOld>
        </tr>
      </thead>
      <tbody>
        {isArray(rooms) && rooms.map((room, i) => room && getRow(room, sign, i))}
        {isShowTotal && <TableRow styleTotal={styleTotal} price={totalPrice} />}
      </tbody>
    </TableStyledOld>
  );
};

TableRoomsSent.propTypes = {
  rooms: PropTypes.array.isRequired,
  sign: PropTypes.string,
};

export default TableRoomsSent;

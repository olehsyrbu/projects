import styled from 'styled-components';
import { Table } from 'reactstrap';
import { colors } from 'app/style/variables';

export const TableStyledOld = styled(Table)`
  border-right: 1px solid #D4DCE4 !important;
  border-bottom: 1px solid #D4DCE4 !important;
  margin: 0;
  > table td, {
    border: 1px solid ${colors.grayWhite};
  }
  > td, th, {
    text-align: right;
  }
  td:first-child,
  th:first-child {
    text-align: left;
  }
`;

export const ThWrapOld = styled.th`
  font-weight: 300;
  padding: 8px !important;
  font-size: 14px;
  line-height: 24px;
  background: ${colors.grayWhiteText}
  color: ${colors.grayLightText};
  border-top: 1px solid ${colors.grayWhite}  !important;
  border-bottom: 1px solid ${colors.grayWhite} !important;
  :last-child {
    text-align: right;
    padding-right: 23px !important;
  }
`;

export const TdWrapOld = styled.td`
  padding: 9px 16px !important;
  color: ${colors.gray} !important;
  :last-child {
    white-space: nowrap;
    text-align: right;
    padding-right: 20px !important;
  }
`;

export const ThWrap = styled.div`
  flex: 1;
  font-weight: 300;
  padding: 8px !important;
  font-size: 14px;
  line-height: 24px;
  background: ${colors.grayBGText}
  color: rgba(51,51,51,0.6);
  :last-child {
    text-align: right;
  }
`;

export const TdWrap = styled.div`
  flex: 1;
  padding: 9px 16px !important;
  color: ${colors.text} !important;
  :last-child {
    white-space: nowrap;
    text-align: right;
  }
`;

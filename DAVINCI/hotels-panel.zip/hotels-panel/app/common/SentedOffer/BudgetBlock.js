import React from 'react';
import { Row, Col } from 'reactstrap';
import Label from 'app/common/design/LabelKeys';
import { currency } from 'app/utils/currency';
import isNull from 'lodash/isNull';
import i18n from 'app/utils/i18n';

export default ({ sessionBudget, sign }) => (
  <Row className="OfferWrapRowPadding">
    <Col xs="4" lg="6" md="4">
      <Label>{i18n('app.components.Request.budget')}:</Label>
    </Col>
    <Col xs="8" lg="6" md="8" className="textBold">
      { isNull(sessionBudget) ? sessionBudget : currency({ num: sessionBudget, sign }) }
      { isNull(sessionBudget)
        ? i18n('app.components.HotelCondition.Info.budgetTextNoValue')
        : i18n('app.components.HotelCondition.Info.budgettext')
      }
    </Col>
  </Row>
);


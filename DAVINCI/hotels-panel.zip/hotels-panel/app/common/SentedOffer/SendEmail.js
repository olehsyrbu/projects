import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

import iconEmail from 'app/media/email.svg';
import { colors } from '../../style/variables';
import { email } from 'app/utils/global-constant';

const SendEmailStyle = styled.div`
  padding: 8px 13px;
  background: #fff;
  color: ${colors.grayBg} !important;
  border: 1px solid ${colors.grayWhite};
  > a {
    color: ${colors.grayBg} !important;
    &:hover {
      text-decoration: none !important;
    }
    > img {
      padding-right: 5px;
    }
  }
`;

const SendEmail = ({ msg, id }) => (
  <SendEmailStyle>
    <a href={`mailto:${email}?subject=Session ID:${id}`} >
      <img src={iconEmail} alt="" />
      {msg}
    </a>
  </SendEmailStyle>
);

SendEmail.propTypes = {
  msg: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.string,
  ]),
  id: PropTypes.string.isRequired,
};

export default SendEmail;

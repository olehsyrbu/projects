import React from 'react';
import { Row, Col } from 'reactstrap';
import infoSvg from 'app/media/info.svg';
import styled from 'styled-components';
import Hint from 'app/common/Hint';
import { colors } from 'app/style/variables';
import i18n from 'app/utils/i18n';

const PolicyWrap = styled.div`
  img {
    width: 15px;
  }
  &:hover {
    .date-notify {
      opacity: 1;
    }
  }
`;

const ColumnWrapTitle = styled.div`
  color: ${colors.grayLightText};
  opacity: 0.6;
  padding-right: 20px;
  font-weight: 300;
`;

const getTextHintPolicy = ({ free = '', periods = [] }) => (
  <div>
    <span>{i18n('app.components.Offer.HotelCondition.freeCancel')} - {free} - 0%</span>
    {periods.map((p, index) => (<div key={index}>
        {p.from} - {p.to}  {i18n('app.components.Offer.HotelCondition.days')} = {p.percent}%
      </div>))}
  </div>
);

const CancelationPolicy = ({ msg, Policy }) => (
  <Row>
    <Col xs="6">
      <ColumnWrapTitle>{msg}</ColumnWrapTitle>
    </Col>

    <Col xs="6">
      <PolicyWrap>
        <img src={infoSvg} />
        <Hint className="date-notify" text={getTextHintPolicy(Policy)} />
      </PolicyWrap>
    </Col>
  </Row>
);

export default CancelationPolicy;

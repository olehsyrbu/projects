import React from 'react';
import { Row, Col } from 'reactstrap';
import styled from 'styled-components';
import { colors } from 'app/style/variables';

const ColumnWrapTitle = styled(Col)`
  color: ${colors.grayBg};
  padding-right: 10px;
  font-weight: 300;
`;

const WrapText = styled(Col)`
  font-weight: 500;
  font-size: 16px;
  line-height: 24px;
`;
const LabelGroupType = ({
  msg, value, titleNum = '6', textNum = '6', classStyle,
}) => (
  <Row className={classStyle} >
    <ColumnWrapTitle xs={titleNum}>{msg}:</ColumnWrapTitle>
    <WrapText xs={textNum}>
      {value}
    </WrapText>
  </Row>
);

export default LabelGroupType;

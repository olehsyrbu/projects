import React from 'react';
import PropTypes from 'prop-types';
import Paper from 'material-ui/Paper';
import './style.scss';
import Id from 'app/common/Id';
import { PaperStyle, Pagewrapper, PaperStyledeclined } from './style';

const SentedOffer = ({ num, declined, children }) => (
  <div style={{ opacity: declined ? 0 : 1 }}>
    <Id id={num} />
    <Paper style={declined ? PaperStyledeclined : PaperStyle} zDepth={0}>
      <Pagewrapper>
        {children}
      </Pagewrapper>
    </Paper>
  </div>
);

SentedOffer.propTypes = {
  declined: PropTypes.bool,
  num: PropTypes.string,
  children: PropTypes.node,
};

export default SentedOffer;

import React from 'react';
import { Row, Col } from 'reactstrap';
import Label from 'app/common/design/LabelKeys';
import i18n from 'app/utils/i18n';

const CityTax = ({ msg, cityTax }) => (
  <Row className="OfferWrapRowPadding">
    <Col xs="4" lg="6" md="4">
      <Label>{msg}:</Label>
    </Col>
    <Col xs="8" lg="6" md="4" className="textBold">
      {cityTax !== 'notInclude'
        ? i18n('app.components.HotelCondition.Info.cityTaxIncluded')
        : i18n('app.components.HotelCondition.Info.cityTaxNotInclude')
      }
    </Col>
  </Row>
);

export default CityTax;

import React from 'react';
import styled from 'styled-components';
import Label from 'app/common/design/LabelKeys';
import { Row, Col } from 'reactstrap';

const Left = styled.div`
  min-width: 120px;
  display: inline-block;
`;

const Right = styled.div`
  display: inline-block;
  font-weight: 500;
`;

const CommentsBlock = ({ commentText, msg }) => (
  <Row>
    <Col xs="6" lg="2" md="6">
      <Left >
        <Label>{msg}:</Label>
      </Left>
    </Col>
    <Col xs="6" lg="10" md="6">
      <Right >
        <div>{commentText}</div>
      </Right>
    </Col>
  </Row>
);

export default CommentsBlock;


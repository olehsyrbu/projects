import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { Collapse, Container } from 'reactstrap';
import arrowSvg from 'app/media/arrow.svg';
import { colors } from 'app/style/variables';
import i18n from 'app/utils/i18n';

const WrapBody = styled.div`
  padding: 15px;
  border: 1px solid ${colors.grayWhite};
  border-top: none;
`;

const WrapHeaderStyle = styled.div`
  margin-left: -15px;
  margin-right: -15px;
  margin-bottom: 10px;
`;

const TextWrap = styled.div`
  opacity: 0.6;
  color: ${colors.dark};
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 1px;
  line-height: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
`;
const styleHideInfo = { transform: 'rotate(180deg)' };

const OfferCollapseContainer = ({ toggle, collapse, children }) => (<WrapBody>
  <WrapHeaderStyle>
    <Container onClick={toggle}>
      {collapse
        ? <TextWrap>{i18n('app.components.OfferBody.hideAdditionalInfo')}
            <img src={arrowSvg} style={styleHideInfo} />
          </TextWrap>
        : <TextWrap>{i18n('app.components.OfferBody.showAdditionalInfo')}
            <img src={arrowSvg} />
        </TextWrap>
      }
    </Container>
  </WrapHeaderStyle>
  <Collapse isOpen={collapse}>
    {children}
  </Collapse>
</WrapBody>);

OfferCollapseContainer.propTypes = {
  toggle: PropTypes.func,
  collapse: PropTypes.bool,
};

export default OfferCollapseContainer;

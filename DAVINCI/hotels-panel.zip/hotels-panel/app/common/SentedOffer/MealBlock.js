import React from 'react';
import { Row, Col } from 'reactstrap';
import Label from 'app/common/design/LabelKeys';

const MealBlock = ({ meal, msg }) => (
  <Row className="OfferWrapRowPadding">
    <Col xs="4">
      <Label>{msg}:</Label>
    </Col>
    <Col xs="8" className="textBold">
      {meal}
    </Col>
  </Row>
);

export default MealBlock;

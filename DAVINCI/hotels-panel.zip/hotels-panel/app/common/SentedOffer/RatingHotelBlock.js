import React from 'react';
import { Row, Col } from 'reactstrap';
import Label from 'app/common/design/LabelKeys';
import Rating from 'app/common/SentedOffer/Rating';

export default ({ handleRating, rating, msg }) => (
  <Row className="OfferWrapRowPadding">
    <Col xs="4">
      <Label>{msg}</Label>
    </Col>
    <Col xs="8">
      <Rating handleRating={handleRating} rating={rating} />
    </Col>
  </Row>
);


import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';
import { Row, Col } from 'reactstrap';
import ImageIcon from 'app/common/design/ImageIcon';
import i18n from 'app/utils/i18n';

import mealIcon from 'app/media/meal.svg';
import focIcon from 'app/media/foc.svg';
import cityTaxIcon from 'app/media/CityTaxNew.svg';

const ColumnWrap = styled(Col)`
  font-weight: 500;
`;

const ColumnWrapTitle = styled(Col)`
  color: ${colors.grayLightText};
  opacity: 0.6;
  font-weight: 300;
`;

class OfferHotelInfo extends React.PureComponent {
  render() {
    const {
      meal, foc, isInfoView, cityTaxValue,
    } = this.props;
    const style = isInfoView ? {} : { margin: '0 10px' };
    const wrapNumTitle = isInfoView ? '5' : '6';
    const wrapNumBody = wrapNumTitle === '5' ? '7' : '6';

    return (
      <div style={style}>
        <Row>
          <ColumnWrapTitle xs={wrapNumTitle}>
            <ImageIcon src={mealIcon} />
            {i18n('app.components.SentOffers.meal')}
          </ColumnWrapTitle>
          <ColumnWrap xs={wrapNumBody}>
            {meal || i18n('app.components.OfferHotelInfo.none')}
          </ColumnWrap>
        </Row>
        <Row>
          <ColumnWrapTitle xs={wrapNumTitle}>
            <ImageIcon src={focIcon} />
            {i18n('app.components.Offer.RoomStructure.focText')}
          </ColumnWrapTitle>
          <ColumnWrap xs={wrapNumBody}>
            {foc
              ? i18n('app.components.OfferHotelInfo.focTextPerson', { foc })
              : i18n('app.components.OfferHotelInfo.none')
            }
          </ColumnWrap>
        </Row>
        <Row>
          <ColumnWrapTitle xs={wrapNumTitle}>
            <ImageIcon src={cityTaxIcon} />
            {i18n('app.components.Request.city_tax')}
          </ColumnWrapTitle>
          <ColumnWrap xs={wrapNumBody}>
            {cityTaxValue || i18n('app.components.includedInPrice')}
          </ColumnWrap>
        </Row>
    </div>
    );
  }
}

OfferHotelInfo.propTypes = {
  cityTax: PropTypes.string,
  meal: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  foc: PropTypes.string,
  sign: PropTypes.string,
  isInfoView: PropTypes.bool,
};

export default OfferHotelInfo;

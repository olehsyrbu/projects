import React from 'react';
import { Row, Col } from 'reactstrap';
import styled from 'styled-components';

import DateFormat from 'app/common/DateFormat';
import { getDueDate, getIsFixed } from 'app/utils/date';
import { colors } from 'app/style/variables';
import ImageIcon from 'app/common/design/ImageIcon';

import reservationIcon from 'app/media/reservation-status.svg';

const ColumnWrapTitle = styled.div`
  color: ${colors.grayLightText};
  padding-right: 20px;
  font-weight: 300;
`;

const ColumnWrapBody = styled.div`
  font-weight: 500;
`;

export const MessageWrap = styled.span`
  padding-right: 3px;
`;

import i18n from 'app/utils/i18n';

class ReservationStatus extends React.PureComponent {
  render() {
    const {
      isShowImg, msg, dueDays, checkIn, titleNum = '6', textNum = '6', styleData = {},
    } = this.props;

    const DueDate = getDueDate(checkIn, dueDays);
    const isFixed = getIsFixed(checkIn, dueDays);

    return (
      <Row style={styleData}>
        <Col xs={titleNum}>
          <ColumnWrapTitle >
            {isShowImg ? <ImageIcon src={reservationIcon} /> : null}
            {msg}
          </ColumnWrapTitle>
        </Col>
        <Col xs={textNum}>
          <ColumnWrapBody >
            {isFixed
              ? <div>
                  {i18n('app.components.SentOffers.fixedOpt')}
                </div>
              : <div>
                  <MessageWrap>{i18n('app.components.SentOffers.till')}</MessageWrap>
                  <DateFormat date={DueDate} />
              </div>
            }
          </ColumnWrapBody>
        </Col>
      </Row>
    );
  }
}

export default ReservationStatus;

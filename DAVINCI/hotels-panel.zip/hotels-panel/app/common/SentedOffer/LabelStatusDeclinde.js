import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Row } from 'reactstrap';

import { colors } from 'app/style/variables';
import { declinedMessages } from 'app/utils/global-constant';

import DeclineWrap from 'app/common/design/DeclineStatusWrap';

import IconWrap from 'app/common/design/IconWrap';
import Label from 'app/common/LabelStatusStyle';

import i18n from 'app/utils/i18n';

import styled from 'styled-components';
import imgDeclined from 'app/media/x.svg';

const IconStyle = styled(IconWrap)`
  width: 20px;
  transform: rotate(90deg);
  color: ${colors.grayBg}
`;

const WrapText = styled.div`
  width: calc(100% - 25px);
`;

const WrapBody = styled.div`
  display: flex;
`;

class StatusDeclined extends Component {
  getDeclinedMsg = declinedMsg =>
    (declinedMessages.indexOf(declinedMsg) !== -1
      ? i18n(`app.common.declineHotel.${declinedMsg}`)
      : declinedMsg
    );

  render() {
    const {
      status4Hotel, declinedMsg,
    } = this.props;
    const text = i18n(`app.components.SentOffers.${status4Hotel}`);

    return (
      <Row>
        <Row>
          <WrapBody>
            <IconStyle>
              <img src={imgDeclined} />
            </IconStyle>
            <WrapText>
              {text && <Label color={colors.red}>{text}</Label>}
            </WrapText>
          </WrapBody>
        </Row>
        <Row>
          <DeclineWrap>
            ({this.getDeclinedMsg(declinedMsg)})
          </DeclineWrap>
        </Row>
      </Row>
    );
  }
}

StatusDeclined.propTypes = {
  status4Hotel: PropTypes.string,
  declined: PropTypes.bool,
};

export default StatusDeclined;

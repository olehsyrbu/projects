import { gap } from '../../style/variables';
import styled from 'styled-components';

export const PaperStyle = {
  position: 'relative',
  background: '#D4DCE4',
  marginBottom: gap.g9,
  opacity: 1,
  transitionProperty: 'opacity, margin',
  transitionDuration: '300ms, 0s',
  transitionTimingFunction: 'ease-in-out',
  transitionDelay: '200ms, 400ms',
};

export const PaperStyledeclined = {
  ...PaperStyle,
  opacity: 0,
  marginTop: '-300px',
};

export const Pagewrapper = styled.div`
  width: 100%;
  height: 100%;
  background: #fff;
  transition: opacity 300ms ease-in-out;
`;

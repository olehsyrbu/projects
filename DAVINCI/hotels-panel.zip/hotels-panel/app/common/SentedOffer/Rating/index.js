import React from 'react';
import PropTypes from 'prop-types';
import { isArray, isFunction } from 'lodash';
import { RatingContainer, CheckBox, stylesCheckbox } from './style';
import i18n from 'app/utils/i18n';

class Rating extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      ratingLabels: {
        '-1': '-',
        1: '1*',
        2: '2*',
        3: '3*',
        4: '4*',
        5: '5*',
      },
      ratingArray: [],
    };

    this.restoreRating = this.restoreRating.bind(this);
  }

  componentWillMount() {
    this.restoreRating();
  }

  restoreRating() {
    const { rating, handleRating } = this.props;
    const ratingAnyEnabled = rating && rating.filter(rait => rait.value === true);
    const ratingEnabledOnlyAny = ratingAnyEnabled && ratingAnyEnabled.length === 1 && ratingAnyEnabled.some(rait => rait.star && isFunction(rait.star.toString) && rait.star.toString() === '-1');
    const ratingToState = ratingEnabledOnlyAny ? i18n('app.components.Rating.any') : rating;
    this.setState({ ratingArray: ratingToState });

    handleRating && handleRating(!rating.every(star => star.value === false));
  }

  render() {
    const { rating } = this.props;
    const { ratingArray, ratingLabels } = this.state;
    const showStars = rating && !rating.some(star => star.value === true);
    if (showStars) return null;
    return (
      <RatingContainer className="rating" >
        {
          !isArray(ratingArray)
            ? <span className="text" >{ratingArray}</span>
            : ratingArray && ratingArray.map((rait, index) => (
              <CheckBox
                key={index}
                label={ratingLabels[rait.star] || '-'}
                style={stylesCheckbox}
                checked={rait.value}
              />
            ))
        }
      </RatingContainer>
    );
  }
}

Rating.propTypes = {
  rating: PropTypes.any,
};

export default Rating;

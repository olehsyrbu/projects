import styled from 'styled-components';
import { font } from 'app/style/variables';
import Checkbox from 'app/common/Checkbox';

export const RatingContainer = styled.span`
  display: flex;
  font-size: ${font.s};
  .text {
    font-size: ${font.m};
  }
`;

export const CheckBox = styled(Checkbox)`
  margin-right: -1px;  
  
  &>div {
    margin-right: 6px;
    display: flex;
    flex-direction: column-reverse;
    align-items: center;
    
    &>div {
      margin-right: 0 !important
    }
  }
`;

export const stylesCheckbox = {
  flexDirection: 'column-reverse',
};

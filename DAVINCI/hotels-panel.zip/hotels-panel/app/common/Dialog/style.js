import styled from 'styled-components';
import { colors, font, gap } from '../../style/variables';

export const CheckIconStyle = { width: '44px', height: '44px', opacity: '0.1' };

export const DialogWrap = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 64px;
  background-color: ${colors.light};
  border-radius: 3px;
  padding: 0 6px;
  text-align: center; 
  color: ${colors.light};
  font-size: ${font.m};
  a {
    color: ${colors.blue};
    text-decoration: underline;
  }
`;
export const Title = styled.h2`
  font-size: ${font.xl};
  margin: ${gap.g4} 0;
  color: ${colors.dark};
`;
export const Text = styled.p`
  opacity: 0.6;
  color: ${colors.dark};
  font-size: ${font.m};
  line-height: ${gap.g6};
  padding-bottom: 48px;
  margin: 0;
  text-align: left;
`;

export const Tip = styled.span`
  font-style: italic;
  color: ${colors.dark};
  font-size: ${font.m};
  line-height: ${gap.g6};
  opacity: 1;
  padding-bottom: 0;
  text-align: left;
`;

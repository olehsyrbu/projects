import React from 'react';
import PropTypes from 'prop-types';

import CheckIcon from 'material-ui/svg-icons/action/check-circle';
import Btn from '../RaisedBtn';
import { DialogWrap, Tip, Title, Text, CheckIconStyle } from './style';

export const Dialog = ({
  style, onClick, title, text, btnText, tip, isHideIcon,
}) => (
  <DialogWrap
    style={style}
  >
    {isHideIcon ? null : <CheckIcon style={CheckIconStyle} /> }
    <Title>{title}</Title>
    <Text>{text}
      {tip && <Tip>{tip}</Tip>}
    </Text>
    <Btn
      className="btn-confirm"
      primary
      size={46}
      label={btnText}
      onClick={onClick}
    />
  </DialogWrap>
);

Dialog.propTypes = {
  style: PropTypes.object,
  onClick: PropTypes.func,
  icon: PropTypes.node,
  title: PropTypes.object,
  text: PropTypes.object,
  btnText: PropTypes.object,
  handleBtn: PropTypes.func,
};

export default Dialog;

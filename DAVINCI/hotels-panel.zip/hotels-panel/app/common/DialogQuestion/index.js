import React from 'react';
import PropTypes from 'prop-types';

import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';

class DialogQuestion extends React.PureComponent {
  getAction = () => [
    <FlatButton
      label="Cancel"
      primary
      onClick={this.props.handleClose}
    />,
    <FlatButton
      label="Ok"
      primary
      keyboardFocused
      onClick={this.props.handlerOk}
    />,
  ];
  render() {
    const {
      title, open, handleClose,
    } = this.props;
    return (
      <Dialog
        titleStyle={{ padding: '20px' }}
        title={title}
        actions={this.getAction()}
        modal={false}
        open={open}
        onRequestClose={handleClose}
      />
    );
  }
}

DialogQuestion.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func,
  handlerOk: PropTypes.func,
};

export default DialogQuestion;



import React from 'react';
import iconBed from 'app/media/bed.svg';
import styled from 'styled-components';

export default styled(props => <img {...props} src={iconBed} />)`
  width: 19px;
  height: 19px;
  margin: -2px 0 0 0;
`;

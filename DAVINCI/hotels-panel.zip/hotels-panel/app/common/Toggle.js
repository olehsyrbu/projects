import React from 'react';

import { colors } from 'app/style/variables';

import ToggleEl from 'material-ui/Toggle';

const ToggleStyle = {
  style: {
    display: 'inline-flex',
    width: 'auto',
  },
  trackStyle: {
    height: 14,
    width: 30,
    border: '1px solid rgba(56,86,112, .1)',
    backgroundColor: colors.grayWhiteText,
    boxSizing: 'content-box',
  },
  trackSwitchedStyle: {
    backgroundColor: colors.blueText,
  },
  thumbStyle: {
    top: '5px',
    left: '3px',
    height: 14,
    width: 14,
    backgroundColor: colors.light,
  },

  thumbSwitchedStyle: {
    left: 33,
    backgroundColor: colors.light,
  },
};

class Toggle extends React.PureComponent {
  render() {
    return (
      <ToggleEl
        {...ToggleStyle}
        {...this.props}
      />
    );
  }
}

export default Toggle;

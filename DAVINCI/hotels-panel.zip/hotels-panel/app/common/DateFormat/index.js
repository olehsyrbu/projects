import React, { PureComponent } from 'react'; // eslint-disable-line no-unused-vars
import PropTypes from 'prop-types';
import { dateFormatDMY, dateFormatDMYHMS, dateFormatDM, dateFormatDMYY } from 'app/utils/date';

class DateFormat extends PureComponent {
  static propTypes = {
    date: PropTypes.object,
    isFull: PropTypes.bool,
    isShort: PropTypes.bool,
    isShortYear: PropTypes.bool,
  };

  render() {
    const {
      date, isFull, isShort, isShortYear, ...props
    } = this.props;

    if (isShort) {
      return <span {...props}>{dateFormatDM(date)}</span>;
    }
    if (isShortYear) {
      return <span {...props}>{dateFormatDMYY(date)}</span>;
    }
    if (isFull) {
      return <span {...props}>{dateFormatDMYHMS(date)}</span>;
    }
    return <span {...props}>{dateFormatDMY(date)}</span>;
  }
}

export default DateFormat;

import styled from 'styled-components';
import { colors } from 'app/style/variables';

export const Text = styled.h3`
  font-size: 26px;
  font-weight: 700;
  color: ${colors.dark};
  line-height: 36px;
  text-align: center;
`;

export const WrapImg = styled.div`
  display: flex;
  justify-content: center;
  margin: 24px 0;
`;

export const SubText = styled.p`
  opacity: 0.6;
  font-size: 14px;
  line-height: 24px;
  color: ${colors.dark};
  text-align: center;
  line-height: 24px;
`;

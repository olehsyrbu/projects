import React from 'react';

import emptyDataImg from 'app/media/emptyData.svg';
import { Text, WrapImg, SubText } from './style.js';
import i18n from 'app/utils/i18n';

const EmptyInfo = ({ text }) => (
  <div>
    <WrapImg>
      <img src={emptyDataImg} />
    </WrapImg>
    <Text>
      {i18n('app.components.EmptyPage.titleEmpty', { text })}
    </Text>
    <SubText>
      {i18n('app.components.EmptyPage.subTextEmpty', { text })}
    </SubText>
  </div>
);


export default EmptyInfo;

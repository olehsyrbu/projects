import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

const MoreWrap = styled.button`
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  background-color: ${colors.light};
  border-radius: 1em;
  border: 1px solid currentColor;
  font-size: ${font.m};
  color: ${colors.grayBg};
  cursor: pointer; 
  transition: color 0.5s ease-in-out;
  &:focus {
    outline: none;
  }
  &:hover {
    color: ${colors.blue};
  }
`;

class More extends React.PureComponent {
  render() {
    const { amount, handleMoreClick } = this.props;
    return (
      <MoreWrap onClick={handleMoreClick} >
        + {amount} more
      </MoreWrap>
    );
  }
}

More.propTypes = {
  amount: PropTypes.number.isRequired,
  handleMoreClick: PropTypes.func.isRequired,
};

export default More;

import styled from 'styled-components';
import { colors, font } from 'app/style/variables';

export const HotelWrap = styled.div`
  display: flex;
  align-items: center;
//  margin-left: 20px;
  color: ${props => props.color || colors.light};
  font-size: ${font.ml};
`;
export const HotelName = styled.span`
  padding-left: 10px;
`;

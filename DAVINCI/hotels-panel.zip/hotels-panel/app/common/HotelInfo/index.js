import React from 'react';
import PropTypes from 'prop-types';

import Avatar from 'app/common/Avatar';
import { HotelWrap, HotelName } from './style';

class HotelInfo extends React.PureComponent {
  render() {
    const {
      sizeAvatar, color, hotelLogo, hotelName,
    } = this.props;
    return (
      <HotelWrap color={color}>
        <Avatar src={hotelLogo} size={+sizeAvatar} name={!hotelLogo && hotelName} />
        <HotelName>{hotelName}</HotelName>
      </HotelWrap>
    );
  }
}

HotelInfo.propTypes = {
  hotel: PropTypes.shape({
    name: PropTypes.string,
    media: PropTypes.shape({
      logo: PropTypes.string,
    }),
  }),
};

export default HotelInfo;

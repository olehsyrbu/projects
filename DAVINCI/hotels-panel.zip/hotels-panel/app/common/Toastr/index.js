import React from 'react';
import './style.scss';

function Toastr({
  closeElement, title, message, onClose,
}) {
  return (
    <div className="hotel-toaster ui-toaster-container">
      <div className="ui-toastr-item ui-toastr-item-type-danger">
        {!(title == null) && (<div className="ui-toastr-message">{title}</div>)}
        {!(message == null) && (<div className="ui-toastr-description">{message}</div>)}
        {
          closeElement && (
            <div className="ui-toastr-close-element" onClick={onClose}>{closeElement}</div>
          )
        }
      </div>
    </div>
  );
}

export default Toastr;

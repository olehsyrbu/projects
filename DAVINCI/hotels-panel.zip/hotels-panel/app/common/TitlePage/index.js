import React from 'react';
import styled from 'styled-components';
import HeaderTitle from 'app/common/design/HeaderTitle';

export const WrapTitle = styled.div`
  flex: 1;
`;

export default ({ text, children }) => (
  <HeaderTitle>
    <WrapTitle>
      {text}
    </WrapTitle>
    {children}
  </HeaderTitle>
);

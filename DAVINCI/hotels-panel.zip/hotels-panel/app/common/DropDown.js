import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { colors } from '../style/variables';

import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';

class DropDown extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      value: props.defaultValue,
    };

    this.getStyle = this.getStyle.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event, index, value) {
    const { onChange } = this.props;
    this.setState({ value });
    onChange(value);
  }

  getStyle = isHideBorder => ({
    style: {
      border: isHideBorder ? 'none' : `1px solid ${colors.grayWhiteText}`,
      height: '100%',
    },
    labelStyle: {
      height: '100%',
      paddingLeft: '15px',
      paddingRight: '35px',
      lineHeight: '36px',
    },
    underlineStyle: {
      display: 'none',
    },
    iconStyle: {
      fill: colors.grayBg,
      right: '-6px',
      top: '-2px',
      height: 38,
      width: 38,
      padding: 2,
    },
  });

  render() {
    const {
      list, styleDrop, autoWidth, anchorOrigin, targetOrigin, className, isDisabled,
    } = this.props;
    const newStyle = _.merge({ ...this.getStyle(styleDrop && styleDrop.isHideBorder) }, { ..._.omit(styleDrop, ['isHideBorder']) });

    return (
      <DropDownMenu
        disabled={isDisabled}
        className={className}
        value={this.state.value}
        onChange={this.handleChange}
        {...newStyle}
        autoWidth={autoWidth}
        anchorOrigin={anchorOrigin}
        targetOrigin={targetOrigin}
      >
        {
          list && list.map((item, i) => (
            <MenuItem
              key={i}
              value={item.value}
              primaryText={item.name}
            />
          ))
        }
      </DropDownMenu>
    );
  }
}

DropDown.propTypes = {
  onChange: PropTypes.func,
  defaultValue: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  styleDrop: PropTypes.object,
  list: PropTypes.array,
};

export default DropDown;

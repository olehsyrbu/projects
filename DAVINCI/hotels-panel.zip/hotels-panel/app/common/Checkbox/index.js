import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';

import StarRate from 'material-ui/svg-icons/toggle/star';

const CheckboxWrap = styled.div`
  display: inline-flex;
  justify-content: center;
  margin: 0;
`;
const CheckboxLabel = styled.span`
  text-align: center;
  color: ${colors.grayBg};
`;
const CheckboxInput = styled.span`
  position: relative;
  display: inline-flex;
  border-radius: 3px;
  width: 1.5em;
  height: 1.5em;
  margin: 2px 3px;
  border: 1px solid ${props => (props.checked ? colors.orange : colors.grayWhiteText)};
  background-color: ${props => (props.checked ? colors.orange : colors.light)};
  color: ${colors.light};
  .checkbox-input {
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    margin: 0;
    padding: 0;
    opacity: 0;
  }
`;

const StarRateStyles = {
  width: '100%',
  height: '100%',
};

class Checkbox extends React.PureComponent {
  render() {
    const { checked, label, style } = this.props;
    return (
      <CheckboxWrap style={style}>
        <CheckboxInput checked={!!checked} >
          {
            checked && <StarRate style={StarRateStyles} color={colors.light} />
          }
        </CheckboxInput>
        {
          label && <CheckboxLabel>{label}</CheckboxLabel>
        }
      </CheckboxWrap>
    );
  }
}

Checkbox.propTypes = {
  checked: PropTypes.bool,
  label: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.object,
  ]),
  style: PropTypes.object,
};

export default Checkbox;

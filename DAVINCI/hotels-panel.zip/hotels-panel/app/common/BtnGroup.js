import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';

import RaisedBtn from './RaisedBtn';

const BtnGroupWrap = styled.div`
  display: flex;
  justify-content: flex-end;
  width: 100%;
  & > div {
    margin-left: 18px;
  }
`;

class BtnGroup extends React.PureComponent {
  render() {
    const {
      className, style, size = 46, labelCancel, labelConfirm,
      onClickCancel, onClickConfirm, secondary,
      disableConfirm, disabledCancel,
    } = this.props;

    return (
      <BtnGroupWrap style={style} className={className} >
        <RaisedBtn
          size={size}
          label={labelCancel}
          disabled={disabledCancel}
          onClick={onClickCancel}
        />
        <RaisedBtn
          size={size}
          label={labelConfirm}
          onClick={onClickConfirm}
          primary={!secondary}
          secondary={secondary}
          disabled={disableConfirm}
        />
      </BtnGroupWrap>
    );
  }
}

BtnGroup.propTypes = {
  style: PropTypes.object,
  size: PropTypes.number,
  labelCancel: PropTypes.object,
  labelConfirm: PropTypes.object,
  onClickCancel: PropTypes.func,
  onClickConfirm: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.bool,
  ]),
  secondary: PropTypes.bool,
};

export default BtnGroup;

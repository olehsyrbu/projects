import styled from 'styled-components';
import { colors, font, gap } from '../../style/variables';

export const ErrorsWrap = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 170px 0;
`;

export const Title = styled.h2`
  margin: 10px 0;
  font-size: 26px;
`;
export const Text = styled.p`
  margin: 0 0 36px;
  font-size: 14px;
`;
export const Page = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid currentColor;
  width: 56px;
  height: 56px;
  border-radius: 3px;
  padding-top: 10px;
  font-size: 24px;
  opacity: 0.2;
  &::before {
    content: '';
    right: 2px;
    height: 2px;
    left: 2px;
    top: 3px;
    position: absolute;
    border-left: 2px solid currentColor;
    border-right: 30px solid currentColor;
  }
  &::after {
    content: '';
    width: 100%;
    position: absolute;
    top: 8px;
    left: 0;
    border-top: 2px solid currentColor;
  }
`;

export const DialogWrap = styled.div`
  text-align: center;
`;
export const TitleDialog = styled.h2`
  font-size: ${font.xl};
  margin: ${gap.g4} 0;
  color: ${colors.dark};
  line-height: 36px;
`;
export const TextDialog = styled.p`
  opacity: 0.6;
  color: ${colors.dark};
  font-size: ${font.m};
  line-height: ${gap.g6};
  padding-bottom: 48px;
  margin: 0;
`;

export const Mail = styled.div`
  color: ${colors.blue};
`;
export const RaisedStyles = {
  height: '46px',
  minWidth: '110px',
  boxShadow: 'none',
  overflow: 'hidden',
  whiteSpace: 'nowrap',

};
export const RaisedLabelStyle = {
  padding: '0 1.7em',
  height: '46px',
  lineHeight: '46px',
  fontSize: '14px',
};

export const styleDialog = { width: '520px' };

import React from 'react';
import Dialog from 'material-ui/Dialog';
import RaisedButton from 'material-ui/RaisedButton';

import Loop from 'material-ui/svg-icons/av/loop';
import infoSrc from 'app/media/ic_ done.svg';
import { emailInfo } from 'app/utils/global-constant';
import { DialogWrap, TextDialog, TitleDialog, RaisedLabelStyle, RaisedStyles, Mail, styleDialog } from './style';
import i18n from 'app/utils/i18n';

class DialogError extends React.PureComponent {
  handlerReloadPage = () => {
    window.location.reload();
  };

  render() {
    return (
      <Dialog
        modal
        open
        contentStyle={styleDialog}
      >
        <DialogWrap>
          <img src={infoSrc} />
          <TitleDialog>{i18n('app.components.Error.titleErrorDialog')}</TitleDialog>
          <TextDialog>
            {i18n('app.components.Error.textErrorDialog')}
            <Mail>
              {emailInfo}
            </Mail>
          </TextDialog>

          <RaisedButton
            icon={<Loop />}
            className="btn-confirm"
            primary
            size={46}
            style={RaisedStyles}
            labelStyle={RaisedLabelStyle}
            label={i18n('app.components.Error.reloadPage')}
            onClick={this.handlerReloadPage}
          />
        </DialogWrap>
      </Dialog>
    );
  }
}

export default DialogError;

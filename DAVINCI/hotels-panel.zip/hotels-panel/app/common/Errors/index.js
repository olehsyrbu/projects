import React from 'react';
import PropTypes from 'prop-types';
import RaisedBtn from 'app/common/RaisedBtn';
import { ErrorsWrap, Title, Text, Page } from './style';
import i18n from 'app/utils/i18n';

const Error = ({
  code, title, text, btnText, onClick,
}) => (
  <ErrorsWrap>
    <Page>
      {code}
    </Page>
    <Title>{title || i18n('app.components.Error.title503')}</Title>
    <Text>{text || i18n('app.components.Error.text503')}</Text>
    <RaisedBtn
      className="btn"
      size={32}
      label={btnText || i18n('app.components.Error.btn503')}
      onClick={onClick}
      primary
    />
  </ErrorsWrap>
);

Error.propTypes = {
  code: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  title: PropTypes.object,
  text: PropTypes.object,
  onClick: PropTypes.func,
};

export default Error;

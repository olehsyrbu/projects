import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment/moment';

const style = { paddingLeft: '5px' };
export default class TextField extends React.PureComponent {
  static propTypes = {
    from: PropTypes.string,
    to: PropTypes.string,
  };

  constructor(props) {
    super(props);
    this.state = {
      timerString: this.getTimerString(),
    };
  }

  componentWillMount() {
    this.interval = setInterval(() => {
      this.setState({ timerString: this.getTimerString() });
    }, 1000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
  }

  getTimerString() {
    const { from, to, onEnd } = this.props;

    const dateFrom = from ? moment.utc(from) : moment.utc();
    const dateTo = to ? moment(to).valueOf() : moment.utc().valueOf();
    const offset = dateFrom.parseZone(dateTo).utcOffset() * 60 * 1000;
    const duration = moment.duration(dateTo - offset - dateFrom.valueOf(), 'ms');

    const h = duration.hours() + (duration.days() * 24);
    if (duration.minutes() <= 0 && h <= 0 && duration.seconds() <= 0) {
      clearInterval(this.interval);
      if (typeof onEnd === 'function') {
        onEnd();
      }
    } else {
      return `
        ${h > 0 ? `${h.toString()}:` : ''} 
        ${`0${duration.minutes().toString()}`.substr(-2).toString()}
      : ${`0${duration.seconds().toString()}`.substr(-2).toString()}`;
    }
  }

  removeProps(propsToRemove) {
    const props = { ...this.props };
    propsToRemove.map((prop) => {
      if (props[prop]) {
        delete props[prop];
      }
    });
    return props;
  }

  render() {
    const props = this.removeProps(['from', 'to', 'onEnd']);
    const { timerString = '' } = this.state;
    return <span style={style} {...props}>{timerString}</span>;
  }
}

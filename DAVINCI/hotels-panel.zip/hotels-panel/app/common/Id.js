import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors, font, fontWeight } from 'app/style/variables';

const IdWrap = styled.div`
  display: inline;
  width: 100px;
  min-width: 64px;
  background-color: ${colors.grayLight};
  border-radius: 2px 2px 0 0;
  padding: 5px 11px;
  text-align: center;
  line-height: 24px;
  color: ${colors.light};
  font-size: ${font.m};
  font-weight: ${fontWeight.lighter};
`;

class Id extends React.PureComponent {
  render() {
    const { id, style } = this.props;
    return (
      <IdWrap style={style} >
        #{id}
      </IdWrap>
    );
  }
}

Id.propTypes = {
  id: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]).isRequired,
  style: PropTypes.object,
};

export default Id;

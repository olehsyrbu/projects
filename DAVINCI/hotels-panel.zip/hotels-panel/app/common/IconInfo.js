import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import HelpOutline from 'app/media/Hint_16px_fill.svg';
import { Tooltip } from 'app/ui';
import { isEqual } from 'lodash';
import i18n from 'app/utils/i18n';

const IconInfoWrap = styled.div`
  position: relative;
  display: inline-flex;
  user-select: none;
  cursor: pointer;
  align-items: center;
  white-space: pre;
  overflow: visible;
  &:hover {
    .date-notify {
      opacity: 1;
    }
  }
`;

export class IconInfo extends React.Component {
  shouldComponentUpdate(nextProps) {
    return !isEqual(nextProps.children, this.props.children);
  }

  render() {
    const {
      id, children, className, place,
    } = this.props;
    return (
      <IconInfoWrap data-tip data-for={id} className={className} >
        {
          children ||
          <Tooltip className="ui-tooltip-hotel" place={place} tooltip={i18n(`${id}`)}>
            <img
              src={HelpOutline}
              style={{ paddingLeft: '4px', opacity: '0.6' }}
              alt="image"
            />
          </Tooltip>
        }
      </IconInfoWrap>
    );
  }
}

IconInfo.propTypes = {
  text: PropTypes.object,
};

export default IconInfo;

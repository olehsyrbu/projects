import React from 'react';
import PropTypes from 'prop-types';

import { colors } from 'app/style/variables';
import RaisedButton from 'material-ui/RaisedButton';

class RaisedBtn extends React.PureComponent {
  constructor(props) {
    super(props);

    this.RaisedStyles = this.RaisedStyles.bind(this);
    this.RaisedlabelStyles = this.RaisedlabelStyles.bind(this);
  }

  RaisedStyles() {
    const { size = 36, primary, styleData } = this.props;
    const sizePx = `${size.toString()}px`;

    return {
      height: sizePx,
      minWidth: '110px',
      boxShadow: 'none',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      border: `${primary ? 'none' : `1px solid ${colors.grayWhiteText}`}`,
      ...styleData,
    };
  }

  RaisedlabelStyles(styleData) {
    const size = `${this.props.size.toString()}px` || '36px';
    return {
      padding: '0 1.7em',
      height: size,
      lineHeight: size,
      fontSize: '15px',
      display: 'flex',
      justifyContent: 'center',
      ...styleData,
    };
  }

  render() {
    const { size, styleData, ...props } = this.props;
    const RaisedStyles = size && this.RaisedStyles();
    const RaisedlabelStyle = size && this.RaisedlabelStyles(styleData);

    return (
      <RaisedButton
        style={RaisedStyles}
        labelStyle={RaisedlabelStyle}
        {...props}
      />
    );
  }
}
RaisedBtn.propTypes = {
  primary: PropTypes.bool,
  size: PropTypes.number,
  styleData: PropTypes.object,
};

export default RaisedBtn;

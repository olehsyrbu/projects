import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { font, colors } from 'app/style/variables';
import LocationIcon from 'material-ui/svg-icons/communication/location-on';

const LocationWrap = styled.div`
  display: inline-flex;
  justify-content: space-between;
  align-items: center;
  font-size: ${font.m};
  color: inherit;
`;

const LocationStyle = {
  color: 'inherit',
  fill: `${colors.grayBg}`,
  marginRight: '10px',
  width: '20px',
  height: '20px',
};

class Location extends React.PureComponent {
  render() {
    const { city, radius, hasIcon } = this.props;
    const rad = radius ? `${radius.toString()} km` : null;

    return (
      <LocationWrap>
        {hasIcon && <LocationIcon style={LocationStyle} />} {city} {rad}
      </LocationWrap>
    );
  }
}
Location.defaultProps = {
  hasIcon: true,
};

Location.propTypes = {
  radius: PropTypes.number,
  hasIcon: PropTypes.bool,
};

export default Location;

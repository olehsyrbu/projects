export const countries = ['GB', 'CZ', 'PL', 'DE', 'FR'];
export const defaultCountry = 'GB';

import React from 'react';
import ReactFlagsSelect from 'react-flags-select';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import 'react-flags-select/css/react-flags-select.css';
import { countries, defaultCountry } from './constants';
import './style.scss';

const LocalizationWrapper = styled.div`
  display: flex;
  align-items: center;
`;

const LocalizationSwitcher = ({ size, onChangeLanguage }) => (
  <LocalizationWrapper>
    <ReactFlagsSelect
      className="menu-flags"
      selectedSize={size}
      defaultCountry={localStorage.getItem('selectedNewFlag') || defaultCountry}
      countries={countries}
      onSelect={onChangeLanguage}
      showSelectedLabel={false}
      showOptionLabel={false}
    />
  </LocalizationWrapper>
);

LocalizationSwitcher.propTypes = {
  size: PropTypes.number,
  onChangeLanguage: PropTypes.func,
};

export default LocalizationSwitcher;

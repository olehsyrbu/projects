import React from 'react';
import DatePicker from 'material-ui/DatePicker';
import Wrapper from './Wrapper';
import { dateFormatDateDMYDots } from 'app/utils/date';

const textFieldStyle = {
  height: 36,
  width: 182,
  fontSize: 14,
};

class Datapicker extends React.PureComponent {
  render() {
    const { style, locale } = this.props;
    return (
      <Wrapper style={style} >
        <DatePicker
          DateTimeFormat={Intl.DateTimeFormat}
          locale={locale}
          formatDate={date => dateFormatDateDMYDots(date)}
          textFieldStyle={textFieldStyle}
          {...this.props}
        />
      </Wrapper>
    );
  }
}

export default Datapicker;

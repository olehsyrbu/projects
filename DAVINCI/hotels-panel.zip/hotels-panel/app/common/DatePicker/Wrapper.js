import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors, gap } from 'app/style/variables';

import Calendar from 'material-ui/svg-icons/action/today';

const DatespickerWrap = styled.div`
  position: relative;
  display: inline-flex;
  align-items: center;
  border: 2px solid ${colors.grayWhiteText};
  height: ${gap.g9};
  box-sizing: border-box;
  padding: 0 0 0 ${gap.g3};
  margin: 0 ${gap.g3};
  hr {
    display: none;
  }
  ${props => props.style}
`;

const calendarStyles = {
  position: 'absolute',
  top: 0,
  pointerEvents: 'none',
  right: 0,
  height: gap.g8,
  width: gap.g10,
  padding: gap.g1,
  color: colors.grayBg,
  marginLeft: 'auto',
  borderLeft: `2px solid ${colors.grayWhiteText}`,
};


class Datespicker extends React.PureComponent {
  render() {
    const { children, style } = this.props;
    return (
      <DatespickerWrap style={style} >
        {children}
        <Calendar style={calendarStyles} />
      </DatespickerWrap>
    );
  }
}

Datespicker.propTypes = {
  children: PropTypes.node,
};

export default Datespicker;

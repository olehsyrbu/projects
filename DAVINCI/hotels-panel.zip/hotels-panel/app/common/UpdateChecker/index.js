import React, { PureComponent } from 'react';
import Dialog from 'app/ui/Dialog';
import BtnGroup from 'app/common/BtnGroup';
import { defineMessages, FormattedMessage } from 'react-intl';
import * as Sentry from '@sentry/browser';

const messages = defineMessages({
  system_message: {
    id: 'app.common.system_message',
    defaultMessage: 'System message',
  },
  later: {
    id: 'app.update_checker.later',
    defaultMessage: 'Remind me later',
  },
  refresh: {
    id: 'app.update_checker.refresh',
    defaultMessage: 'Refresh',
  },
  messageText: {
    id: 'app.update_checker.message',
    defaultMessage: 'The application has been updated. Please refresh the page.',
  },
});

const msg = {
  system_message: <FormattedMessage {...messages.system_message} />,
  later: <FormattedMessage {...messages.later} />,
  refresh: <FormattedMessage {...messages.refresh} />,
  messageText: <FormattedMessage {...messages.messageText} />,
};

let lastModified = null;
const options = { method: 'HEAD' };
const DEFAULT_TIMEOUT = 5 * 60 * 1000;
const LATER_TIMEOUT = 10 * 60 * 1000;

class UpdateChecker extends PureComponent {
  constructor(props) {
    super(props);
    this.state = { showModal: false };
    this.setNewTimeout(lastModified ? DEFAULT_TIMEOUT : 0);
  }

  componentWillUnmount() {
    clearTimeout(this.timeoutId);
  }

  setNewTimeout(seconds) {
    this.timeoutId = setTimeout(this.checkLastModified, seconds);
  }

  checkLastModified = async () => {
    try {
      const { headers } = await window.fetch('/', options);
      const header = headers.get('Last-Modified') || true;
      if (!lastModified) {
        lastModified = header;
      }
      if (lastModified === header) {
        return this.setNewTimeout(DEFAULT_TIMEOUT);
      }
      this.setState({ showModal: true });
    } catch (error) {
      Sentry.captureException(error);
    }
  };

  onConfirm = () => {
    window.location.reload();
  };

  onRefuse = () => {
    this.setState({ showModal: false });
    this.setNewTimeout(LATER_TIMEOUT);
  };

  render() {
    const { showModal } = this.state;
    return showModal && (
      <Dialog
        contentStyle={{ padding: '20px' }}
        bodyStyle={{ padding: '20px' }}
        open={showModal}
        onClose={this.onRefuse}
        title={msg.system_message}
        actions={[
          <BtnGroup
            size={46}
            className="hotel-conditions-btns"
            onClickCancel={this.onRefuse}
            onClickConfirm={this.onConfirm}
            labelCancel={msg.later}
            labelConfirm={msg.refresh}
          />,
        ]}
      >
        <div>
          {msg.messageText}
        </div>
      </Dialog>
    );
  }
}

export default UpdateChecker;

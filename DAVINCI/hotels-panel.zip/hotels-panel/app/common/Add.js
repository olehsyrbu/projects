import React from 'react';
import PropTypes from 'prop-types';

import styled from 'styled-components';
import { colors } from 'app/style/variables';

import AddBox from 'material-ui/svg-icons/content/add-box';

const AddWrap = styled.div`
  display: inline-flex;
  align-items: center;
  text-transform: uppercase;
  color: ${colors.grayText06};
  font-size: 11px;
  font-weight: 500;
  user-select: none;
  cursor: ${props => (props.disable ? 'all' : 'pointer')};
  opacity: ${props => (props.disable ? '0.3' : '1')};
  &:hover {
    svg {
      color: ${props => (props.disable ? 'inherit' : `${colors.blue} !important`)} ;
    }
  }
`;

const AddBoxStyle = {
  color: colors.blue,
  fill: 'currentColor',
  marginRight: '7px',
  width: '2em',
  height: '2em',
};

class Add extends React.PureComponent {
  render() {
    const {
      className, text, handleAddClick, disable,
    } = this.props;
    return (
      <AddWrap className={className} disable={disable} onClick={!disable && handleAddClick} >
        <AddBox style={AddBoxStyle} />
        {text && text}
      </AddWrap>
    );
  }
}

Add.propTypes = {
  className: PropTypes.string,
  text: PropTypes.object,
  handleAddClick: PropTypes.func,
  disable: PropTypes.bool,
};

export default Add;

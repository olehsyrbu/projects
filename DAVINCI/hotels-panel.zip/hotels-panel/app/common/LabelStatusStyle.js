
import styled from 'styled-components';

export default styled.div`
  border-radius: 12px;
  text-transform: unset;
  font-size: 16px;
  font-weight: 400;
  line-height: 24px;
  white-space: nowrap;
  width: 1000%;
  overflow: hidden;
  text-overflow: ellipsis;
  display: flex;
  align-items: center; 
`;

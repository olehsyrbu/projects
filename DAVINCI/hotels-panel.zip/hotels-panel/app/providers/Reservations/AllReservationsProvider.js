import React from 'react';
import { Query } from 'react-apollo';
import ReservationsQuery from 'app/graph/queries/reservations';

export default function AllReservationsProvider({ render }) {
  return (
    <Query query={ReservationsQuery}>
      {({ data, loading, error }) => render({ data, loading, error })}
    </Query>
  );
}

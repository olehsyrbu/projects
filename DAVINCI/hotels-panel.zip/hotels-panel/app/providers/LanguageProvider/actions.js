/*
 *
 * LanguageProvider actions
 *
 */

import { CHANGE_LOCALE } from './constants';

const getLang = (language) => {
  switch (language) {
    case 'GB':
      return 'en';
    case 'PL':
      return 'pl';
    case 'DE':
      return 'de';
    case 'CZ':
      return 'cs';
    case 'FR':
      return 'fr';
    default:
      return 'en';
  }
};

export function changeLocale(languageLocale) {
  const language = getLang(languageLocale);
  localStorage.setItem('selectedNewLanguage', language);
  return {
    type: CHANGE_LOCALE,
    locale: language,
  };
}

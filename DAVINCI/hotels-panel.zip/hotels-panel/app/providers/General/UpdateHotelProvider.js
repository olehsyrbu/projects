import React from 'react';
import { Mutation } from 'react-apollo';
import * as Sentry from '@sentry/browser';

import HotelMutation from 'app/graph/mutations/updateHotel';
import SessionQuery from 'app/graph/queries/session';
import HotelQuery from 'app/graph/queries/hotel';

const getDataForMutation = ({ hotel, sessionId }) => {
  const mutationProps = {
    variables: { hotel },
    update: (store, { data: { newHotel } }) => {
      const data = store.readQuery({ query: HotelQuery });
      data.hotel = { ...data.hotel, ...newHotel };
      store.writeQuery({ query: HotelQuery, data });
    },
  };

  if (!sessionId) return mutationProps;

  return {
    ...mutationProps,
    refetchQueries: [{
      query: SessionQuery,
      variables: { sessionId },
    }],
  };
};

const updateHotelProvider = mutation => data => mutation(getDataForMutation(data)).catch(e => Sentry.captureException(e));

export default function UpdateHotelProvider({ render }) {
  return (
    <Mutation mutation={HotelMutation} >
      {updateHotel => render(updateHotelProvider(updateHotel))}
    </Mutation>
  );
}

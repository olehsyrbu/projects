import React from 'react';
import { Query } from 'react-apollo';
import RoomsQuery from 'app/graph/queries/rooms';
import Loading from 'app/common/Loading';
import DialogNotification from 'app/common/DialogNotification';

export default function RoomsProvider({ render }) {
  return (
    <Query query={RoomsQuery}>
      {({ data: { roomTypes } = {}, loading, error }) => {
        if (loading) return <Loading />;
        if (error) throw new Error(error);
        if (!roomTypes) return <DialogNotification isOpen action="failed" />;
        return render(roomTypes);
      }}
    </Query>
  );
}

import React from 'react';
import { Query } from 'react-apollo';
import SentOffersQuery from 'app/graph/queries/sentOffers';

export default function SentOffersProvider({ render }) {
  return (
    <Query query={SentOffersQuery} fetchPolicy="network-only">
      {({
          data, loading, error,
        }) => {
        if (error) throw new Error(error);
        return render({ data, loading, error });
      }}
    </Query>
  );
}

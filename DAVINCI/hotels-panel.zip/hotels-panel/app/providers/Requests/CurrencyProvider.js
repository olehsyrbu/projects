import React from 'react';
import { Query } from 'react-apollo/index';
import CurrencyQuery from 'app/graph/queries/currency';

import Loading from 'app/common/Loading';
import DialogNotification from 'app/common/DialogNotification';
import { defValueCurrency } from 'app/utils/global-constant';

export default function CurrencyProvider({ render }) {
  return (
    <Query query={CurrencyQuery}>
      {({ data: { currencies } = {}, loading, error }) => {
        if (loading) return <Loading />;
        if (!currencies) return <DialogNotification isOpen action="failed" />;
        if (error) throw new Error(error);

        const currencyData = error ? [defValueCurrency] : currencies;
        return render(currencyData);
      }}
    </Query>
  );
}

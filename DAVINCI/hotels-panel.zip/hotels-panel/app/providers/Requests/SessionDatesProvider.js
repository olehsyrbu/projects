import React from 'react';
import SessionQuery from 'app/graph/queries/session';
import { Query } from 'react-apollo';
import Loading from 'app/common/Loading';
import DialogNotification from 'app/common/DialogNotification';

export default function SessionDatesProvider({ sessionId, render }) {
  return (
    <Query query={SessionQuery} variables={{ sessionId }}>
      {({ data, loading, error }) => {
        if (loading) return (<Loading />);
        if (error) throw new Error(error);
        if (!error && data && !data.session) return <DialogNotification isOpen action="removed" />;

        const {
          session: {
            checkIn, checkOut,
          } = {},
        } = data;
        return render({ checkIn, checkOut });
      }}
    </Query>
  );
}

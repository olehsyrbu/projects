import React from 'react';
import { Query } from 'react-apollo';
import NewRequestsQuery from 'app/graph/queries/newRequests';

export default function NewRequestsProvider({ render }) {
  return (
    <Query query={NewRequestsQuery} fetchPolicy="network-only">
      {({
        data, loading, error, subscribeToMore,
      }) => {
        if (error) throw new Error(error);
        return render({
          newRequests: data && data.newRequests ? data.newRequests : [], subscribeToMore, loading, error,
        });
      }}
    </Query>
  );
}

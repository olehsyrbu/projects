import React from 'react';
import { Query } from 'react-apollo';
import HotelQuery from 'app/graph/queries/hotel';
import Loading from 'app/common/Loading';

export default function HotelProvider({ render }) {
  return (
    <Query query={HotelQuery} fetchPolicy="network-only">
      {({ data: { hotel } = {}, loading, error }) => {
        if (error) throw new Error(error);
        if (loading) return <Loading />;
        return render(hotel);
      }}
    </Query>
  );
}

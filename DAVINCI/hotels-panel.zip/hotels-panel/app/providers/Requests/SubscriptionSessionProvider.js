import React from 'react';
import { Subscription } from 'react-apollo';

import SessionsListSubscription from 'app/graph/subscriptions/sessionsList';
import { isEmpty, isArray } from 'lodash';
import { actionsListSubscriptions } from 'app/utils/global-constant';

const { NO_AVAILIBILITY, MAKE_OFFER } = actionsListSubscriptions;

export default function SubscriptionSessionProvider({ sessionId, render }) {
  return (
    <Subscription subscription={SessionsListSubscription} >
      {({ data: dataSessionListUpdate }) => {
        let dialogAction;

        if (dataSessionListUpdate && isArray(dataSessionListUpdate.sessionListUpdate)) {
          const { action, session } = dataSessionListUpdate.sessionListUpdate.find(item => item.id === sessionId) || {};

          if (!isEmpty(action)) {
            if (MAKE_OFFER === action) { dialogAction = 'success'; }
            if (NO_AVAILIBILITY === action) { dialogAction = 'removed'; }
          }
          if (dialogAction) return render({ dialogAction });
          if (session) return render({ session });
        }
        return render();
      }}
    </Subscription>
  );
}

// import { Value } from 'react-powerplug/types';
// // example if we need something from REST API
//
// export default function InfoRequestProvider() {
//   // call rest api function and set data in component
//   return (<Value initial="bob" />);
// }

import React from 'react';
import { Query } from 'react-apollo/index';
import Loading from 'app/common/Loading';
import { getBudgetByRequest } from 'app/utils/sessions';
import DialogNotification from 'app/common/DialogNotification';
import { sign } from 'app/utils/global-constant';
import InfoRequestQuery from 'app/graph/queries/infoRequest';
import i18n from 'app/utils/i18n';

export default function InfoRequestProvider({ sessionId, render }) {
  return (
    <Query query={InfoRequestQuery} variables={{ sessionId }}>
      {({ data, loading, error }) => {
        if (loading) return <Loading />;
        if (error) throw new Error(error);
        if (!error && data && !data.session) return <DialogNotification isOpen action="removed" />;

        const {
          session: {
            requestData,
            sessionRequestComment,
          } = {},
        } = data;
        const {
           cityTax, stars = [], budgetMin, budgetMax,
          } = requestData;
        const budgetValue = getBudgetByRequest(budgetMin, budgetMax);

        return render({
          stars,
          budgetValue,
          sessionRequestComment,
          cityTax: cityTax !== 'notInclude' ? i18n('app.components.HotelCondition.Info.cityTaxIncluded') : i18n('app.components.HotelCondition.Info.cityTaxNotInclude'),
          budgetSignText: budgetValue ? sign : i18n('app.components.HotelCondition.Info.budgetTextNoValue'),
        });
      }}
    </Query>
  );
}

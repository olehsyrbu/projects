import React from 'react';
import { Query } from 'react-apollo';
import { dateFormatDMYDots } from 'app/utils/date';
import { globalGroupTypes, mealDefaultFullText } from 'app/utils/global-constant';
import AdditionalInfoQuery from 'app/graph/queries/additionalInfo';
import Loading from 'app/common/Loading';
import i18n from 'app/utils/i18n';

export default function AdditionProvider({ sessionId, render }) {
  return (
    <Query query={AdditionalInfoQuery} variables={{ sessionId }}>
      {({ data, loading, error }) => {
        if (loading) return (<Loading />);
        if (error) throw new Error(error);
        const { session = {} } = data || {};

        if (session) {
          const {
            num, checkIn, checkOut, radius, rooms, requestData,
          } = session;

          if (requestData) {
          const {
            geo: { cityName } = {},
            groupType: requestDataGroupType = '', meal = '',
          } = requestData;
          const mealValue = meal ? i18n(`app.meal.${meal}`) : mealDefaultFullText;
          const { val: groupTypeValue } = globalGroupTypes.find(group => group.key === requestDataGroupType) || {};

          return render({
            loading,
            error,
            num,
            meal: mealValue,
            radius,
            rooms,
            cityName,
            periodDates: `${dateFormatDMYDots(checkIn)} - ${dateFormatDMYDots(checkOut)}`,
            groupTypeValue,
          });
        }
      }

      return render({ loading, error });
    }}
    </Query>
  );
}

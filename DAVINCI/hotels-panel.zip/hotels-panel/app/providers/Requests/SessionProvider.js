import React from 'react';
import { Query } from 'react-apollo';
import SessionQuery from 'app/graph/queries/session';
import DialogNotification from 'app/common/DialogNotification';
import Loading from 'app/common/Loading';

export default function SessionProvider({ sessionId, render }) {
  return (
    <Query query={SessionQuery} variables={{ sessionId }}>
      {({ data, loading, error }) => {
        if (loading) return <Loading />;
        if (error) throw new Error(error);
        if (!error && data && !data.session) return <DialogNotification action="removed" />;

        return render({ session: data && data.session ? data.session : [] });
      }}
    </Query>
  );
}

// example, if need to make Rest
// const fakeDataFromAPI = new Promise((resolve) => {
//   setTimeout(() => {
//     resolve({ data: 'some value' });
//   }, 1000);
// });
//
// export default class SessionProvider extends React.PureComponent {
//   render() {
//     const { render } = this.props;
//     fakeDataFromAPI.then(d => {
//       return render(d);
//     });
//     return null;
//   }
// }

import React from 'react';
import { Query } from 'react-apollo';
import Loading from 'app/common/Loading';
import ConflictOfferQuery from 'app/graph/queries/conflictOffer';

export default function ConflictOfferProvider({ sessionId, render }) {
  return (
    <Query fetchPolicy="network-only" query={ConflictOfferQuery} variables={{ sessionId }}>
      {({ data, loading, error }) => {
        if (error) throw new Error(error);
        if (loading) return (<Loading />);
        return render({ data });
      }}
    </Query>
  );
}

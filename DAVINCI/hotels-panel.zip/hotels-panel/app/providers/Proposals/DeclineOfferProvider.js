import React from 'react';
import { Mutation } from 'react-apollo';
import SentryGraph from 'app/utils/sentryGraphUtil';
import SessionDecline from 'app/graph/mutations/sessionDecline';
import NewRequestsQuery from 'app/graph/queries/newRequests';

const declineRequestProvider = mutation => data =>
  mutation({
    variables: { ...data },
    update: (store, { data: { declineRequest } }) => {
      const data = store.readQuery({ query: NewRequestsQuery });
      data.newRequests = data.newRequests.filter(c => c._id !== declineRequest._id);
      store.writeQuery({ query: NewRequestsQuery, data });
    },
  }).catch(e => SentryGraph(e));

export default function DeclineOfferProvider({ render }) {
  return (
    <Mutation mutation={SessionDecline}>
      {declineRequest => render(declineRequestProvider(declineRequest))}
    </Mutation>
  );
}

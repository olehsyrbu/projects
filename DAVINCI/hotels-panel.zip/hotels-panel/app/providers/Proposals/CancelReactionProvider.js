import React from 'react';
import { Mutation } from 'react-apollo';
import SessionCancelReason from 'app/graph/mutations/sessionCancelReason';
import SentryGraph from 'app/utils/sentryGraphUtil';

const cancelReactionProvider = mutation => data => mutation({ variables: { ...data } }).catch(e => SentryGraph(e));

export default function CancelReactionProvider({ render }) {
  return (
    <Mutation mutation={SessionCancelReason}>
      {cancelReaction => render(cancelReactionProvider(cancelReaction))}
    </Mutation>
  );
}

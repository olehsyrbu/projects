import React from 'react';
import { Mutation } from 'react-apollo';
import SentryGraph from 'app/utils/sentryGraphUtil';
import SessionHotelProposalsUpdatedMutation from 'app/graph/mutations/sessionHotelProposalsUpdated';

const makeOfferProvider = mutation => data =>
  mutation({ variables: { ...data } })
    .catch(e => SentryGraph(e));

export default function MakeOfferProvider({ render }) {
  return (
    <Mutation mutation={SessionHotelProposalsUpdatedMutation} >
      {makeOffer => render(makeOfferProvider(makeOffer))}
    </Mutation>
  );
}

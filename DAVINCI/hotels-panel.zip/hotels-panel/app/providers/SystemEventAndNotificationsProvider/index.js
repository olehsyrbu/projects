import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { Query } from 'react-apollo';
import EventSubscription from 'app/graph/subscriptions/eventSubscription';
import EventQuery from 'app/graph/queries/event';

import handleEvent from './eventHandler';
import FlexRow from 'app/common/design/FlexRow';

class SystemEventAndNotificationsProvider extends PureComponent {
  static propTypes = {
    children: PropTypes.node,
    subscribeToEvent: PropTypes.func,
  };
  constructor(props, context) {
    super(props, context);
    this.componentCleanup = this.componentCleanup.bind(this);
  }

  componentDidMount() {
    this.unsub = this.props.subscribeToEvent();
    window.addEventListener('beforeunload', this.componentCleanup);
  }

  componentCleanup() {
    this.unsub && this.unsub();
  }

  componentWillUnmount() {
    this.unsub && this.unsub();
    window.removeEventListener('beforeunload', this.componentCleanup);
  }

  render() {
    return (
      <FlexRow>
        {React.Children.only(this.props.children)}
      </FlexRow>
    );
  }
}

const subscribeToEvent = subscribeToMore => () => subscribeToMore({
  document: EventSubscription,
  updateQuery: (prev, { subscriptionData }) => {
    handleEvent(subscriptionData.data.SystemEvent);
    return prev;
  },
});

export default props => (
  <Query query={EventQuery} fetchPolicy="network-only">
    {({ subscribeToMore }) => (
      <SystemEventAndNotificationsProvider
        {...props}
        subscribeToEvent={subscribeToEvent(subscribeToMore)}
      />
    )}
  </Query>
);

import apolloClient from 'app/apollo';
import NewRequestsQuery from 'app/graph/queries/newRequests';
import SentOffersQuery from './queries/sentOffers';
import { actionsListSubscriptions } from 'app/utils/global-constant';
import _ from 'lodash';

const updateSentOffers = (newData, action) => {
  if (apolloClient.cache.data.data.ROOT_QUERY.sentOffers) {
    const SentOffers = apolloClient.readQuery({ query: SentOffersQuery });
    const sentOffers = _.clone(SentOffers.sentOffers);

    switch (action) {
      case actionsListSubscriptions.CANCEL_REACTION:
        sentOffers.splice(_.findIndex(sentOffers, offer => offer._id === newData.id), 1);
        apolloClient.writeQuery({ query: SentOffersQuery, data: { sentOffers: [...sentOffers] } });
        return sentOffers;
      default:
        sentOffers.push(newData.session);
        apolloClient.writeQuery({ query: SentOffersQuery, data: { sentOffers: [...sentOffers] } });
        return sentOffers;
    }
  }
};

export const updateSessionsQuery = (subscriptionData) => {
  if (!subscriptionData) { return subscriptionData; }
  const newData = subscriptionData.sessionListUpdate[0];
  const requests = apolloClient.readQuery({ query: NewRequestsQuery }).newRequests;

  switch (newData.action) {
    case actionsListSubscriptions.CANCEL_REACTION:
      // remove session in SentOffers and add to NewRequests
      updateSentOffers(newData, actionsListSubscriptions.CANCEL_REACTION);
      requests.push(newData.session);

      apolloClient.writeQuery({ query: NewRequestsQuery, data: { newRequests: [...requests] } });

      return Object.assign({}, {
        newRequests: [...requests],
      });

    case actionsListSubscriptions.NO_AVAILABILITY:
      // remove request
      requests.splice(_.findIndex(requests, el => el._id === newData.id), 1);
      apolloClient.writeQuery({ query: NewRequestsQuery, data: { newRequests: [...requests] } });
      updateSentOffers(newData, actionsListSubscriptions.NO_AVAILABILITY);

      return Object.assign({}, {
        newRequests: [...requests],
      });

    case actionsListSubscriptions.MAKE_OFFER:
      requests.splice(_.findIndex(requests, el => el._id === newData.id), 1);
      apolloClient.writeQuery({ query: NewRequestsQuery, data: { newRequests: [...requests] } });
      updateSentOffers(newData, actionsListSubscriptions.MAKE_OFFER);

      return Object.assign({}, {
        newRequests: [...requests],
      });

    default:
      return {
        newRequests: [...requests],
      };
  }
};


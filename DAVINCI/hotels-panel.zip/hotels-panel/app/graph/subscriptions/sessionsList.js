import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  subscription {
    sessionListUpdate{
      id
      action
      session{
        ...RequestFragment
      }
    }
  }
  ${session}
`;

import SessionsListSubscription from './subscriptions/sessionsList';
import { updateSessionsQuery } from './updateSessionsQuery';

export const subscribeNewRequests = subscribeToMore => () => subscribeToMore({
  document: SessionsListSubscription,
  updateQuery: (prev, { subscriptionData }) => {
    const Sessions = updateSessionsQuery(subscriptionData.data);
    return Object.assign({}, prev, {
      newRequests: Sessions.newRequests,
    });
  },
});

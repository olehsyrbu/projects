import gql from 'graphql-tag';

export default gql`
  fragment AdditionalInfoFragment on Session {
    num,
    checkIn,
    checkOut,
    radius,
    rooms{
      room{
        name
        abbr
        _id
      }
      amount
    }
    requestData{
      groupType
      meal
      geo {
        cityName
      }
    }
  }
`;

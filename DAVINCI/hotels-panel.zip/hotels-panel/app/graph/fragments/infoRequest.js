import gql from 'graphql-tag';

export default gql`
  fragment InfoRequestFragment on Session {
    requestData{
      cityTax,
      stars{
        star
        value
      }
      budgetMin,
      budgetMax
    },
    sessionRequestComment
  }
`;

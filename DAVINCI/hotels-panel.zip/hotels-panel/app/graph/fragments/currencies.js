import gql from 'graphql-tag';

export default gql`
  fragment currenciesFragment on Currency {
    name
    abbr
    sign
    rate
    date
  }
`;

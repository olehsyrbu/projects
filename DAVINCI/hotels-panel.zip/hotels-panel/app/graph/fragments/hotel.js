import gql from 'graphql-tag';

export default gql`
  fragment hotelFragment on Hotel {
    _id
    paymentPolicy
    partialCancellationComment
    proposals{
      rooms {
        localPrice {
          currency {
            abbr
            rateToEUR
          }
          value
        }
        room
        price
      }
      from
      to
      weekdays
    }
    isHotelEditable
    geo {
      address
      cityName
      countryCode
    }
    currencyAbbr
    phone
    emailDeliveryDelay
    email
    name
    budget {
      personPerNight {
        min
        max
      }
    }
    cancellationPolicy {
      free
      periods {
        from
        to
        percent
      }
    }
    media{
      logo
    }
    cityTax
    meal
    foc
    confirmedConditions
    lastOffer{
      singleLocalCost
      twinLocalCost
      doubleLocalCost
      tripleLocalCost
      quadLocalCost
    }
    currencyAbbr
    groupMembers {
      name
      token
      _id
      media {
        logo
      }
    }
  }
`;

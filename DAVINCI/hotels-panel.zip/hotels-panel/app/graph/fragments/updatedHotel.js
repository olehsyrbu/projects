import gql from 'graphql-tag';

export default gql`
  fragment updatedHotelFragment on Hotel {
    email
    name
    foc
    cityTax
    meal
    budget {
      personPerNight {
        min
        max
      }
    }
    confirmedConditions
    cancellationPolicy{
      free
      periods{
        from
        to
        percent
      }
    }
  }
`;

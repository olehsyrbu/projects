import gql from 'graphql-tag';

export default gql`
  fragment SessionSentOffersFragment on Session {
    _id
    status4Hotel
    status
    cityTax
    optionalProlongRequestStatus
    dueDays
    createdAt
    checkIn
    checkOut
    num
    budget
    sessionRequestComment
    requestData{
      meal
      budgetMin
      budgetMax
      cityTax
      stars{
        star
        value
      }
    }
    rooms{
      room{
        name
        abbr
        _id
      }
      amount
    }
    hotelProposal{
        cancellationPolicy {
          free
          periods {
            from
            to
            percent
          }
        }
        rooms{
          prices{
            primeCost
            localPrice{
              value
              currency{
                abbr
                rateToEUR
              }
            }
          }
          room{
            abbr
            name
            order
          }
          amount
        }
      }
    hotelsProposals {
      createdAt
      declinedMsg
      cityTax
      dueDays
      upTo
      meal
      foc
      proposals {
        rooms{
          prices{
            primeCost
            localPrice{
              value
              currency{
                abbr
                rateToEUR
              }
            }
          }
          room{
            abbr
            name
            order
          }
          amount
        }
        cancellationPolicy {
          free
          periods {
            from
            to
            percent
          }
        }
      }
    }
    hotelsDeclined{
      createdAt
      id
      reason
    }
  }
`;

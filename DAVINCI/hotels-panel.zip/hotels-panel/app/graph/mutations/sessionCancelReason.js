import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  mutation cancelReaction($sessionId: String!) {
    cancelReaction(sessionId: $sessionId){
      _id
      ...RequestFragment
    }
  }
  ${session}
`;

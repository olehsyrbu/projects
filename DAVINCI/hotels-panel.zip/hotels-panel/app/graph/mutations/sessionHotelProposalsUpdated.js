import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  mutation makeOffer($session: SessionUpdateHotelProposalsInput) {
    makeOffer(session: $session){
      _id,
      ...RequestFragment
    }
  }
  ${session}
`;

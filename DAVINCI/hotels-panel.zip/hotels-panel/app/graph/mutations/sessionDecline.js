import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  mutation declineRequest($sessionId: String!, $decision: String!) {
    declineRequest(sessionId: $sessionId, decision: $decision,){
      _id
      ...RequestFragment
    }
  }
  ${session}
`;

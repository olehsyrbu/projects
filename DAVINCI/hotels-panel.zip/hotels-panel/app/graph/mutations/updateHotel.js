import gql from 'graphql-tag';

export default gql`
  mutation updateHotel($hotel: HotelUpdate) {
    updateHotel(hotel: $hotel){
      _id
      email
      name
      foc
      cityTax
      meal
      budget {
        personPerNight {
          min
          max
        }
      }
      confirmedConditions
      cancellationPolicy{
        free
        periods{
          from
          to
          percent
        }
      }
    }
  }
`;

import gql from 'graphql-tag';
import hotel from '../fragments/hotel';

export default gql`
  query hotelQuery{
    hotel{
      _id,
      ...hotelFragment
    }
  }
  ${hotel}
`;

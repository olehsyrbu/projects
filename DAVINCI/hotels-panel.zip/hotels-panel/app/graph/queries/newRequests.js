import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  query newRequests{
    newRequests {
      _id,
      ...RequestFragment
    }
  },
  ${session}
`;

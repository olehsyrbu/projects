import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  query ReservationsQuery{
    reservations{
      _id,
      ...RequestFragment
    }
  }
  ${session}
`;

import gql from 'graphql-tag';
import sessionSentOffers from '../fragments/sessionSentOffers';

export default gql`
  query sentOffers{
    sentOffers {
      _id,
      ...SessionSentOffersFragment
    }
  }
  ${sessionSentOffers}
`;

import gql from 'graphql-tag';
import session from '../fragments/session';

export default gql`
  query SessionQuery($sessionId: String!){
    session(sessionId: $sessionId){
      _id,
      ...RequestFragment
    }
  }
  ${session}
`;

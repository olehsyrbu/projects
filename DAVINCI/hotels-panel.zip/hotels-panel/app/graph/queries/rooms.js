import gql from 'graphql-tag';

export default gql`
  query roomTypes{
    roomTypes{
      _id,
      abbr,
      name,
    }
  }
`;

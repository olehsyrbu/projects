import gql from 'graphql-tag';
import additionalInfo from '../fragments/additionalInfo';

export default gql`
  query SessionQuery($sessionId: String!){
    session(sessionId: $sessionId){
      _id,
      ...AdditionalInfoFragment
    }
  }
  ${additionalInfo}
`;


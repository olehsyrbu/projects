import gql from 'graphql-tag';

export default gql`
query ConflictSessionQuery($sessionId: String!){
  intersectionSessions(sessionId: $sessionId) {
    num
    checkIn
    checkOut
    hotelsProposals {
      upTo
      proposals {
        rooms  {
          amount 
          room {
            abbr
            name
          }
        }
      }
    }
  }
}
`;


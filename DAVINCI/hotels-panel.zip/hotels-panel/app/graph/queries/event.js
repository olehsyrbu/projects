import gql from 'graphql-tag';

export default gql`
  query SystemEventQuery{
    SystemEvent{
      type,
      data
    }
  }
`;

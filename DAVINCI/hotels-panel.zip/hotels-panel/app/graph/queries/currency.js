import gql from 'graphql-tag';
import currencies from '../fragments/currencies';

export default gql`
  query currencyQuery{
    currencies{
      ...currenciesFragment
    }
  }
  ${currencies}
`;

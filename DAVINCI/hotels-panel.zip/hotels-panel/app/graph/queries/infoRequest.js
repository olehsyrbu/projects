import gql from 'graphql-tag';
import infoRequest from '../fragments/infoRequest';

export default gql`
  query SessionQuery($sessionId: String!){
    session(sessionId: $sessionId){
      _id,
      ...InfoRequestFragment
    }
  }
  ${infoRequest}
`;

Quick start
--------

1. Clone this repo using `git clone git@github.com:davincits/hotels-panel.git`
2. Move to the appropriate directory: `cd hotels-panel`.
3. Run `npm install` in order to install front dependencies.
4. At this point you can run `npm start` to see the example app at [http://localhost:3000](http://localhost:3000).
5. Move to the demo-server directory: `cd graph`. 
6. Run `npm install` in order to install back dependencies.
7. At this point you can run `npm start` to start back-end server api on http://localhost:4000 and to see the GraphQL IDE at [http://localhost:4000/graphiql](http://localhost:4000/graphiql).

##  Building
- Run `npm run build`
- Run `npm start`
---------------------------------

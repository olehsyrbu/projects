#!/bin/bash
set -e

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') CI variables imported
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Building docker image..."
docker build \
    -t ${K8S_ENV}/${K8S_DEPLOYMENT} \
    --build-arg VERSION_FROM_GIT_DESCRIBE=$VERSION_FROM_GIT_DESCRIBE \
    --build-arg NODE_ENV=$NODE_ENV \
    --build-arg API_INTERCOM_APP_ID=$API_INTERCOM_APP_ID \
    --build-arg GRAPH_URL=$GRAPH_URL \
    --build-arg WS_URL=$WS_URL \
    --build-arg API_CITY=$API_CITY \
    --build-arg API_SENTRY_DSN=$API_SENTRY_DSN .
echo "$(date '+%Y-%m-%d %H:%M:%S') docker build -t ${K8S_ENV}/${K8S_DEPLOYMENT}
$(date '+%Y-%m-%d %H:%M:%S') Image build finished
=============================================================================="
docker tag \
    ${K8S_ENV}/${K8S_DEPLOYMENT} \
    "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF}"
docker tag \
    ${K8S_ENV}/${K8S_DEPLOYMENT} \
    "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:latest"
echo "$(date '+%Y-%m-%d %H:%M:%S') Image tagged
=============================================================================="
export AWS_ACCESS_KEY_ID="${K8S_AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${K8S_AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${K8S_REGION}"
token="$( \
    aws ecr \
        --region=${K8S_REGION} \
        get-authorization-token \
            --output text \
            --query authorizationData[].authorizationToken \
    | base64 -d \
    | cut -d: -f2 \
)"
echo "export ECR_token=$token" \
    >> ".ci/.${BUILD_ENV}.${CI_COMMIT_SHORT_SHA}"

#docker login -u AWS -p "${token}" https://"${K8S_ACCOUNT}".dkr.ecr."${K8S_REGION}".amazonaws.com
$(aws ecr get-login --no-include-email --region ${K8S_REGION})
echo "$(date '+%Y-%m-%d %H:%M:%S') Docker login to image registry"

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Pushing images to registry
$(date '+%Y-%m-%d %H:%M:%S') ${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF}
$(date '+%Y-%m-%d %H:%M:%S') ${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:latest"
docker push \
    "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF}"
docker push \
    "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:latest"
echo "$(date '+%Y-%m-%d %H:%M:%S') Image pushed to registry
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Logging out from ECR..."
docker logout
echo "$(date '+%Y-%m-%d %H:%M:%S') Done."

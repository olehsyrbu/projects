#!/bin/bash
set -e

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Checking whether was finished previous(BUILD) step ... "
if [[ ! -f ".ci/.${BUILD_ENV}.${CI_COMMIT_SHORT_SHA}" ]]
then
    echo "______________________________________________________________________________
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$(date '+%Y-%m-%d %H:%M:%S') Build step not completed -- job will not continue
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
    exit 22
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') OK: previous step (build) was finished. Continuing...
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Importing environment variables from prev. stage... "
    source .ci/.${BUILD_ENV}.${CI_COMMIT_SHORT_SHA}
    echo "$(date '+%Y-%m-%d %H:%M:%S') Done."
fi

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Login to ECR registry"

$(aws ecr get-login --no-include-email --region ${K8S_REGION})

echo "$(date '+%Y-%m-%d %H:%M:%S') Done
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Pulling ${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF} image from registry..."

docker pull "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF}"

echo "$(date '+%Y-%m-%d %H:%M:%S') Done
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Deploying ${K8S_DEPLOYMENT} to S3 bucket, and invalidating cache"

docker run \
    --rm \
    --name "${K8S_DEPLOYMENT}" \
    --entrypoint ".ci/deploy.sh" \
    --env AWS_ACCESS_KEY_ID \
    --env AWS_SECRET_ACCESS_KEY \
    --env AWS_DEFAULT_REGION \
    --env CF_DISTRIBUTION \
    --env NODE_ENV \
    --env S3_BUCKET \
    "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF}" \
    ".ci/deploy.sh"
    

echo "$(date '+%Y-%m-%d %H:%M:%S') Job finished
=============================================================================="

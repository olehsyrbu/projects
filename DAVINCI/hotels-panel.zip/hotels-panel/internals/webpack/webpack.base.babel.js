/**
 * COMMON WEBPACK CONFIGURATION
 */


const path = require('path');
const webpack = require('webpack');
// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

module.exports = options => ({
  mode: options.mode,
  node: {
    fs: 'empty',
  },
  entry: options.entry,
  output: Object.assign({ // Compile into js/build.js
    path: path.resolve(process.cwd(), 'build'),
    publicPath: '/',
  }, options.output), // Merge with env dependent settings
  module: {
    rules: [
      {
        test: /node_modules\/cesium\/index\.js$/,
        use: [
          {
            loader: 'shebang-loader',
          },
        ],
      },
      {
        test: /\.js$/, // Transform all .js files required somewhere with Babel
        use: [
          {
            loader: 'babel-loader',
            query: options.babelQuery,
          },
          {
            loader: 'shebang-loader',
          },
        ],
        exclude: /node_modules/,
      },
      {
        // Do not transform vendor's CSS with CSS-modules
        // The point is that they remain in global scope.
        // Since we require these CSS files in our JS or CSS files,
        // they will be a part of our compilation either way.
        // So, no need for ExtractTextPlugin here.
        test: /\.css$/,
        include: /node_modules/,
        use: [
          {
            loader: 'style-loader',
          },
          {
            loader: 'css-loader',
          },
        ],
      },
      {
        test: /\.(sa|sc|c)ss$/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'style-loader',
          },
          {
            loader: 'css-loader',
          },
          {
            loader: 'sass-loader',
          },
        ],
      },
      {
        test: /\.(eot|svg|png|ttf|woff|woff2|jpg)$/,
        use: [{
          loader: 'file-loader',
        }],
      },
      {
        test: /\.(gif)$/,
        use: [
          {
            loader: 'file-loader',
          },
          {
            loader: 'image-webpack-loader',
            options: {
              mozjpeg: {
                progressive: true,
                quality: 65,
              },
              gifsicle: {
                interlaced: false,
              },
            },
          },
        ],
      },
      {
        test: /\.html$/,
        use: [{
          loader: 'html-loader',
        }],
      },
      {
        test: /\.(mp4|webm)$/,
        use: [{
          loader: 'url-loader',
          options: {
            limit: 1000,
          },
        }],
      }],
  },
  plugins: options.plugins.concat([
    // Always expose NODE_ENV to webpack, in order to use `process.env.NODE_ENV`
    // inside your code for any environment checks; UglifyJS will automatically
    // drop any unreachable code.
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify(process.env.NODE_ENV),
        GRAPH_URL: JSON.stringify(process.env.GRAPH_URL),
        API_CITY: JSON.stringify(process.env.API_CITY),
        WS_URL: JSON.stringify(process.env.WS_URL),
        API_SENTRY_DSN: JSON.stringify(process.env.API_SENTRY_DSN),
        API_INTERCOM_APP_ID: JSON.stringify(process.env.API_INTERCOM_APP_ID),
      },
      __VERSION__: JSON.stringify(process.env.VERSION_FROM_GIT_DESCRIBE ||
          require('child_process').execSync('git describe --tag').toString().trim()),
    }),
    new webpack.ProvidePlugin({
      // make fetch available
      fetch: 'exports-loader?self.fetch!whatwg-fetch',
    }),
    new webpack.NamedModulesPlugin(),
    new webpack.ContextReplacementPlugin(
      /moment[\\\/]lang$/,
      /^\.\/(en-gb|de|pl)$/,
    ),
    new webpack.ContextReplacementPlugin(
      /\.\/locale$/, 'empty-module', false,
      /js$/,
    ),
    // new BundleAnalyzerPlugin(),
  ]),
  resolve: {
    alias: {
      app: path.resolve(__dirname, './../../app'),
    },
    modules: ['app', 'node_modules'],
    extensions: [
      '.js',
      '.jsx',
      '.react.js',
    ],
    mainFields: [
      'browser',
      'jsnext:main',
      'main',
    ],
  },
  devtool: options.devtool,
  target: 'web', // Make web variables accessible to webpack, e.g. window
  performance: options.performance || {},
});

#!/bin/bash
set -e

vars=( 
    API_CITY
    API_INTERCOM_APP_ID
    API_SENTRY_DSN
    AWS_ACCESS_KEY_ID
    AWS_DEFAULT_REGION
    AWS_SECRET_ACCESS_KEY
    CF_DISTRIBUTION
    COMPOSE_HTTP_TIMEOUT
    CONTAINER_REGISTRY
    GRAPH_URL
    K8S_ACCOUNT
    K8S_AWS_ACCESS_KEY_ID
    K8S_AWS_SECRET_ACCESS_KEY
    K8S_CERT
    K8S_CERT_CLIENT
    K8S_CLUSTER_NAME
    K8S_DEPLOYMENT
    K8S_ENV
    K8S_KEY_CLIENT
    K8S_PASS_CLIENT
    K8S_REGION
    NODE_ENV
    PORT
    S3_BUCKET
    SERVICE_URL
    VERSION_FROM_GIT_DESCRIBE
    WS_URL
)

if [[ -z ${BUILD_ENV} ]]
then
    echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Build environment not defined. Exiting...
=============================================================================="
    exit 25
elif [[ ! ${BUILD_ENV} =~ ^(stage|k8s-stage|production|k8s-prod|qa)$ ]]
then
    echo "______________________________________________________________________________
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$(date '+%Y-%m-%d %H:%M:%S') Unknown build environment. Should be one of:
$(date '+%Y-%m-%d %H:%M:%S')    stage, k8s-stage, production, k8s-prod, qa.
$(date '+%Y-%m-%d %H:%M:%S')
$(date '+%Y-%m-%d %H:%M:%S') Exiting...
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
    exit 26
elif [[ ${BUILD_ENV} =~ ^("production"|"k8s-prod")$ ]]
then
    var_prefix=PROD
elif [[ ${BUILD_ENV} = "qa" ]]
then
    var_prefix=QA
else
    var_prefix=DEV
fi

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Build environment: ${BUILD_ENV} (prefix: ${var_prefix})"

for key in ${vars[*]}
do
    value="${var_prefix}_${key}"
    echo "export ${key}=${!value}" \
        >> ".ci/.${BUILD_ENV}.${CI_COMMIT_SHORT_SHA}"
done
echo "$(date '+%Y-%m-%d %H:%M:%S') CI variables exported
=============================================================================="

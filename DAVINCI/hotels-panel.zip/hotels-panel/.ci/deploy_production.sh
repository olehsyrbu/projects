#!/bin/bash
set -e

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Checking whether was finished previous(BUILD) step ... "
if [[ ! -f ".ci/.${BUILD_ENV}.${CI_COMMIT_SHORT_SHA}" ]]
then
    echo "______________________________________________________________________________
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$(date '+%Y-%m-%d %H:%M:%S') Build step not completed -- job will not continue
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"
    exit 22
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') OK: previous step (build) was finished. Continuing...
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Importing environment variables from prev. stage... "
    source .ci/.${BUILD_ENV}.${CI_COMMIT_SHORT_SHA}
    echo "$(date '+%Y-%m-%d %H:%M:%S') Done."
fi

echo "==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Getting AWS ECR authentication token..."
export AWS_ACCESS_KEY_ID="${K8S_AWS_ACCESS_KEY_ID}"
export AWS_SECRET_ACCESS_KEY="${K8S_AWS_SECRET_ACCESS_KEY}"
export AWS_DEFAULT_REGION="${K8S_REGION}"
cmd="$(aws ecr get-login --no-include-email)"
echo "$(date '+%Y-%m-%d %H:%M:%S') Done.
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Docker login ..."
eval ${cmd}
echo "$(date '+%Y-%m-%d %H:%M:%S') Done.
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Pull image from ECR repository ..."
docker \
    -H ${HOST} \
    --tlscacert /etc/docker/ssl/ca.pem \
    --tlscert /etc/docker/ssl/cert.pem \
    --tlskey /etc/docker/ssl/key.pem \
    --tlsverify \
    pull \
    "${K8S_ACCOUNT}.dkr.ecr.${K8S_REGION}.amazonaws.com/${K8S_ENV}/${K8S_DEPLOYMENT}:${CI_BUILD_REF}"
echo "$(date '+%Y-%m-%d %H:%M:%S') Done.
=============================================================================="
#$(date '+%Y-%m-%d %H:%M:%S') Shutting down service ${K8S_ENV}/${K8S_DEPLOYMENT} ..."
#docker-compose \
#    -H ${HOST} \
#    --tlscacert /etc/docker/ssl/ca.pem \
#    --tlscert /etc/docker/ssl/cert.pem \
#    --tlskey /etc/docker/ssl/key.pem \
#    --tlsverify \
#    down --remove-orphans
echo "$(date '+%Y-%m-%d %H:%M:%S') Done.
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Recreating service ${K8S_ENV}/${K8S_DEPLOYMENT} ..."
docker-compose \
    -H ${HOST} \
    --tlscacert /etc/docker/ssl/ca.pem \
    --tlscert /etc/docker/ssl/cert.pem \
    --tlskey /etc/docker/ssl/key.pem \
    --tlsverify \
    up -d -V --force-recreate
echo "$(date '+%Y-%m-%d %H:%M:%S') Done.
==============================================================================
$(date '+%Y-%m-%d %H:%M:%S') Docker logout ..."
docker logout
echo "$(date '+%Y-%m-%d %H:%M:%S') Done.
=============================================================================="

#!/bin/bash
set -e

echo "============================================================================="
aws sts get-caller-identity
echo "============================================================================="

aws s3 sync \
    /opt/app/build/ \
    "s3://${S3_BUCKET}" \
    --delete

aws configure set preview.cloudfront true

aws cloudfront \
    create-invalidation \
    --distribution-id "${CF_DISTRIBUTION}" \
    --paths "/*"
